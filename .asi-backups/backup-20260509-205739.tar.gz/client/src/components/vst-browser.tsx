// ── RFC-EXEMPT: STATUS palette (§4.5) ────────────────────────────────────────
// Colors: var(--status-warn) (amber)
// Reason: VST load/compatibility warning — adjacent to sanctioned vst.tsx
// Approved: P2 remediation pass — see PRD §4.5 and tools/p2_patch.py
// ─────────────────────────────────────────────────────────────────────────────
/**
 * client/src/components/vst-browser.tsx
 * VST Plugin Browser — Acid Grid Edition
 *
 * Fully restyled to match the ag- hardware aesthetic from instrument.tsx:
 * IBM Plex Mono, zero border-radius, acid-green (#a3e635) accents,
 * AG token system, no shadcn dependencies — all inline styles.
 *
 * Logic preserved 1:1:
 *   VSTScanner.loadFromStorage() / scanDirectory()
 *   Favorites, Recent, Category tabs
 *   Grid / List view toggle
 *   Per-category accent colours
 *   useVSTStore channel integration
 */

import type { CSSProperties } from 'react';
import { useState, useEffect, useMemo, useCallback } from 'react';
import { VSTScanner } from '@/audio/fx/vst-scanner';
import type { VSTPluginInfo } from '@/audio/fx/vst-scanner';
import { Search, Star, TrendingUp, Grid, List, RefreshCw, Package } from 'lucide-react';
import { getAudioContext } from '@/audio/core/audio-context';
import { useVSTStore } from '@/store/vst-store';

// ── Acid Grid design tokens ───────────────────────────────────────────────────
// Mirrors the CSS custom properties in instrument.tsx STYLES block.
const AG = {
  black:   'var(--void)',
  ink:     '#0a0a0a',
  panel:   '#0d0d0d',
  card:    'var(--t-b1)',
  border:  '#1c1c1c',
  mute:    '#2a2a2a',
  dim:     'var(--neutral-700)',
  mid:     'var(--dj-muted)',
  soft:    'var(--text-dim)',
  acid:    '#a3e635',
  acid2:   'var(--looper-lime)',
  acidDim: 'rgba(163,230,53,0.08)',
  acidD:   'var(--status-ok-dim)',
  white:   'var(--daw-fg)',
  err:     '#ff3b3b',
  rec:     '#ef4444',
  cyan:    'var(--looper-cyan)',
  font:    "'IBM Plex Mono', 'JetBrains Mono', monospace",
} as const;

// Per-category accent colours for badges and active states
const CAT_COLOR: Record<string, string> = {
  synth:      AG.acid,
  instrument: AG.acid,
  effects:    AG.cyan,
  effect:     AG.cyan,
  dynamics:   'var(--status-warn)',
  eq:         'var(--accent-violet-soft)',
  reverb:     'var(--accent-blue)',
  delay:      'var(--status-ok-alt)',
  distortion: AG.err,
  utility:    AG.soft,
  filter:     'var(--orange-400)',
  chorus:     'var(--accent-fuchsia)',
  modulation: 'var(--accent-blue)',
};
const catAccent = (cat = '') => CAT_COLOR[cat.toLowerCase()] ?? AG.soft;

// ── Shared style helpers ──────────────────────────────────────────────────────
const mono: CSSProperties = { fontFamily: AG.font };
const tag: CSSProperties  = {
  ...mono,
  fontSize: 7, letterSpacing: '0.2em',
  textTransform: 'uppercase' as const,
};

// Keyframes injected once
const KEYFRAMES = `
  @keyframes vst-spin  { to { transform: rotate(360deg); } }
  @keyframes vst-sweep { from { left: -60%; } to { left: 100%; } }
  @keyframes vst-pulse { from { opacity: 0.5; } to { opacity: 1; } }
`;

// ── Props ─────────────────────────────────────────────────────────────────────
interface VSTBrowserProps {
  onPluginSelect: (plugin: VSTPluginInfo) => void;
  channelId?:    string;
  showFXChain?:  boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export function VSTBrowser({ onPluginSelect, channelId }: VSTBrowserProps) {
  const addPluginToChannel = useVSTStore(s => s.addPluginToChannel);

  const [plugins,     setPlugins]     = useState<VSTPluginInfo[]>([]);
  const [recentIds,   setRecentIds]   = useState<string[]>([]);
  const [loadingId,   setLoadingId]   = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [viewMode,    setViewMode]    = useState<'grid' | 'list'>('grid');
  const [isScanning,  setIsScanning]  = useState(false);
  const [scanMsg,     setScanMsg]     = useState('');

  // Load cached plugins on mount
  useEffect(() => {
    VSTScanner.loadFromStorage();
    setPlugins(VSTScanner.getAllCachedPlugins());
  }, []);

  // ── Scan ─────────────────────────────────────────────────────────────────
  const handleScan = useCallback(async () => {
    setIsScanning(true);
    setScanMsg('INITIALIZING SCANNER...');
    try {
      const audioCtx = getAudioContext();
      setScanMsg('SCANNING /PLUGINS...');
      const result = await VSTScanner.scanDirectory('/plugins', audioCtx);
      setPlugins(result.plugins);
      VSTScanner.saveToStorage();
      setScanMsg(`FOUND ${result.plugins.length} PLUGIN${result.plugins.length !== 1 ? 'S' : ''}`);
      setTimeout(() => setScanMsg(''), 2500);
    } catch (err) {
      setScanMsg('SCAN FAILED');
      setTimeout(() => setScanMsg(''), 2500);
      console.error('VSTBrowser scan error:', err);
    } finally {
      setIsScanning(false);
    }
  }, []);

  // ── Select ───────────────────────────────────────────────────────────────
  const handlePluginSelect = useCallback((plugin: VSTPluginInfo) => {
    setLoadingId(plugin.id);
    setRecentIds(prev =>
      [plugin.id, ...prev.filter(id => id !== plugin.id)].slice(0, 10)
    );
    if (channelId) addPluginToChannel(channelId, plugin.id, plugin.name);
    onPluginSelect(plugin);
    setTimeout(() => setLoadingId(null), 600);
  }, [channelId, addPluginToChannel, onPluginSelect]);

  // ── Favorite toggle ───────────────────────────────────────────────────────
  const toggleFavorite = useCallback((pluginId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPlugins(prev =>
      prev.map(p => p.id === pluginId ? { ...p, isFavorite: !p.isFavorite } : p)
    );
    VSTScanner.saveToStorage();
  }, []);

  // ── Derived data ──────────────────────────────────────────────────────────
  const categories = useMemo(
    () => Array.from(new Set(plugins.map(p => p.category))).sort(),
    [plugins],
  );

  const filteredPlugins = useMemo(() => {
    return plugins.filter(plugin => {
      if (selectedCat === 'favorites') return !!plugin.isFavorite;
      if (selectedCat === 'recent')    return recentIds.includes(plugin.id);
      if (selectedCat !== 'all' && plugin.category !== selectedCat) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          plugin.name.toLowerCase().includes(q) ||
          plugin.vendor.toLowerCase().includes(q) ||
          plugin.tags.some(t => t.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [plugins, searchQuery, selectedCat, recentIds]);

  const TABS = [
    { id: 'all',       label: 'ALL',    icon: null,                           accent: AG.white },
    { id: 'favorites', label: 'FAV',    icon: <Star size={9} />,              accent: 'var(--status-warn)' },
    { id: 'recent',    label: 'RECENT', icon: <TrendingUp size={9} />,        accent: AG.cyan },
    ...categories.map(c => ({ id: c, label: c.toUpperCase(), icon: null, accent: catAccent(c) })),
  ];

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      background: AG.panel, fontFamily: AG.font,
      minHeight: 0, height: '100%',
    }}>
      <style>{KEYFRAMES}</style>

      {/* ── Toolbar ──────────────────────────────────────────────────────── */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '8px 14px',
        background: AG.ink,
        borderBottom: `1px solid ${AG.border}`,
        flexShrink: 0,
      }}>
        {/* Search */}
        <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
          <Search size={10} style={{
            position: 'absolute', left: 10, top: '50%',
            transform: 'translateY(-50%)',
            color: AG.mid, pointerEvents: 'none',
          }} />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="SEARCH PLUGINS..."
            style={{
              ...mono,
              width: '100%', boxSizing: 'border-box',
              background: AG.black,
              border: `1px solid ${AG.border}`,
              borderRadius: 0,
              color: AG.white,
              fontSize: 9, letterSpacing: '0.15em',
              padding: '6px 10px 6px 28px',
              outline: 'none',
              transition: 'border-color 0.1s, box-shadow 0.1s',
            }}
            onFocus={e => {
              e.currentTarget.style.borderColor = AG.acid;
              e.currentTarget.style.boxShadow  = `0 0 0 1px ${AG.acid}`;
            }}
            onBlur={e => {
              e.currentTarget.style.borderColor = AG.border;
              e.currentTarget.style.boxShadow  = 'none';
            }}
          />
        </div>

        {/* View toggle: grid / list */}
        {(['grid', 'list'] as const).map(mode => {
          const active = viewMode === mode;
          return (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              title={`${mode} view`}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                width: 28, height: 28, padding: 0, flexShrink: 0,
                background: active ? AG.acidDim : 'transparent',
                border: `1px solid ${active ? AG.acid : AG.border}`,
                color: active ? AG.acid : AG.mid,
                cursor: 'pointer',
                boxShadow: active ? `0 0 8px ${AG.acid}33` : 'none',
                transition: 'all 0.1s',
              }}
              onMouseEnter={e => {
                if (!active) {
                  e.currentTarget.style.borderColor = AG.dim;
                  e.currentTarget.style.color       = AG.soft;
                }
              }}
              onMouseLeave={e => {
                if (!active) {
                  e.currentTarget.style.borderColor = AG.border;
                  e.currentTarget.style.color       = AG.mid;
                }
              }}
            >
              {mode === 'grid' ? <Grid size={11} /> : <List size={11} />}
            </button>
          );
        })}

        {/* Scan button */}
        <button
          onClick={handleScan}
          disabled={isScanning}
          style={{
            ...mono,
            display: 'flex', alignItems: 'center', gap: 6,
            height: 28, padding: '0 12px', flexShrink: 0,
            background: isScanning ? AG.acidDim : 'transparent',
            border: `1px solid ${isScanning ? AG.acid : AG.border}`,
            color: isScanning ? AG.acid : AG.mid,
            cursor: isScanning ? 'default' : 'pointer',
            fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
            whiteSpace: 'nowrap',
            transition: 'all 0.1s',
          }}
          onMouseEnter={e => {
            if (!isScanning) {
              e.currentTarget.style.borderColor = AG.acid;
              e.currentTarget.style.color       = AG.acid;
            }
          }}
          onMouseLeave={e => {
            if (!isScanning) {
              e.currentTarget.style.borderColor = AG.border;
              e.currentTarget.style.color       = AG.mid;
            }
          }}
        >
          <RefreshCw
            size={10}
            style={{ animation: isScanning ? 'vst-spin 1s linear infinite' : 'none' }}
          />
          {isScanning ? 'SCANNING' : 'SCAN'}
        </button>
      </div>

      {/* Scan progress sweep bar */}
      {isScanning && (
        <div style={{
          height: 2, background: AG.border,
          position: 'relative', overflow: 'hidden', flexShrink: 0,
        }}>
          <div style={{
            position: 'absolute', left: '-60%', top: 0, bottom: 0, width: '60%',
            background: `linear-gradient(90deg, transparent, ${AG.acid}, transparent)`,
            animation: 'vst-sweep 1.2s linear infinite',
          }} />
        </div>
      )}

      {/* Scan status message */}
      {scanMsg && (
        <div style={{
          ...tag, color: isScanning ? AG.acid : AG.soft,
          padding: '4px 14px',
          background: AG.ink, borderBottom: `1px solid ${AG.border}`,
          flexShrink: 0,
        }}>
          {scanMsg}
        </div>
      )}

      {/* ── Category tabs ─────────────────────────────────────────────────── */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 2,
        overflowX: 'auto', flexShrink: 0,
        padding: '6px 14px',
        background: AG.black,
        borderBottom: `1px solid ${AG.border}`,
        // hide scrollbar
        scrollbarWidth: 'none' as const,
      }}>
        {TABS.map(({ id, label, icon, accent }) => {
          const active = selectedCat === id;
          return (
            <button
              key={id}
              onClick={() => setSelectedCat(id)}
              style={{
                ...mono,
                display: 'flex', alignItems: 'center', gap: 5,
                height: 24, padding: '0 10px', flexShrink: 0,
                background: active ? `${accent}18` : 'transparent',
                border: `1px solid ${active ? accent : AG.border}`,
                color: active ? accent : AG.mid,
                fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase',
                cursor: 'pointer',
                boxShadow: active ? `0 0 8px ${accent}33` : 'none',
                transition: 'all 0.1s',
                whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => {
                if (!active) {
                  e.currentTarget.style.color       = AG.soft;
                  e.currentTarget.style.borderColor = AG.mute;
                }
              }}
              onMouseLeave={e => {
                if (!active) {
                  e.currentTarget.style.color       = AG.mid;
                  e.currentTarget.style.borderColor = AG.border;
                }
              }}
            >
              {icon}
              {label}
            </button>
          );
        })}
      </div>

      {/* ── Plugin area ───────────────────────────────────────────────────── */}
      <div style={{
        flex: 1, overflowY: 'auto', minHeight: 0,
        padding: viewMode === 'grid' ? '12px 14px 6px' : 0,
        scrollbarWidth: 'thin' as const,
        scrollbarColor: `${AG.acidD} ${AG.ink}`,
      }}>

        {/* Empty state */}
        {filteredPlugins.length === 0 && (
          <div style={{
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            gap: 14, padding: '40px 20px',
          }}>
            <Package size={28} color={AG.dim} />
            <div style={{ ...tag, color: AG.mid, textAlign: 'center', fontSize: 9 }}>
              {searchQuery
                ? 'NO PLUGINS MATCH SEARCH'
                : plugins.length === 0
                  ? 'NO PLUGINS LOADED — CLICK SCAN'
                  : 'EMPTY FOR THIS FILTER'}
            </div>
            {plugins.length === 0 && !searchQuery && (
              <div style={{
                ...mono, fontSize: 8, color: AG.dim,
                textAlign: 'center', lineHeight: 2,
                maxWidth: 240,
              }}>
                Place .vst3 / .vst files in /plugins then press SCAN
              </div>
            )}
          </div>
        )}

        {/* ── Grid view ──────────────────────────────────────────────────── */}
        {viewMode === 'grid' && filteredPlugins.length > 0 && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(158px, 1fr))',
            gap: 5,
          }}>
            {filteredPlugins.map(plugin => (
              <PluginCard
                key={plugin.id}
                plugin={plugin}
                loading={loadingId === plugin.id}
                onSelect={() => handlePluginSelect(plugin)}
                onToggleFavorite={e => toggleFavorite(plugin.id, e)}
              />
            ))}
          </div>
        )}

        {/* ── List view ──────────────────────────────────────────────────── */}
        {viewMode === 'list' && filteredPlugins.length > 0 && (
          <div>
            {/* List header */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '88px 1fr 110px 70px 28px',
              gap: 0,
              padding: '5px 14px',
              background: AG.black,
              borderBottom: `1px solid ${AG.border}`,
              position: 'sticky', top: 0, zIndex: 1,
            }}>
              {['CAT', 'NAME', 'VENDOR', 'VER', '★'].map(h => (
                <div key={h} style={{ ...tag, color: AG.dim, fontSize: 8 }}>{h}</div>
              ))}
            </div>
            {filteredPlugins.map(plugin => (
              <PluginListItem
                key={plugin.id}
                plugin={plugin}
                loading={loadingId === plugin.id}
                onSelect={() => handlePluginSelect(plugin)}
                onToggleFavorite={e => toggleFavorite(plugin.id, e)}
              />
            ))}
          </div>
        )}

        {/* Footer count */}
        {filteredPlugins.length > 0 && (
          <div style={{
            ...tag, fontSize: 8, color: AG.dim, textAlign: 'right',
            padding: viewMode === 'grid' ? '8px 0 2px' : '6px 14px',
          }}>
            {filteredPlugins.length} PLUGIN{filteredPlugins.length !== 1 ? 'S' : ''}
            {searchQuery && ` — "${searchQuery.toUpperCase()}"`}
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PLUGIN CARD — grid view
// ─────────────────────────────────────────────────────────────────────────────
function PluginCard({
  plugin, loading, onSelect, onToggleFavorite,
}: {
  plugin:           VSTPluginInfo;
  loading?:         boolean;
  onSelect:         () => void;
  onToggleFavorite: (e: React.MouseEvent) => void;
}) {
  const [hovered, setHovered] = useState(false);
  const accent = catAccent(plugin.category);

  return (
    <div
      onClick={loading ? undefined : onSelect}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: 'relative',
        background: hovered ? 'var(--dj-surface2)' : AG.card,
        border: `1px solid ${hovered ? AG.dim : AG.border}`,
        borderTop: `2px solid ${hovered ? accent : AG.border}`,
        cursor: loading ? 'wait' : 'pointer',
        opacity: loading ? 0.55 : 1,
        transition: 'background 0.1s, border-color 0.1s',
        padding: '10px 10px 9px',
        display: 'flex', flexDirection: 'column', gap: 7,
        animation: loading ? 'vst-pulse 0.5s ease infinite alternate' : 'none',
        boxShadow: hovered ? `inset 0 0 20px rgba(0,0,0,0.4)` : 'none',
      }}
    >
      {/* Category badge + favorite */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
        <span style={{
          ...tag, fontSize: 7,
          color: accent,
          background: `${accent}14`,
          border: `1px solid ${accent}40`,
          padding: '2px 5px',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          maxWidth: '72%',
        }}>
          {plugin.category || 'VST'}
        </span>
        <button
          onClick={onToggleFavorite}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            padding: 2, flexShrink: 0,
            color: plugin.isFavorite ? 'var(--status-warn)' : AG.dim,
            transition: 'color 0.1s',
            display: 'flex', alignItems: 'center',
          }}
          onMouseEnter={e => { e.currentTarget.style.color = 'var(--status-warn)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = plugin.isFavorite ? 'var(--status-warn)' : AG.dim; }}
        >
          <Star size={10} style={{ fill: plugin.isFavorite ? 'var(--status-warn)' : 'none' }} />
        </button>
      </div>

      {/* Plugin name */}
      <div style={{
        fontFamily: AG.font, fontWeight: 600, fontSize: 11,
        color: hovered ? AG.white : 'var(--text-secondary)',
        letterSpacing: '0.02em', lineHeight: 1.2,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {plugin.name}
      </div>

      {/* Vendor */}
      <div style={{
        fontFamily: AG.font, fontSize: 8, color: AG.soft,
        letterSpacing: '0.08em',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {plugin.vendor}
      </div>

      {/* Tags */}
      {plugin.tags.length > 0 && (
        <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
          {plugin.tags.slice(0, 2).map(t => (
            <span key={t} style={{
              ...tag, fontSize: 7, color: AG.mid,
              border: `1px solid ${AG.border}`,
              padding: '1px 4px',
            }}>
              {t}
            </span>
          ))}
        </div>
      )}

      {/* Hover accent line at bottom */}
      {hovered && (
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: 1,
          background: accent,
          boxShadow: `0 0 6px ${accent}`,
          pointerEvents: 'none',
        }} />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PLUGIN LIST ITEM — list view
// ─────────────────────────────────────────────────────────────────────────────
function PluginListItem({
  plugin, loading, onSelect, onToggleFavorite,
}: {
  plugin:           VSTPluginInfo;
  loading?:         boolean;
  onSelect:         () => void;
  onToggleFavorite: (e: React.MouseEvent) => void;
}) {
  const [hovered, setHovered] = useState(false);
  const accent = catAccent(plugin.category);

  return (
    <div
      onClick={loading ? undefined : onSelect}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'grid',
        gridTemplateColumns: '88px 1fr 110px 70px 28px',
        alignItems: 'center',
        gap: 0,
        padding: '0 14px',
        height: 38,
        background: hovered ? 'var(--t-b1)' : 'transparent',
        borderBottom: `1px solid ${AG.border}`,
        borderLeft: `3px solid ${hovered ? accent : 'transparent'}`,
        cursor: loading ? 'wait' : 'pointer',
        opacity: loading ? 0.55 : 1,
        transition: 'background 0.08s, border-left-color 0.08s',
        animation: loading ? 'vst-pulse 0.5s ease infinite alternate' : 'none',
      }}
    >
      {/* Category */}
      <span style={{
        ...tag, fontSize: 7, color: accent,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        paddingRight: 8,
      }}>
        {plugin.category || '—'}
      </span>

      {/* Name */}
      <span style={{
        fontFamily: AG.font, fontWeight: 600, fontSize: 10,
        color: hovered ? AG.white : 'var(--daw-ghost)',
        letterSpacing: '0.04em',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        paddingRight: 8,
      }}>
        {plugin.name}
      </span>

      {/* Vendor */}
      <span style={{
        fontFamily: AG.font, fontSize: 9, color: AG.soft,
        letterSpacing: '0.06em',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        paddingRight: 8,
      }}>
        {plugin.vendor}
      </span>

      {/* Version */}
      <span style={{
        fontFamily: AG.font, fontSize: 8, color: AG.dim, letterSpacing: '0.1em',
      }}>
        {plugin.version ? `v${plugin.version}` : '—'}
      </span>

      {/* Favorite */}
      <button
        onClick={onToggleFavorite}
        style={{
          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: plugin.isFavorite ? 'var(--status-warn)' : AG.dim,
          transition: 'color 0.1s',
        }}
        onMouseEnter={e => { e.stopPropagation(); e.currentTarget.style.color = 'var(--status-warn)'; }}
        onMouseLeave={e => { e.currentTarget.style.color = plugin.isFavorite ? 'var(--status-warn)' : AG.dim; }}
      >
        <Star size={10} style={{ fill: plugin.isFavorite ? 'var(--status-warn)' : 'none' }} />
      </button>
    </div>
  );
}