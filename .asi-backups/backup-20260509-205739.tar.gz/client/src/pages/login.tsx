// client/src/pages/login.tsx
// Enhanced v2 — PRD-compliant design system
// Colors: cyan var(--accent-cyan) (active), violet var(--accent-purple) (AI), lime #a3e635 (accent),
//         amber var(--status-warn) (warning), red #ff3b3b (error)
// Font: JetBrains Mono (data), IBM Plex Mono (fallback)
// Background: var(--void), Card: #0a0a0a, Border: #1c1c1c
// Live pulse wave canvas behind panel — animated LLPTE signal visualization

import {
  useState,
  useEffect,
  useRef,
  useCallback,
  type FormEvent,
  type CSSProperties,
  type ReactNode,
} from 'react';
import { Link, useLocation } from 'wouter';
import { LogIn, AlertCircle, Eye, EyeOff, Cpu, Activity } from 'lucide-react';
import { useAuthStore } from '../hooks/authStore';

// ─── Types ────────────────────────────────────────────────────────────────────
type LoginState = 'idle' | 'loading' | 'error' | 'success';

interface Tokens {
  bg:       string;
  card:     string;
  cardGlow: string;
  border:   string;
  borderHi: string;
  accent:   string;
  accentHv: string;
  cyan:     string;
  violet:   string;
  amber:    string;
  text:     string;
  textSub:  string;
  muted:    string;
  dim:      string;
  error:    string;
  font:     string;
}

// ─── Design tokens — PRD-compliant ───────────────────────────────────────────
const T: Tokens = {
  bg:       'var(--void)',
  card:     '#0a0a0a',
  cardGlow: '#0d0d0d',
  border:   '#1c1c1c',
  borderHi: '#2a2a2a',
  accent:   '#a3e635',       // lime — R3 brand
  accentHv: 'var(--looper-lime)',
  cyan:     'var(--accent-cyan)',       // PRD: active state
  violet:   'var(--accent-purple)',       // PRD: AI signal
  amber:    'var(--status-warn)',       // PRD: warning
  text:     'var(--daw-fg)',
  textSub:  'var(--text-dim)',
  muted:    '#555555',
  dim:      'var(--dj-dimmer)',
  error:    '#ff3b3b',
  font:     "'JetBrains Mono','IBM Plex Mono','Fira Code',monospace",
};

// ─── Password strength ────────────────────────────────────────────────────────
function getStrength(pw: string): number {
  if (!pw) return 0;
  let s = 0;
  if (pw.length >= 8)          s++;
  if (/[A-Z]/.test(pw))        s++;
  if (/[0-9]/.test(pw))        s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}
const STRENGTH_LABEL = ['', 'WEAK', 'FAIR', 'STRONG', 'MAX'] as const;
const STRENGTH_COLOR = ['', '#ff3b3b', 'var(--status-warn)', '#a3e635', 'var(--accent-cyan)'] as const;

// ─── Keyframe injection ───────────────────────────────────────────────────────
const INJECTED_ID = 'r3-login-v2-keyframes';
function injectKeyframes(): void {
  if (typeof document === 'undefined') return;
  if (document.getElementById(INJECTED_ID)) return;
  const style = document.createElement('style');
  style.id = INJECTED_ID;
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&display=swap');

    @keyframes r3-shake {
      0%,100% { transform: translateX(0); }
      18%     { transform: translateX(-6px); }
      36%     { transform: translateX(6px); }
      54%     { transform: translateX(-4px); }
      72%     { transform: translateX(4px); }
    }
    @keyframes r3-fadein {
      from { opacity: 0; transform: translateY(-4px); }
      to   { opacity: 1; transform: none; }
    }
    @keyframes r3-spin {
      to { transform: rotate(360deg); }
    }
    @keyframes r3-pulse-dot {
      0%, 100% { opacity: 1; transform: scale(1); }
      50%      { opacity: 0.4; transform: scale(0.7); }
    }
    @keyframes r3-scan {
      0%   { transform: translateY(-100%); opacity: 0; }
      10%  { opacity: 0.6; }
      90%  { opacity: 0.6; }
      100% { transform: translateY(100vh); opacity: 0; }
    }
    @keyframes r3-glow-border {
      0%, 100% { box-shadow: 0 0 0 0 transparent, inset 0 1px 0 rgba(0,245,255,0.06); }
      50%      { box-shadow: 0 0 40px rgba(0,245,255,0.04), inset 0 1px 0 rgba(0,245,255,0.12); }
    }
    @keyframes r3-node-ping {
      0%   { transform: scale(1); opacity: 0.8; }
      100% { transform: scale(2.5); opacity: 0; }
    }
    @keyframes r3-dash-flow {
      to { stroke-dashoffset: -20; }
    }

    .r3-shake        { animation: r3-shake 0.42s cubic-bezier(.22,1,.36,1); }
    .r3-fadein       { animation: r3-fadein 0.22s ease; }
    .r3-spin         { animation: r3-spin 0.75s linear infinite; }
    .r3-glow-card    { animation: r3-glow-border 4s ease-in-out infinite; }

    .r3-input {
      display: block;
      width: 100%;
      box-sizing: border-box;
      background: var(--void);
      border: 1px solid #1c1c1c;
      border-radius: 0;
      color: var(--daw-fg);
      font-family: 'JetBrains Mono','IBM Plex Mono',monospace;
      font-size: 13px;
      padding: 12px 14px;
      outline: none;
      transition: border-color .15s, box-shadow .15s;
      letter-spacing: 0.02em;
    }
    .r3-input:focus {
      border-color: var(--accent-cyan);
      box-shadow: 0 0 0 1px rgba(0,245,255,0.15), inset 0 0 20px rgba(0,245,255,0.02);
    }
    .r3-input:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .r3-input::placeholder { color: var(--dj-dimmer); }

    .r3-checkbox {
      appearance: none;
      -webkit-appearance: none;
      width: 12px;
      height: 12px;
      border: 1px solid #2a2a2a;
      background: var(--void);
      cursor: pointer;
      flex-shrink: 0;
      transition: background 0.15s, border-color 0.15s;
    }
    .r3-checkbox:checked {
      background: #a3e635;
      border-color: #a3e635;
    }
  `;
  document.head.appendChild(style);
}

// ─── Live Pulse Wave Canvas ───────────────────────────────────────────────────
// Multi-layer signal visualization: LLPTE pre/post AI signal (violet + cyan)
// plus ambient carrier waves — all animated at 60fps
function PulseWaveCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let t = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.round(rect.width  || canvas.offsetWidth  || 800);
      const h = Math.round(rect.height || canvas.offsetHeight || 600);
      if (canvas.width !== w)  canvas.width  = w;
      if (canvas.height !== h) canvas.height = h;
    };
    let resizeTimer: ReturnType<typeof setTimeout> | undefined;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(resize, 80);
    };
    resize();
    window.addEventListener('resize', onResize);

    // Signal layers — PRD-accurate: violet = AI/pre, cyan = post-AI, lime = carrier
    const layers = [
      // Carrier / ambient — lime green, slow, wide
      { amp: 28,  freq: 0.007, speed: 0.008, phase: 0,    color: 'rgba(163,230,53,0.07)',  lineW: 1,   yOff: 0.50 },
      { amp: 14,  freq: 0.015, speed: 0.014, phase: 1.1,  color: 'rgba(163,230,53,0.04)',  lineW: 0.8, yOff: 0.38 },
      { amp: 20,  freq: 0.010, speed: 0.010, phase: 2.3,  color: 'rgba(163,230,53,0.035)', lineW: 0.8, yOff: 0.62 },

      // Pre-AI signal — violet, medium frequency
      { amp: 38,  freq: 0.018, speed: 0.022, phase: 0.5,  color: 'rgba(139,92,246,0.14)',  lineW: 1.2, yOff: 0.46 },
      { amp: 22,  freq: 0.030, speed: 0.032, phase: 1.8,  color: 'rgba(139,92,246,0.08)',  lineW: 0.8, yOff: 0.54 },

      // Post-AI signal — cyan, tighter, more processed
      { amp: 26,  freq: 0.024, speed: 0.028, phase: 0.9,  color: 'rgba(0,245,255,0.12)',   lineW: 1.5, yOff: 0.48 },
      { amp: 16,  freq: 0.040, speed: 0.038, phase: 2.1,  color: 'rgba(0,245,255,0.07)',   lineW: 1,   yOff: 0.52 },
      { amp: 10,  freq: 0.055, speed: 0.045, phase: 0.3,  color: 'rgba(0,245,255,0.04)',   lineW: 0.7, yOff: 0.50 },

      // LLPTE deep carrier — amber, very slow
      { amp: 60,  freq: 0.004, speed: 0.004, phase: 3.0,  color: 'rgba(245,158,11,0.025)', lineW: 1,   yOff: 0.50 },
    ];

    const draw = () => {
      const { width, height } = canvas;
      if (width > 0 && height > 0) {
        ctx.clearRect(0, 0, width, height);

        // Radial ambient glow behind card center
        const cx = width * 0.5;
        const cy = height * 0.5;
        const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, width * 0.55);
        grd.addColorStop(0, 'rgba(139,92,246,0.04)');
        grd.addColorStop(0.5, 'rgba(0,245,255,0.02)');
        grd.addColorStop(1, 'transparent');
        ctx.fillStyle = grd;
        ctx.fillRect(0, 0, width, height);

        layers.forEach(w => {
          ctx.beginPath();
          ctx.strokeStyle = w.color;
          ctx.lineWidth = w.lineW;

          const yBase = height * w.yOff;
          for (let x = 0; x <= width; x += 1.5) {
            const tScaled = t * w.speed * 60;
            const y =
              yBase
              + Math.sin(x * w.freq + tScaled + w.phase) * w.amp
              + Math.sin(x * w.freq * 0.47 + tScaled * 0.6 + w.phase * 1.3) * (w.amp * 0.35)
              + Math.sin(x * w.freq * 2.1  + tScaled * 1.4 + w.phase * 0.7) * (w.amp * 0.15);
            x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
          }
          ctx.stroke();
        });

        // Vertical scan line — subtle CRT sweep
        const scanX = ((t * 0.4) % (width + 200)) - 100;
        const scanGrd = ctx.createLinearGradient(scanX - 30, 0, scanX + 30, 0);
        scanGrd.addColorStop(0, 'transparent');
        scanGrd.addColorStop(0.5, 'rgba(0,245,255,0.025)');
        scanGrd.addColorStop(1, 'transparent');
        ctx.fillStyle = scanGrd;
        ctx.fillRect(scanX - 30, 0, 60, height);

        t++;
      }
      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animId);
      clearTimeout(resizeTimer);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position:      'absolute',
        inset:         0,
        width:         '100%',
        height:        '100%',
        pointerEvents: 'none',
      }}
    />
  );
}

// ─── Mini LLPTE oscilloscope — shows last 200 "ticks" as a live waveform ─────
function MiniOscilloscope({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bufRef    = useRef<Float32Array>(new Float32Array(200));
  const tRef      = useRef(0);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;

    const draw = () => {
      const t = tRef.current++;
      const buf = bufRef.current;
      // Simulate LLPTE post-AI signal
      const newSample =
        Math.sin(t * 0.12) * 0.4
        + Math.sin(t * 0.07 + 1.2) * 0.25
        + Math.sin(t * 0.21 + 0.5) * 0.15
        + (Math.random() - 0.5) * 0.06;
      buf.copyWithin(0, 1);
      buf[buf.length - 1] = newSample;

      const { width, height } = canvas;
      ctx.clearRect(0, 0, width, height);

      // Violet pre-AI (offset/phase shifted)
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(139,92,246,0.7)';
      ctx.lineWidth = 1;
      for (let i = 0; i < buf.length; i++) {
        const x = (i / buf.length) * width;
        const vPre = Math.sin((tRef.current - buf.length + i) * 0.12 + 0.8) * 0.4
                   + Math.sin((tRef.current - buf.length + i) * 0.07 + 2.0) * 0.25;
        const y = height * 0.5 - vPre * (height * 0.38);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Cyan post-AI
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(0,245,255,0.85)';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < buf.length; i++) {
        const x = (i / buf.length) * width;
        const y = height * 0.5 - buf[i] * (height * 0.38);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Zero line
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255,255,255,0.06)';
      ctx.lineWidth = 0.5;
      ctx.moveTo(0, height * 0.5);
      ctx.lineTo(width, height * 0.5);
      ctx.stroke();

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      width={220}
      height={36}
      style={{ width: '100%', height: 36, display: 'block' }}
    />
  );
}

// ─── LLPTE status badge row ───────────────────────────────────────────────────
function LLPTEBar({ state }: { state: LoginState }) {
  const isActive = state === 'loading' || state === 'success';
  const latency  = isActive ? '10ms' : '—';
  const edges    = isActive ? '847' : '—';

  const badge = (label: string, val: string, color: string) => (
    <div style={{
      display:    'flex',
      alignItems: 'center',
      gap:        5,
      padding:    '3px 8px',
      border:     `1px solid ${T.border}`,
      background: 'var(--t-b0x)',
    }}>
      <div style={{
        width:        5,
        height:        5,
        borderRadius: '50%',
        background:    color,
        boxShadow:     isActive ? `0 0 6px ${color}` : 'none',
        flexShrink:    0,
        animation:     isActive ? 'r3-pulse-dot 1.4s ease-in-out infinite' : 'none',
      }} />
      <span style={{ fontSize: 8, color: T.muted, letterSpacing: '.2em' }}>{label}</span>
      <span style={{ fontSize: 8, color: isActive ? color : T.dim, letterSpacing: '.1em', fontWeight: 700 }}>{val}</span>
    </div>
  );

  return (
    <div style={{
      display:      'flex',
      alignItems:   'center',
      gap:          6,
      padding:      '10px 36px',
      borderBottom: `1px solid ${T.border}`,
      background:   'var(--t-b0xx)',
      overflowX:    'auto',
    }}>
      <Cpu size={9} color={T.muted} strokeWidth={1.5} style={{ flexShrink: 0 }} />
      <span style={{ fontSize: 8, letterSpacing: '.25em', color: T.dim, marginRight: 4 }}>LLPTE</span>
      {badge('INFER', latency, T.cyan)}
      {badge('EDGES', edges,   T.violet)}
      {badge('TICK',  isActive ? '0.8ms' : '—', T.accent)}
      <div style={{ flex: 1 }} />
      <Activity size={9} color={isActive ? T.cyan : T.dim} strokeWidth={1.5} style={{ flexShrink: 0 }} />
    </div>
  );
}

// ─── Mini oscilloscope panel ──────────────────────────────────────────────────
function OscilloscopePanel({ active }: { active: boolean }) {
  return (
    <div style={{
      padding:      '10px 36px 12px',
      borderBottom: `1px solid ${T.border}`,
      background:   'var(--t-b0xx)',
    }}>
      <div style={{
        display:       'flex',
        justifyContent:'space-between',
        alignItems:    'center',
        marginBottom:  6,
      }}>
        <span style={{ fontSize: 8, color: T.dim, letterSpacing: '.2em' }}>SIGNAL</span>
        <div style={{ display: 'flex', gap: 10 }}>
          <span style={{ fontSize: 7, color: T.violet, letterSpacing: '.15em' }}>■ PRE-AI</span>
          <span style={{ fontSize: 7, color: T.cyan,   letterSpacing: '.15em' }}>■ POST-AI</span>
        </div>
      </div>
      <div style={{
        background: T.bg,
        border:     `1px solid ${T.border}`,
        overflow:   'hidden',
      }}>
        <MiniOscilloscope active={active} />
      </div>
    </div>
  );
}

// ─── Submit button ────────────────────────────────────────────────────────────
function SubmitButton({ state }: { state: LoginState }) {
  const isLoading = state === 'loading';
  const isSuccess = state === 'success';
  const [hovered, setHovered] = useState(false);

  const bg = isSuccess
    ? T.cyan
    : hovered && !isLoading
    ? T.accentHv
    : T.accent;

  return (
    <button
      type="submit"
      disabled={isLoading || isSuccess}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'center',
        gap:            9,
        width:          '100%',
        padding:        '15px',
        border:         'none',
        borderRadius:   0,
        background:     bg,
        color:          'var(--void)',
        fontFamily:     T.font,
        fontSize:       11,
        letterSpacing:  '.3em',
        textTransform:  'uppercase' as const,
        fontWeight:     700,
        cursor:         isLoading || isSuccess ? 'not-allowed' : 'pointer',
        transition:     'background 0.15s, box-shadow 0.2s',
        opacity:        isLoading ? 0.8 : 1,
        boxShadow:      isSuccess
          ? `0 0 30px ${T.cyan}55, 0 0 60px ${T.cyan}22`
          : hovered && !isLoading
          ? `0 0 20px ${T.accent}44`
          : `0 0 12px ${T.accent}22`,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Sweep shimmer on hover */}
      {hovered && !isLoading && !isSuccess && (
        <div style={{
          position:   'absolute',
          inset:      0,
          background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.12) 50%, transparent 100%)',
          animation:  'r3-scan 0.6s ease-out forwards',
          pointerEvents: 'none',
        }} />
      )}

      {isSuccess ? (
        <>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="20 6 9 17 4 12" />
          </svg>
          AUTHORIZED
        </>
      ) : isLoading ? (
        <>
          <svg
            className="r3-spin"
            width="13" height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
          >
            <circle cx="12" cy="12" r="10" strokeDasharray="40" strokeDashoffset="30" strokeLinecap="round" />
          </svg>
          AUTHENTICATING…
        </>
      ) : (
        <>
          <LogIn size={13} strokeWidth={2} />
          AUTHENTICATE
        </>
      )}
    </button>
  );
}

// ─── Field block ──────────────────────────────────────────────────────────────
function FieldBlock({
  label,
  children,
  style,
}: {
  label:    string;
  children: ReactNode;
  style?:   CSSProperties;
}) {
  return (
    <div style={{ marginBottom: 20, ...style }}>
      <span style={{
        display:       'block',
        fontSize:      9,
        letterSpacing: '.28em',
        textTransform: 'uppercase' as const,
        color:         T.muted,
        marginBottom:  8,
      }}>
        {label}
      </span>
      {children}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [credential, setCredential] = useState('');
  const [password,   setPassword]   = useState('');
  const [showPw,     setShowPw]     = useState(false);
  const [remember,   setRemember]   = useState(false);
  const [loginState, setLoginState] = useState<LoginState>('idle');
  const [errorMsg,   setErrorMsg]   = useState('');
  const [mounted,    setMounted]    = useState(false);
  const [shakeKey,   setShakeKey]   = useState(0);

  const credRef       = useRef<HTMLInputElement>(null);
  const errorTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const strength  = getStrength(password);
  const isLoading = loginState === 'loading';
  const isSuccess = loginState === 'success';
  const isError   = loginState === 'error';

  useEffect(() => {
    injectKeyframes();
    const mountTimer = setTimeout(() => setMounted(true), 60);
    return () => {
      clearTimeout(mountTimer);
      if (errorTimerRef.current) clearTimeout(errorTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (mounted) credRef.current?.focus();
  }, [mounted]);

  const triggerError = useCallback((msg: string) => {
    if (errorTimerRef.current) clearTimeout(errorTimerRef.current);
    setErrorMsg(msg);
    setLoginState('error');
    setShakeKey(k => k + 1);
    errorTimerRef.current = setTimeout(() => setLoginState('idle'), 5000);
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isLoading || isSuccess) return;

    const trimmed = credential.trim();
    if (!trimmed || !password) {
      triggerError('All fields are required.');
      return;
    }

    setLoginState('loading');
    setErrorMsg('');

    try {
      await useAuthStore.getState().login(trimmed, password);
      setLoginState('success');
      setTimeout(() => setLocation('/instrument'), 800);
    } catch (err) {
      const raw = (err as Error).message ?? '';
      triggerError(raw || 'Authentication failed — check your credentials.');
    }
  };

  // PRD: grid texture behind everything
  const gridBg = [
    'repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(255,255,255,.008) 3px,rgba(255,255,255,.008) 4px)',
    'repeating-linear-gradient(90deg,transparent,transparent 39px,rgba(255,255,255,.01) 39px,rgba(255,255,255,.01) 40px)',
  ].join(',');

  // Top border: cyan on active/success, error on error, accent normally
  const topBorderColor = isSuccess ? T.cyan : isError ? T.error : T.accent;

  const cardTranslateY = mounted ? '0' : '16px';
  const cardOpacity    = mounted ? 1 : 0;

  return (
    <div style={{
      display:         'flex',
      alignItems:      'center',
      justifyContent:  'center',
      minHeight:       'calc(100vh - var(--nav-h, 0px))',
      background:      T.bg,
      backgroundImage: gridBg,
      fontFamily:      T.font,
      padding:         '40px 20px',
      position:        'relative',
      overflow:        'hidden',
    }}>

      {/* ── Live pulse wave background ── */}
      <PulseWaveCanvas />

      {/* ── Subtle corner vignette ── */}
      <div style={{
        position:      'absolute',
        inset:         0,
        background:    'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.6) 100%)',
        pointerEvents: 'none',
      }} />

      {/* ── Panel ── */}
      <div
        key={shakeKey === 0 ? 'card-init' : `card-${shakeKey}`}
        className={`r3-glow-card${shakeKey > 0 ? ' r3-shake' : ''}`}
        style={{
          position:   'relative',
          zIndex:     10,
          width:      'min(540px, calc(100vw - 40px))',
          background: T.card,
          border:     `1px solid ${T.border}`,
          borderTop:  `2px solid ${topBorderColor}`,
          opacity:    cardOpacity,
          transform:  `translateY(${cardTranslateY})`,
          transition: 'opacity 0.45s ease, transform 0.45s cubic-bezier(.22,1,.36,1), border-top-color 0.25s',
        }}
      >
        {/* Top glow under border */}
        <div style={{
          position:      'absolute',
          top:           1,
          left:          0,
          right:         0,
          height:        1,
          background:    `linear-gradient(90deg, transparent 0%, ${topBorderColor}55 40%, ${topBorderColor}33 60%, transparent 100%)`,
          pointerEvents: 'none',
          transition:    'background 0.25s',
        }} />

        {/* Outer glow ring — success only */}
        {isSuccess && (
          <div style={{
            position:      'absolute',
            inset:         -1,
            border:        `1px solid ${T.cyan}30`,
            boxShadow:     `0 0 40px ${T.cyan}15`,
            pointerEvents: 'none',
          }} />
        )}

        {/* ── Header ── */}
        <div style={{
          padding:      '22px 36px 20px',
          borderBottom: `1px solid ${T.border}`,
          display:      'flex',
          alignItems:   'center',
          gap:          14,
        }}>
          {/* Status dot */}
          <div style={{
            width:        8,
            height:       8,
            borderRadius: '50%',
            background:   isError ? T.error : isSuccess ? T.cyan : T.accent,
            boxShadow:    isError
              ? `0 0 10px ${T.error}, 0 0 20px ${T.error}55`
              : isSuccess
              ? `0 0 10px ${T.cyan}, 0 0 20px ${T.cyan}55`
              : `0 0 8px ${T.accent}, 0 0 16px ${T.accent}44`,
            flexShrink:   0,
            transition:   'background 0.2s, box-shadow 0.2s',
            animation:    'r3-pulse-dot 2s ease-in-out infinite',
          }} />

          <LogIn size={15} color={isSuccess ? T.cyan : T.accent} strokeWidth={1.5} style={{ transition: 'color 0.2s' }} />

          <div style={{ flex: 1 }}>
            <div style={{
              fontSize:      15,
              fontWeight:    700,
              color:         T.text,
              letterSpacing: '-.01em',
              lineHeight:    1,
              marginBottom:  6,
            }}>
              R3<span style={{ color: T.accent, margin: '0 3px' }}>/</span>NATIVE
              <span style={{
                marginLeft:    10,
                fontSize:       9,
                letterSpacing: '.2em',
                color:         T.dim,
                fontWeight:    400,
              }}>v4.2.1</span>
            </div>
            <div style={{
              fontSize:      9,
              letterSpacing: '.3em',
              textTransform: 'uppercase' as const,
              color:         T.muted,
            }}>
              Authenticate to continue
            </div>
          </div>

          {/* State chip */}
          <div style={{
            display:       'flex',
            alignItems:    'center',
            gap:           6,
            fontSize:      8,
            letterSpacing: '.2em',
            textTransform: 'uppercase' as const,
            color:         isSuccess ? T.cyan : isError ? T.error : isLoading ? T.violet : T.dim,
            borderLeft:    `1px solid ${T.border}`,
            paddingLeft:   14,
            transition:    'color 0.2s',
          }}>
            {isLoading && (
              <div style={{
                width:        6,
                height:       6,
                borderRadius: '50%',
                background:   T.violet,
                animation:    'r3-pulse-dot 0.8s ease-in-out infinite',
              }} />
            )}
            {isSuccess ? 'AUTHORIZED' : isError ? 'DENIED' : isLoading ? 'CHECKING' : 'SECURE'}
          </div>
        </div>

        {/* ── LLPTE status bar ── */}
        <LLPTEBar state={loginState} />

        {/* ── Oscilloscope ── */}
        <OscilloscopePanel active={isLoading || isSuccess} />

        {/* ── Form ── */}
        <form onSubmit={handleSubmit} style={{ padding: '28px 36px 32px' }} noValidate>

          {isError && errorMsg && (
            <div
              className="r3-fadein"
              role="alert"
              style={{
                display:      'flex',
                gap:          10,
                alignItems:   'flex-start',
                background:   'rgba(255,59,59,.05)',
                borderLeft:   `2px solid ${T.error}`,
                padding:      '12px 16px',
                marginBottom: 24,
              }}
            >
              <AlertCircle size={12} color={T.error} style={{ marginTop: 1, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: 'rgba(255,59,59,.8)', letterSpacing: '.05em', lineHeight: 1.5 }}>
                {errorMsg}
              </span>
            </div>
          )}

          <FieldBlock label="Email or Username">
            <input
              ref={credRef}
              type="text"
              value={credential}
              onChange={e => setCredential(e.target.value)}
              placeholder="you@example.com"
              autoComplete="username"
              spellCheck={false}
              disabled={isLoading || isSuccess}
              className="r3-input"
            />
          </FieldBlock>

          <FieldBlock label="Password" style={{ marginBottom: 8 }}>
            <div style={{ position: 'relative' }}>
              <input
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                disabled={isLoading || isSuccess}
                className="r3-input"
                style={{ paddingRight: 44 }}
              />
              <button
                type="button"
                onClick={() => setShowPw(v => !v)}
                aria-label={showPw ? 'Hide password' : 'Show password'}
                style={{
                  position:   'absolute',
                  right:      12,
                  top:        '50%',
                  transform:  'translateY(-50%)',
                  background: 'none',
                  border:     'none',
                  cursor:     'pointer',
                  color:      T.muted,
                  padding:    4,
                  display:    'flex',
                  alignItems: 'center',
                }}
              >
                {showPw ? <EyeOff size={13} strokeWidth={1.5} /> : <Eye size={13} strokeWidth={1.5} />}
              </button>
            </div>
          </FieldBlock>

          {/* Strength bar */}
          {password.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
              <div style={{ display: 'flex', gap: 3, flex: 1 }}>
                {([1, 2, 3, 4] as const).map(n => (
                  <div key={n} style={{
                    flex:       1,
                    height:     2,
                    background: n <= strength ? STRENGTH_COLOR[strength] : T.border,
                    transition: 'background 0.3s',
                    boxShadow:  n <= strength && strength >= 3
                      ? `0 0 6px ${STRENGTH_COLOR[strength]}88`
                      : 'none',
                  }} />
                ))}
              </div>
              <span style={{
                fontSize:      8,
                letterSpacing: '.2em',
                color:         strength > 0 ? STRENGTH_COLOR[strength] : T.muted,
                minWidth:      38,
                textAlign:     'right' as const,
                transition:    'color 0.3s',
              }}>
                {STRENGTH_LABEL[strength]}
              </span>
            </div>
          )}

          {/* Remember + Forgot */}
          <div style={{
            display:        'flex',
            alignItems:     'center',
            justifyContent: 'space-between',
            marginBottom:   28,
          }}>
            <label style={{
              display:    'flex',
              alignItems: 'center',
              gap:        8,
              cursor:     'pointer',
              userSelect: 'none' as const,
            }}>
              <input
                type="checkbox"
                checked={remember}
                onChange={e => setRemember(e.target.checked)}
                disabled={isLoading || isSuccess}
                className="r3-checkbox"
              />
              <span style={{ fontSize: 9, letterSpacing: '.2em', textTransform: 'uppercase' as const, color: T.muted }}>
                Remember me
              </span>
            </label>

            <Link
              href="/forgot-password"
              style={{
                fontSize:       9,
                letterSpacing:  '.15em',
                textTransform:  'uppercase' as const,
                color:          T.dim,
                textDecoration: 'none',
                transition:     'color 0.15s',
              }}
            >
              Forgot password?
            </Link>
          </div>

          <SubmitButton state={loginState} />

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, margin: '24px 0' }}>
            <div style={{ flex: 1, height: 1, background: T.border }} />
            <span style={{ fontSize: 8, letterSpacing: '.25em', color: T.dim, textTransform: 'uppercase' as const }}>or</span>
            <div style={{ flex: 1, height: 1, background: T.border }} />
          </div>

          <p style={{ fontSize: 10, letterSpacing: '.1em', color: T.muted, textAlign: 'center' as const, margin: 0 }}>
            No account?{' '}
            <Link href="/" style={{ color: T.accent, textDecoration: 'none' }}>
              View Plans →
            </Link>
            {' '}·{' '}
            <Link href="/auth" style={{ color: T.violet, textDecoration: 'none' }}>
              Full Auth →
            </Link>
          </p>
        </form>

        {/* ── Footer strip ── */}
        <div style={{
          display:        'flex',
          justifyContent: 'space-between',
          alignItems:     'center',
          padding:        '10px 36px',
          borderTop:      `1px solid ${T.border}`,
          background:     'var(--t-b0xx)',
        }}>
          <span style={{ fontSize: 7, letterSpacing: '.2em', color: T.dim }}>SECURE · ENCRYPTED</span>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            {/* Tiny node indicators — PRD LLPTE pipeline nodes */}
            {[T.cyan, T.violet, T.violet, T.cyan, 'var(--status-ok)'].map((c, i) => (
              <div key={i} style={{
                width:        5,
                height:       5,
                borderRadius: '50%',
                background:    c,
                opacity:       0.5,
              }} />
            ))}
          </div>
          <span style={{ fontSize: 7, letterSpacing: '.2em', color: T.dim }}>R3 v4</span>
        </div>

        {/* Bottom scan line */}
        <div style={{
          height:     2,
          background: `repeating-linear-gradient(90deg, ${T.border} 0px, ${T.border} 1px, transparent 1px, transparent 5px)`,
          opacity:    0.4,
        }} />
      </div>
    </div>
  );
}
