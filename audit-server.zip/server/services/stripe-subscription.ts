// ─────────────────────────────────────────────────────────────────────────────
// R3 · Stripe Subscription Service
// Drop into: server/services/stripe-subscription.ts
// Requires:  npm install stripe  (if not already installed)
// ─────────────────────────────────────────────────────────────────────────────

import Stripe from 'stripe';
import { db } from '../db';                             // adjust to your db import
import { subscriptions, stripeEvents } from '../../shared/schema-subscription';
import { eq } from 'drizzle-orm';
import {
  SubscriptionTier,
  BillingCycle,
  SubscriptionStatus,
  UserSubscription,
  TIER_DEFINITIONS,
} from '../../shared/subscription.types';

// ── Stripe client ─────────────────────────────────────────────────────────────

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY env var is required');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-04-10',
  typescript: true,
});

// ── Get or create Stripe customer ─────────────────────────────────────────────

export async function getOrCreateStripeCustomer(
  userId: string,
  email: string,
  name?: string,
): Promise<string> {
  const existing = await db
    .select({ stripeCustomerId: subscriptions.stripeCustomerId })
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);

  if (existing[0]?.stripeCustomerId) {
    return existing[0].stripeCustomerId;
  }

  const customer = await stripe.customers.create({
    email,
    name,
    metadata: { r3UserId: userId },
  });

  // Upsert a free-tier subscription row with the customer id
  await db
    .insert(subscriptions)
    .values({
      id: `free_${userId}`,
      userId,
      tier: 'explorer',
      status: 'active',
      stripeCustomerId: customer.id,
    })
    .onConflictDoUpdate({
      target: subscriptions.userId,
      set: { stripeCustomerId: customer.id, updatedAt: new Date() },
    });

  return customer.id;
}

// ── Create checkout session ───────────────────────────────────────────────────

export interface CreateCheckoutOptions {
  userId: string;
  email: string;
  name?: string;
  tier: Exclude<SubscriptionTier, 'explorer'>;
  billingCycle: BillingCycle;
  successUrl: string;
  cancelUrl: string;
  trialDays?: number;    // default: 7
}

export async function createCheckoutSession(opts: CreateCheckoutOptions): Promise<string> {
  const { tier, billingCycle } = opts;
  const tierDef = TIER_DEFINITIONS[tier];

  const priceId =
    billingCycle === 'annual'
      ? tierDef.stripePriceIdAnnual
      : tierDef.stripePriceIdMonthly;

  if (!priceId) {
    throw new Error(`No Stripe price configured for ${tier} ${billingCycle}`);
  }

  const customerId = await getOrCreateStripeCustomer(opts.userId, opts.email, opts.name);
  const trialPeriodDays = opts.trialDays ?? 7;

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    line_items: [{ price: priceId, quantity: 1 }],
    subscription_data: {
      trial_period_days: trialPeriodDays,
      metadata: { r3UserId: opts.userId, r3Tier: tier },
    },
    metadata: { r3UserId: opts.userId, r3Tier: tier },
    success_url: opts.successUrl,
    cancel_url: opts.cancelUrl,
    allow_promotion_codes: true,
  });

  return session.url!;
}

// ── Create customer portal session ───────────────────────────────────────────

export async function createPortalSession(
  userId: string,
  returnUrl: string,
): Promise<string> {
  const row = await db
    .select({ stripeCustomerId: subscriptions.stripeCustomerId })
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);

  if (!row[0]?.stripeCustomerId) {
    throw new Error('No Stripe customer found for this user');
  }

  const session = await stripe.billingPortal.sessions.create({
    customer: row[0].stripeCustomerId,
    return_url: returnUrl,
  });

  return session.url;
}

// ── Get user subscription ─────────────────────────────────────────────────────

export async function getUserSubscription(userId: string): Promise<UserSubscription> {
  const row = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);

  if (!row[0]) {
    // No row yet — treat as free Explorer
    return {
      tier: 'explorer',
      status: 'active',
      billingCycle: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: false,
      trialEnd: null,
      stripeCustomerId: null,
    };
  }

  const s = row[0];
  return {
    tier: s.tier,
    status: s.status,
    billingCycle: s.billingCycle ?? null,
    currentPeriodEnd: s.currentPeriodEnd ?? null,
    cancelAtPeriodEnd: s.cancelAtPeriodEnd,
    trialEnd: s.trialEnd ?? null,
    stripeCustomerId: s.stripeCustomerId ?? null,
  };
}

// ── Handle Stripe webhook ─────────────────────────────────────────────────────

export async function handleStripeWebhook(
  rawBody: Buffer,
  signature: string,
): Promise<void> {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) throw new Error('STRIPE_WEBHOOK_SECRET is not set');

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    throw new Error(`Webhook signature verification failed: ${(err as Error).message}`);
  }

  // Idempotency guard
  const already = await db
    .select({ id: stripeEvents.id })
    .from(stripeEvents)
    .where(eq(stripeEvents.id, event.id))
    .limit(1);

  if (already.length > 0) return; // already processed

  await db.insert(stripeEvents).values({
    id: event.id,
    type: event.type,
    payload: JSON.stringify(event),
  });

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated':
      await syncSubscription(event.data.object as Stripe.Subscription);
      break;

    case 'customer.subscription.deleted':
      await cancelSubscription(event.data.object as Stripe.Subscription);
      break;

    case 'invoice.payment_failed':
      await markPastDue((event.data.object as Stripe.Invoice).subscription as string);
      break;

    default:
      // Unhandled event types are fine — log and move on
      console.info(`[stripe] unhandled event type: ${event.type}`);
  }
}

// ── Internal sync helpers ─────────────────────────────────────────────────────

async function syncSubscription(sub: Stripe.Subscription): Promise<void> {
  const userId = sub.metadata?.r3UserId;
  if (!userId) {
    console.warn('[stripe] subscription missing r3UserId metadata', sub.id);
    return;
  }

  const tier = (sub.metadata?.r3Tier as SubscriptionTier) ?? 'explorer';
  const priceId = sub.items.data[0]?.price.id ?? null;
  const billingCycle = detectBillingCycle(sub);
  const status = sub.status as SubscriptionStatus;

  await db
    .insert(subscriptions)
    .values({
      id: sub.id,
      userId,
      tier,
      status,
      billingCycle,
      stripeCustomerId: sub.customer as string,
      stripeSubscriptionId: sub.id,
      stripePriceId: priceId,
      currentPeriodStart: new Date(sub.current_period_start * 1000),
      currentPeriodEnd: new Date(sub.current_period_end * 1000),
      cancelAtPeriodEnd: sub.cancel_at_period_end,
      trialStart: sub.trial_start ? new Date(sub.trial_start * 1000) : null,
      trialEnd: sub.trial_end ? new Date(sub.trial_end * 1000) : null,
    })
    .onConflictDoUpdate({
      target: subscriptions.userId,
      set: {
        tier,
        status,
        billingCycle,
        stripeCustomerId: sub.customer as string,
        stripeSubscriptionId: sub.id,
        stripePriceId: priceId,
        currentPeriodStart: new Date(sub.current_period_start * 1000),
        currentPeriodEnd: new Date(sub.current_period_end * 1000),
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        trialStart: sub.trial_start ? new Date(sub.trial_start * 1000) : null,
        trialEnd: sub.trial_end ? new Date(sub.trial_end * 1000) : null,
        updatedAt: new Date(),
      },
    });
}

async function cancelSubscription(sub: Stripe.Subscription): Promise<void> {
  const userId = sub.metadata?.r3UserId;
  if (!userId) return;

  await db
    .update(subscriptions)
    .set({
      tier: 'explorer',
      status: 'canceled',
      canceledAt: new Date(),
      cancelAtPeriodEnd: false,
      updatedAt: new Date(),
    })
    .where(eq(subscriptions.userId, userId));
}

async function markPastDue(subscriptionId: string): Promise<void> {
  await db
    .update(subscriptions)
    .set({ status: 'past_due', updatedAt: new Date() })
    .where(eq(subscriptions.stripeSubscriptionId, subscriptionId));
}

function detectBillingCycle(sub: Stripe.Subscription): BillingCycle {
  const interval = sub.items.data[0]?.price.recurring?.interval;
  return interval === 'year' ? 'annual' : 'monthly';
}
