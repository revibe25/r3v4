// ─────────────────────────────────────────────────────────────────────────────
// R3 · Subscription tRPC Router
// Drop into: server/routers/subscription.ts
// Register in server/routes.ts:  subscriptionRouter
// ─────────────────────────────────────────────────────────────────────────────

import { z } from 'zod';
import {router} from '../trpc'
import { protectedProcedure } from '../procedures';;   // adjust to your trpc export
import {
  createCheckoutSession,
  createPortalSession,
  getUserSubscription,
} from '../services/stripe-subscription';
import { BILLING_CYCLES, SUBSCRIPTION_TIERS } from '../../shared/subscription.types';

export const subscriptionRouter = router({
  // ── GET current user subscription ──────────────────────────────────────────
  getMySubscription: protectedProcedure.query(async ({ ctx }) => {
    return getUserSubscription(ctx.user.id);
  }),

  // ── Create Stripe Checkout URL ──────────────────────────────────────────────
  createCheckout: protectedProcedure
    .input(
      z.object({
        tier: z.enum(['creator', 'pro_artist']),
        billingCycle: z.enum(BILLING_CYCLES),
        successPath: z.string().default('/dashboard?upgraded=true'),
        cancelPath: z.string().default('/pricing'),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const baseUrl = process.env.APP_URL ?? 'http://localhost:5173';

      const url = await createCheckoutSession({
        userId: ctx.user.id,
        email: ctx.user.email,
        name: ctx.user.name ?? undefined,
        tier: input.tier,
        billingCycle: input.billingCycle,
        successUrl: `${baseUrl}${input.successPath}`,
        cancelUrl: `${baseUrl}${input.cancelPath}`,
        trialDays: 7,
      });

      return { url };
    }),

  // ── Create Stripe Customer Portal URL ───────────────────────────────────────
  createPortal: protectedProcedure
    .input(z.object({ returnPath: z.string().default('/account') }))
    .mutation(async ({ ctx, input }) => {
      const baseUrl = process.env.APP_URL ?? 'http://localhost:5173';
      const url = await createPortalSession(ctx.user.id, `${baseUrl}${input.returnPath}`);
      return { url };
    }),
});

export type SubscriptionRouter = typeof subscriptionRouter;
