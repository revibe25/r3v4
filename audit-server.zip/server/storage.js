import { eq, desc } from "drizzle-orm";
import { db } from "./db";
import { users, sessions, projects, samples, presets, settings } from "./db/schema";
export class DatabaseStorage {
    // ==================== USER OPERATIONS ====================
    async getUser(id) {
        const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
        return result[0];
    }
    async getUserByUsername(username) {
        const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
        return result[0];
    }
    async createUser(insertUser) {
        const result = await db.insert(users).values({
            ...insertUser,
            tier: "free",
        }).returning();
        return result[0];
    }
    async updateUser(id, updates) {
        const result = await db.update(users)
            .set({
            ...updates,
            updatedAt: new Date(),
        })
            .where(eq(users.id, id))
            .returning();
        return result[0];
    }
    async deleteUser(id) {
        const result = await db.delete(users).where(eq(users.id, id)).returning();
        return result.length > 0;
    }
    // ==================== SESSION OPERATIONS ====================
    async getSessions() {
        const result = await db.select().from(sessions).orderBy(desc(sessions.createdAt));
        return result.map(this.mapSessionFromDb);
    }
    async getSession(id) {
        const result = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
        return result[0] ? this.mapSessionFromDb(result[0]) : undefined;
    }
    async createSession(insertSession) {
        const result = await db.insert(sessions).values({
            ...insertSession,
            fx: insertSession.fx,
            recordedEvents: insertSession.recordedEvents,
        }).returning();
        return this.mapSessionFromDb(result[0]);
    }
    async updateSession(id, updates) {
        const result = await db.update(sessions)
            .set({
            ...updates,
            ...(updates.fx ? { fx: updates.fx } : {}),
            ...(updates.recordedEvents ? { recordedEvents: updates.recordedEvents } : {}),
            updatedAt: new Date(),
        })
            .where(eq(sessions.id, id))
            .returning();
        return result[0] ? this.mapSessionFromDb(result[0]) : undefined;
    }
    async deleteSession(id) {
        const result = await db.delete(sessions).where(eq(sessions.id, id)).returning();
        return result.length > 0;
    }
    // ==================== PROJECT OPERATIONS ====================
    async getProjects() {
        const result = await db.select().from(projects).orderBy(desc(projects.updatedAt));
        return result.map(this.mapProjectFromDb);
    }
    async getProject(id) {
        const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
        return result[0] ? this.mapProjectFromDb(result[0]) : undefined;
    }
    async createProject(insertProject) {
        const result = await db.insert(projects).values({
            ...insertProject,
            projectData: insertProject.projectData,
        }).returning();
        return this.mapProjectFromDb(result[0]);
    }
    async updateProject(id, updates) {
        const result = await db.update(projects)
            .set({
            ...updates,
            ...(updates.projectData ? { projectData: updates.projectData } : {}),
            updatedAt: new Date(),
        })
            .where(eq(projects.id, id))
            .returning();
        return result[0] ? this.mapProjectFromDb(result[0]) : undefined;
    }
    async deleteProject(id) {
        const result = await db.delete(projects).where(eq(projects.id, id)).returning();
        return result.length > 0;
    }
    // ==================== SAMPLE OPERATIONS ====================
    async getSamples() {
        const result = await db.select().from(samples).orderBy(desc(samples.createdAt));
        return result.map(this.mapSampleFromDb);
    }
    async getSample(id) {
        const result = await db.select().from(samples).where(eq(samples.id, id)).limit(1);
        return result[0] ? this.mapSampleFromDb(result[0]) : undefined;
    }
    async getSamplesByTags(searchTags) {
        const result = await db.select().from(samples);
        return result
            .filter((sample) => {
            const sampleTags = sample.tags || [];
            return searchTags.some((tag) => sampleTags.includes(tag));
        })
            .map(this.mapSampleFromDb);
    }
    async createSample(insertSample) {
        const result = await db.insert(samples).values({
            ...insertSample,
            tags: insertSample.tags,
            waveformData: insertSample.waveformData,
        }).returning();
        return this.mapSampleFromDb(result[0]);
    }
    async updateSample(id, updates) {
        const result = await db.update(samples)
            .set({
            ...updates,
            ...(updates.tags ? { tags: updates.tags } : {}),
            ...(updates.waveformData ? { waveformData: updates.waveformData } : {}),
            updatedAt: new Date(),
        })
            .where(eq(samples.id, id))
            .returning();
        return result[0] ? this.mapSampleFromDb(result[0]) : undefined;
    }
    async deleteSample(id) {
        const result = await db.delete(samples).where(eq(samples.id, id)).returning();
        return result.length > 0;
    }
    // ==================== PRESET OPERATIONS ====================
    async getPresets(type) {
        if (type) {
            const result = await db.select().from(presets)
                .where(eq(presets.type, type))
                .orderBy(desc(presets.updatedAt));
            return result.map(this.mapPresetFromDb);
        }
        const result = await db.select().from(presets).orderBy(desc(presets.updatedAt));
        return result.map(this.mapPresetFromDb);
    }
    async getPreset(id) {
        const result = await db.select().from(presets).where(eq(presets.id, id)).limit(1);
        return result[0] ? this.mapPresetFromDb(result[0]) : undefined;
    }
    async createPreset(insertPreset) {
        const result = await db.insert(presets).values({
            ...insertPreset,
            presetData: insertPreset.presetData,
            tags: insertPreset.tags,
        }).returning();
        return this.mapPresetFromDb(result[0]);
    }
    async updatePreset(id, updates) {
        const result = await db.update(presets)
            .set({
            ...updates,
            ...(updates.presetData ? { presetData: updates.presetData } : {}),
            ...(updates.tags ? { tags: updates.tags } : {}),
            updatedAt: new Date(),
        })
            .where(eq(presets.id, id))
            .returning();
        return result[0] ? this.mapPresetFromDb(result[0]) : undefined;
    }
    async deletePreset(id) {
        const result = await db.delete(presets).where(eq(presets.id, id)).returning();
        return result.length > 0;
    }
    // ==================== SETTINGS OPERATIONS ====================
    async getSettings(userId) {
        const result = userId
            ? await db.select().from(settings).where(eq(settings.userId, userId)).limit(1)
            : await db.select().from(settings).limit(1);
        if (result.length === 0) {
            const defaultSettings = {
                userId: userId ?? null,
                audioBufferSize: 2048,
                sampleRate: 48000,
                bitDepth: 24,
                midiEnabled: true,
                audioInputDevice: "default",
                audioOutputDevice: "default",
                theme: "dark",
                autoSave: true,
                autoSaveInterval: 300000,
                masterVolume: 0.8,
                metronomeEnabled: false,
                metronomeBpm: 120,
                metronomeVolume: 0.5,
            };
            const created = await db.insert(settings).values(defaultSettings).returning();
            return this.mapSettingsFromDb(created[0]);
        }
        return this.mapSettingsFromDb(result[0]);
    }
    async updateSettings(updates, userId) {
        const existing = userId
            ? await db.select().from(settings).where(eq(settings.userId, userId)).limit(1)
            : await db.select().from(settings).limit(1);
        let result;
        if (existing.length === 0) {
            result = await db.insert(settings).values({
                userId: userId ?? null,
                ...updates,
            }).returning();
        }
        else {
            result = await db.update(settings)
                .set({
                ...updates,
                updatedAt: new Date(),
            })
                .where(eq(settings.id, existing[0].id))
                .returning();
        }
        return this.mapSettingsFromDb(result[0]);
    }
    // ==================== HELPER METHODS ====================
    mapSessionFromDb(dbSession) {
        return {
            ...dbSession,
            fx: dbSession.fx,
            recordedEvents: dbSession.recordedEvents,
        };
    }
    mapProjectFromDb(dbProject) {
        return {
            ...dbProject,
            projectData: dbProject.projectData,
        };
    }
    mapSampleFromDb(dbSample) {
        return {
            ...dbSample,
            tags: dbSample.tags,
            waveformData: dbSample.waveformData,
        };
    }
    mapPresetFromDb(dbPreset) {
        return {
            ...dbPreset,
            presetData: dbPreset.presetData,
            tags: dbPreset.tags,
        };
    }
    mapSettingsFromDb(dbSettings) {
        return { ...dbSettings };
    }
}
// Export singleton instance
export const storage = new DatabaseStorage();
