import { publicProc } from './trpc';
import { attachSubscription } from './middleware/feature-gate';

// protectedProcedure is defined here (not in trpc.ts) to avoid
// the circular dependency: trpc.ts → feature-gate.ts → trpc.ts
export const protectedProcedure = publicProc.use(attachSubscription);
