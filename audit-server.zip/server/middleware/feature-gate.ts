// ─────────────────────────────────────────────────────────────────────────────
// R3 · Feature Gate Middleware
// Drop into: server/middleware/feature-gate.ts
//
// Usage in tRPC procedures:
//   .use(requireTier('creator'))
//   .use(requireFeature('stemSeparation'))
//   .use(checkAiTransitionLimit)
// ─────────────────────────────────────────────────────────────────────────────

import { TRPCError } from '@trpc/server';
import { middleware } from '../trpc';
import { getUserSubscription } from '../services/stripe-subscription';
import {
  SubscriptionTier,
  TierFeatures,
  tierAtLeast,
  canUseFeature,
  TIER_DEFINITIONS,
} from '../../shared/subscription.types';
import { db } from '../db';
import { aiTransitionUsage } from '../../shared/schema-subscription';
import { eq, and, count } from 'drizzle-orm';

// ── Attach subscription to tRPC context ──────────────────────────────────────
// Add to your root middleware chain so ctx.subscription is always available.
// Unauthenticated users receive subscription: null → treated as 'explorer' downstream.

export const attachSubscription = middleware(async ({ ctx, next }) => {
  if (!ctx.user?.id) {
    return next({ ctx: { ...ctx, subscription: null } });
  }

  const subscription = await getUserSubscription(ctx.user.id);
  return next({ ctx: { ...ctx, subscription } });
});

// ── Require minimum tier ──────────────────────────────────────────────────────

export function requireTier(required: SubscriptionTier) {
  return middleware(async ({ ctx, next }) => {
    const tier: SubscriptionTier = ctx.subscription?.tier ?? 'explorer';

    if (!tierAtLeast(tier, required)) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: JSON.stringify({
          type: 'UPGRADE_REQUIRED',
          userTier: tier,
          requiredTier: required,
          requiredTierDisplay: TIER_DEFINITIONS[required].displayName,
          upgradeUrl: '/pricing',
          message: `This feature requires ${TIER_DEFINITIONS[required].displayName} or above.`,
        }),
      });
    }

    return next();
  });
}

// ── Require specific feature ──────────────────────────────────────────────────

export function requireFeature(feature: keyof TierFeatures) {
  return middleware(async ({ ctx, next }) => {
    const tier: SubscriptionTier = ctx.subscription?.tier ?? 'explorer';

    if (!canUseFeature(tier, feature)) {
      const tiers: SubscriptionTier[] = ['explorer', 'creator', 'pro_artist'];
      const requiredTier = tiers.find((t) => canUseFeature(t, feature)) ?? 'pro_artist';

      throw new TRPCError({
        code: 'FORBIDDEN',
        message: JSON.stringify({
          type: 'FEATURE_GATED',
          feature,
          userTier: tier,
          requiredTier,
          requiredTierDisplay: TIER_DEFINITIONS[requiredTier].displayName,
          upgradeUrl: '/pricing',
          message: `Upgrade to ${TIER_DEFINITIONS[requiredTier].displayName} to unlock this feature.`,
        }),
      });
    }

    return next();
  });
}

// ── AI transition rate limiter ────────────────────────────────────────────────
// Explorer: capped per session (DB-tracked for authenticated, in-memory skipped for guests)
// Creator / Pro Artist: unlimited
//
// FIX: original used ctx.user!.id (non-null assertion) which crashed for
// unauthenticated users whose subscription is null. Guests are treated as
// explorer-tier and bypass DB tracking (no userId to key on); the session
// cap still applies via sessionId alone.

export const checkAiTransitionLimit = middleware(async ({ ctx, next }) => {
  const tier: SubscriptionTier = ctx.subscription?.tier ?? 'explorer';
  const limit = TIER_DEFINITIONS[tier].limits.aiTransitionsPerSession;

  // Unlimited tier — skip all counting
  if (limit === 'unlimited') return next();

  const sessionId = ctx.sessionId as string | undefined;

  // No sessionId in context — can't enforce; let it through rather than crash
  if (!sessionId) return next();

  const userId: string | undefined = ctx.user?.id;

  if (userId) {
    // ── Authenticated path: enforce via DB ──────────────────────────────────
    const [usage] = await db
      .select({ total: count() })
      .from(aiTransitionUsage)
      .where(
        and(
          eq(aiTransitionUsage.userId, userId),
          eq(aiTransitionUsage.sessionId, sessionId),
        ),
      );

    const used = Number(usage?.total ?? 0);

    if (used >= (limit as number)) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: JSON.stringify({
          type: 'LIMIT_REACHED',
          limitType: 'aiTransitionsPerSession',
          used,
          limit,
          userTier: tier,
          requiredTier: 'creator',
          upgradeUrl: '/pricing',
          message: `You've used all ${limit} AI transitions for this session. Upgrade to Creator for unlimited.`,
        }),
      });
    }

    // Record usage after the procedure succeeds
    const result = await next();

    await db.insert(aiTransitionUsage).values({
      id: crypto.randomUUID(),
      userId,
      sessionId,
    });

    return result;
  } else {
    // ── Guest path: no DB record (nothing to key on) ────────────────────────
    // Guests are explorer-tier by definition. We can't persistently track
    // them without a userId, so we let the request through. If you need
    // guest enforcement, add an in-memory or Redis TTL counter keyed on
    // sessionId here.
    return next();
  }
});

// ── Track upload limit check (call before file save) ─────────────────────────

export async function assertTrackUploadAllowed(
  currentTrackCount: number,
  tier: SubscriptionTier,
): Promise<void> {
  const limit = TIER_DEFINITIONS[tier].limits.trackUploads;
  if (limit === 'unlimited') return;

  if (currentTrackCount >= (limit as number)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: JSON.stringify({
        type: 'LIMIT_REACHED',
        limitType: 'trackUploads',
        used: currentTrackCount,
        limit,
        userTier: tier,
        requiredTier: 'creator',
        upgradeUrl: '/pricing',
        message: `You've reached your ${limit}-track limit. Upgrade to Creator for up to 200 tracks.`,
      }),
    });
  }
}