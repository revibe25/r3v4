import { initTRPC } from '@trpc/server';
export function createContext({ req, res }) {
    return { req, res };
}
const t = initTRPC.context().create();
export const router = t.router;
export const publicProc = t.procedure;
