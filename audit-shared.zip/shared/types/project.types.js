// shared/types/project.types.ts
export {};
