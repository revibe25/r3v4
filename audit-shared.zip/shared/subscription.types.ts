// ─────────────────────────────────────────────────────────────────────────────
// R3 · Subscription Types
// Drop into: shared/subscription.types.ts
// ─────────────────────────────────────────────────────────────────────────────

export const SUBSCRIPTION_TIERS = ['explorer', 'creator', 'pro_artist'] as const;
export type SubscriptionTier = (typeof SUBSCRIPTION_TIERS)[number];

export const BILLING_CYCLES = ['monthly', 'annual'] as const;
export type BillingCycle = (typeof BILLING_CYCLES)[number];

export const SUBSCRIPTION_STATUSES = [
  'active',
  'trialing',
  'past_due',
  'canceled',
  'incomplete',
  'paused',
] as const;
export type SubscriptionStatus = (typeof SUBSCRIPTION_STATUSES)[number];

// ── Tier config ──────────────────────────────────────────────────────────────

export interface TierLimits {
  trackUploads: number | 'unlimited';        // max stored tracks
  savedProjects: number | 'unlimited';
  recordingMinutes: number | 'unlimited';    // per recording
  aiTransitionsPerSession: number | 'unlimited';
  supportedFormats: ('mp3' | 'wav' | 'flac')[];
  exportFormats: ('mp3_320' | 'wav' | 'flac')[];
}

export interface TierFeatures {
  energyCurveAnalysis: boolean;
  keyCompatibility: boolean;
  aiMixDashboard: boolean;
  aiAutomixMode: boolean;
  transitionGraphEditor: boolean;
  effectsLibrary: 'basic' | 'full' | 'full_plus_custom';
  effectsPresets: boolean;
  effectsChainStacking: boolean;
  stemSeparation: boolean;
  rekordboxImport: boolean;
  seratolImport: boolean;
  projectSharing: boolean;
  sampleLibrary: 'starter' | 'full' | 'full_priority';
  tutorialLibrary: 'basic' | 'full';
  earlyAccess: boolean;
  support: 'community' | 'email_48h' | 'email_24h';
}

export interface TierDefinition {
  id: SubscriptionTier;
  displayName: string;
  tagline: string;
  monthlyPriceCents: number;   // 0 for free
  annualPriceCents: number;    // per month, billed annually
  stripePriceIdMonthly: string | null;
  stripePriceIdAnnual: string | null;
  limits: TierLimits;
  features: TierFeatures;
  color: string;
  badge?: string;
}

// ── Tier definitions (single source of truth) ────────────────────────────────

export const TIER_DEFINITIONS: Record<SubscriptionTier, TierDefinition> = {
  explorer: {
    id: 'explorer',
    displayName: 'Explorer',
    tagline: 'Start your journey — free forever',
    monthlyPriceCents: 0,
    annualPriceCents: 0,
    stripePriceIdMonthly: null,
    stripePriceIdAnnual: null,
    color: '#3A7D44',
    limits: {
      trackUploads: 10,
      savedProjects: 1,
      recordingMinutes: 0,
      aiTransitionsPerSession: 3,
      supportedFormats: ['mp3'],
      exportFormats: [],
    },
    features: {
      energyCurveAnalysis: false,
      keyCompatibility: false,
      aiMixDashboard: false,
      aiAutomixMode: false,
      transitionGraphEditor: false,
      effectsLibrary: 'basic',
      effectsPresets: false,
      effectsChainStacking: false,
      stemSeparation: false,
      rekordboxImport: false,
      seratolImport: false,
      projectSharing: false,
      sampleLibrary: 'starter',
      tutorialLibrary: 'basic',
      earlyAccess: false,
      support: 'community',
    },
  },

  creator: {
    id: 'creator',
    displayName: 'Creator',
    tagline: 'Your full creative studio',
    monthlyPriceCents: 1000,
    annualPriceCents: 800,
    stripePriceIdMonthly: '',
    stripePriceIdAnnual: '',
    color: '#1A3C5E',
    badge: 'Most Popular',
    limits: {
      trackUploads: 200,
      savedProjects: 25,
      recordingMinutes: 60,
      aiTransitionsPerSession: 'unlimited',
      supportedFormats: ['mp3', 'wav', 'flac'],
      exportFormats: ['mp3_320'],
    },
    features: {
      energyCurveAnalysis: true,
      keyCompatibility: true,
      aiMixDashboard: true,
      aiAutomixMode: false,
      transitionGraphEditor: false,
      effectsLibrary: 'full',
      effectsPresets: true,
      effectsChainStacking: true,
      stemSeparation: false,
      rekordboxImport: false,
      seratolImport: false,
      projectSharing: false,
      sampleLibrary: 'full',
      tutorialLibrary: 'full',
      earlyAccess: false,
      support: 'email_48h',
    },
  },

  pro_artist: {
    id: 'pro_artist',
    displayName: 'Pro Artist',
    tagline: 'Perform without limits',
    monthlyPriceCents: 2500,
    annualPriceCents: 2000,
    stripePriceIdMonthly: '',
    stripePriceIdAnnual: '',
    color: '#B35A00',
    limits: {
      trackUploads: 'unlimited',
      savedProjects: 'unlimited',
      recordingMinutes: 'unlimited',
      aiTransitionsPerSession: 'unlimited',
      supportedFormats: ['mp3', 'wav', 'flac'],
      exportFormats: ['mp3_320', 'wav', 'flac'],
    },
    features: {
      energyCurveAnalysis: true,
      keyCompatibility: true,
      aiMixDashboard: true,
      aiAutomixMode: true,
      transitionGraphEditor: true,
      effectsLibrary: 'full_plus_custom',
      effectsPresets: true,
      effectsChainStacking: true,
      stemSeparation: true,
      rekordboxImport: true,
      seratolImport: true,
      projectSharing: true,
      sampleLibrary: 'full_priority',
      tutorialLibrary: 'full',
      earlyAccess: true,
      support: 'email_24h',
    },
  },
};

// ── Helper utilities ─────────────────────────────────────────────────────────

export function getTierDefinition(tier: SubscriptionTier): TierDefinition {
  return TIER_DEFINITIONS[tier];
}

export function tierAtLeast(userTier: SubscriptionTier, required: SubscriptionTier): boolean {
  const order: SubscriptionTier[] = ['explorer', 'creator', 'pro_artist'];
  return order.indexOf(userTier) >= order.indexOf(required);
}

export function canUseFeature(
  userTier: SubscriptionTier,
  feature: keyof TierFeatures,
): boolean {
  return !!TIER_DEFINITIONS[userTier].features[feature];
}

export function checkLimit(
  userTier: SubscriptionTier,
  limit: keyof TierLimits,
  currentUsage: number,
): { allowed: boolean; limit: number | 'unlimited'; remaining: number | 'unlimited' } {
  const def = TIER_DEFINITIONS[userTier].limits[limit];
  if (def === 'unlimited') return { allowed: true, limit: 'unlimited', remaining: 'unlimited' };
  const numericLimit = def as number;
  return {
    allowed: currentUsage < numericLimit,
    limit: numericLimit,
    remaining: Math.max(0, numericLimit - currentUsage),
  };
}

// ── User subscription state (returned from API) ──────────────────────────────

export interface UserSubscription {
  tier: SubscriptionTier;
  status: SubscriptionStatus;
  billingCycle: BillingCycle | null;
  currentPeriodEnd: Date | null;
  cancelAtPeriodEnd: boolean;
  trialEnd: Date | null;
  stripeCustomerId: string | null;
}

export interface SubscriptionGateResult {
  allowed: boolean;
  requiredTier: SubscriptionTier;
  userTier: SubscriptionTier;
  upgradeUrl: string;
  message: string;
}
