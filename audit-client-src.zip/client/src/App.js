import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// client/src/App.tsx
//
// ─── ARCHITECTURE NOTES ──────────────────────────────────────────────────────
//
//  PROBLEM (original):
//    1. VSTProvider wrapped the ENTIRE app — every page blocked until an audio
//       context gesture fired, showing a full-screen spinner even on /instrument.
//    2. All VST audio classes (VSTPerformanceMonitor, SidechainRouter, etc.)
//       were static top-level imports → landed in the main 626 KB bundle.
//    3. InstrumentPage was eagerly imported → couldn't be split out.
//
//  FIXES:
//    1. VSTProvider now only wraps the /vst route. Every other route loads
//       instantly without touching the audio subsystem.
//    2. All VST audio classes are type-only imports at the top; the actual
//       modules are loaded via dynamic import() inside VSTProvider's useEffect.
//    3. InstrumentPage, NotFound, and every page use React.lazy().
//    4. A single shared <AppShell> wraps providers that ALL routes need
//       (QueryClient, Theme, Tooltip, Toaster) — no redundant nesting.
//    5. ErrorBoundary is extracted to its own module-level class so it is never
//       recreated on render.
//    6. useVSTContextOptional() exported for components that live outside
//       VSTProvider but have optional VST integration (e.g. MultiTrackPanel).
//
// ─────────────────────────────────────────────────────────────────────────────
import { lazy, Suspense, useState, useEffect, useRef, createContext, useContext, Component, } from 'react';
import { Switch, Route } from 'wouter';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { PageNav } from '@/components/page-nav';
import { ThemeProvider } from '@/components/theme-provider';
// ─── LAZY PAGES ───────────────────────────────────────────────────────────────
const InstrumentPage = lazy(() => import('@/pages/instrument'));
const NotFound = lazy(() => import('@/pages/not-found'));
const MultiTrackPanel = lazy(() => import('@/components/multi-track-panel'));
const VSTMasterPanel = lazy(() => import('@/components/vst-master-panel'));
const LoopStation505 = lazy(() => import('@/features/loopstation/LoopStation505').then(m => ({
    default: m.LoopStation505,
})));
class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }
    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }
    componentDidCatch(error, info) {
        console.error('[ErrorBoundary]', error, info);
    }
    render() {
        if (this.state.hasError) {
            return (this.props.fallback ?? (_jsx("div", { className: "flex items-center justify-center h-screen bg-[#060606] text-[#f0f0f0] font-mono", children: _jsxs("div", { className: "text-center max-w-md", children: [_jsx("div", { className: "text-red-500 text-6xl mb-4", children: "\u26A0\uFE0F" }), _jsx("h2", { className: "text-2xl font-bold mb-2", children: "Failed to Load Component" }), _jsx("p", { className: "text-sm text-muted-foreground mb-4", children: this.state.error?.message ?? 'An unexpected error occurred.' }), _jsx("button", { onClick: () => window.location.reload(), className: "px-4 py-2 bg-[#a3e635] hover:bg-[#84cc16] text-[#060606]\n                           rounded-none font-mono text-xs tracking-widest uppercase transition-colors", children: "Reload Page" })] }) })));
        }
        return this.props.children;
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// LOADING FALLBACKS
// ─────────────────────────────────────────────────────────────────────────────
function LoadingFallback({ message }) {
    return (_jsx("div", { className: "flex items-center justify-center h-screen bg-[#060606] text-[#f0f0f0] font-mono", children: _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-[#a3e635] mx-auto mb-4" }), _jsx("p", { className: "text-sm tracking-wider", children: message })] }) }));
}
function PanelFallback({ message }) {
    return (_jsx("div", { className: "flex items-center justify-center h-64 text-[#f0f0f0] font-mono", children: _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "animate-spin rounded-full h-8 w-8 border-b-2 border-[#a3e635] mx-auto mb-3" }), _jsx("p", { className: "text-xs tracking-wider text-[#888]", children: message })] }) }));
}
const VSTContext = createContext(null);
/**
 * Strict hook — throws if called outside VSTProvider.
 * Use inside /vst route components only.
 */
export function useVSTContext() {
    const ctx = useContext(VSTContext);
    if (!ctx)
        throw new Error('useVSTContext must be used within <VSTProvider>');
    return ctx;
}
/**
 * Optional hook — returns null when called outside VSTProvider.
 * Safe to use in components that live on routes without VSTProvider
 * (e.g. MultiTrackPanel on /multitrack). Always null-check the result.
 */
export function useVSTContextOptional() {
    return useContext(VSTContext);
}
// ─────────────────────────────────────────────────────────────────────────────
// VST PROVIDER
// ─────────────────────────────────────────────────────────────────────────────
function VSTProvider({ children }) {
    const [vstSystem, setVstSystem] = useState(null);
    const [initError, setInitError] = useState(null);
    const bootedRef = useRef(false);
    useEffect(() => {
        if (bootedRef.current)
            return;
        bootedRef.current = true;
        const channelsMap = new Map();
        const initAudio = async () => {
            const [{ VSTPerformanceMonitor }, { SidechainRouter }, { VSTAutomationEngine }, { getAudioContext }, { MixerChannel },] = await Promise.all([
                import('@/audio/fx/vst-performance-monitor'),
                import('@/audio/fx/vst-sidechain'),
                import('@/audio/fx/vst-automation-engine'),
                import('@/audio/core/audio-context'),
                import('@/audio/mixer/mixer-channel'),
            ]);
            const audioContext = await getAudioContext();
            const system = {
                performanceMonitor: new VSTPerformanceMonitor(audioContext),
                sidechainRouter: new SidechainRouter(audioContext),
                automationEngine: new VSTAutomationEngine(audioContext),
                audioContext,
                channels: [],
                addChannel(id) {
                    if (channelsMap.has(id))
                        return channelsMap.get(id);
                    const ch = new MixerChannel(id);
                    channelsMap.set(id, ch);
                    setVstSystem(prev => prev ? { ...prev, channels: Array.from(channelsMap.values()) } : null);
                    return ch;
                },
                removeChannel(id) {
                    const ch = channelsMap.get(id);
                    if (ch) {
                        ch.dispose();
                        channelsMap.delete(id);
                        setVstSystem(prev => prev ? { ...prev, channels: Array.from(channelsMap.values()) } : null);
                    }
                },
                getChannel: id => channelsMap.get(id),
            };
            setVstSystem(system);
            channelsMap.__system = system;
        };
        const onGesture = () => {
            initAudio().catch(err => {
                console.error('[VSTProvider] Audio init failed:', err);
                setInitError(err?.message ?? 'Audio initialization failed.');
            });
            document.removeEventListener('click', onGesture);
            document.removeEventListener('keydown', onGesture);
        };
        document.addEventListener('click', onGesture);
        document.addEventListener('keydown', onGesture);
        return () => {
            document.removeEventListener('click', onGesture);
            document.removeEventListener('keydown', onGesture);
            const system = channelsMap.__system;
            if (system) {
                system.performanceMonitor.dispose();
                system.sidechainRouter.dispose();
                system.automationEngine.dispose();
            }
            channelsMap.forEach(ch => ch.dispose());
            channelsMap.clear();
        };
    }, []);
    if (initError) {
        return (_jsx("div", { className: "flex items-center justify-center h-screen bg-[#060606] text-[#f0f0f0] font-mono", children: _jsxs("div", { className: "text-center max-w-md", children: [_jsx("div", { className: "text-red-500 text-5xl mb-4", children: "\u26A0\uFE0F" }), _jsx("h2", { className: "text-xl font-bold mb-2", children: "Audio Engine Error" }), _jsx("p", { className: "text-sm text-red-400 mb-4", children: initError }), _jsx("button", { onClick: () => window.location.reload(), className: "px-4 py-2 bg-[#a3e635] hover:bg-[#84cc16] text-[#060606]\n                       rounded-none font-mono text-xs tracking-widest uppercase transition-colors", children: "Retry" })] }) }));
    }
    if (!vstSystem) {
        return (_jsx("div", { className: "flex items-center justify-center h-screen bg-[#060606] text-[#f0f0f0] font-mono", children: _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-[#a3e635] mx-auto mb-4" }), _jsx("p", { className: "text-sm tracking-wider", children: "Initializing VST Engine\u2026" }), _jsx("p", { className: "text-xs tracking-wider text-[#666] mt-2", children: "Click or press any key to activate audio" })] }) }));
    }
    return _jsx(VSTContext.Provider, { value: vstSystem, children: children });
}
// ─────────────────────────────────────────────────────────────────────────────
// VST MANAGER PAGE
// ─────────────────────────────────────────────────────────────────────────────
function VSTManagerPage() {
    const vstContext = useVSTContext();
    const [loadError, setLoadError] = useState(null);
    const [saveStatus, setSaveStatus] = useState('idle');
    const handleProjectSave = async () => {
        setSaveStatus('saving');
        try {
            const { VSTProjectSerializer } = await import('@/audio/fx/vst-project-serializer');
            const { FXChain } = await import('@/audio/fx/fx-chain');
            const chainMap = new Map();
            vstContext.channels.forEach(ch => chainMap.set(ch.id, ch.fxChain));
            const data = VSTProjectSerializer.serializeProject(chainMap, vstContext.sidechainRouter, vstContext.audioContext);
            VSTProjectSerializer.createBackup(data, `auto-${Date.now()}`);
            setSaveStatus('saved');
            setTimeout(() => setSaveStatus('idle'), 2000);
            return data;
        }
        catch (err) {
            console.error('[VSTManagerPage] Save failed:', err);
            setSaveStatus('error');
            throw err;
        }
    };
    const handleProjectLoad = async (data) => {
        setLoadError(null);
        if (!data?.version || !Array.isArray(data?.chains)) {
            const msg = 'Invalid project file: missing "version" or "chains".';
            setLoadError(msg);
            throw new Error(msg);
        }
        const { VSTProjectSerializer } = await import('@/audio/fx/vst-project-serializer');
        const { FXChain } = await import('@/audio/fx/fx-chain');
        try {
            const chainMap = new Map();
            vstContext.channels.forEach(ch => chainMap.set(ch.id, ch.fxChain));
            const snapshot = VSTProjectSerializer.serializeProject(chainMap, vstContext.sidechainRouter, vstContext.audioContext);
            VSTProjectSerializer.createBackup(snapshot, `pre-load-${Date.now()}`);
        }
        catch (backupErr) {
            console.warn('[VSTManagerPage] Pre-load backup failed:', backupErr);
        }
        vstContext.channels.map(ch => ch.id).forEach(id => vstContext.removeChannel(id));
        for (const chainData of data.chains) {
            const ch = vstContext.addChannel(chainData.channelId);
            if (chainData.volume != null)
                ch.setVolume(chainData.volume);
            if (chainData.pan != null)
                ch.setPan(chainData.pan);
            if (chainData.muted != null)
                ch.setMute(chainData.muted);
            if (chainData.solo != null)
                ch.setSolo(chainData.solo);
            if (chainData.armed != null)
                ch.setArmed(chainData.armed);
            if (chainData.name)
                ch.setName(chainData.name);
        }
        try {
            const restoredChains = await VSTProjectSerializer.deserializeProject(data, vstContext.audioContext);
            restoredChains.forEach((fxChain, channelId) => {
                const ch = vstContext.getChannel(channelId);
                if (!ch)
                    return;
                ch.clearFX();
                fxChain.getAllEffects().forEach(fx => ch.addFX(fx));
            });
        }
        catch (fxErr) {
            const warning = 'Project loaded with warnings: one or more FX plugins could not be restored.';
            console.error('[VSTManagerPage] FX restore error:', fxErr);
            setLoadError(warning);
        }
        if (Array.isArray(data.sidechains) && data.sidechains.length > 0) {
            vstContext.sidechainRouter.getAllConnections().forEach(conn => {
                try {
                    vstContext.sidechainRouter.removeConnection(conn.id);
                }
                catch (_) { }
            });
            data.sidechains.forEach((config) => {
                try {
                    const sourceCh = vstContext.getChannel(config.sourceChannelId);
                    if (!sourceCh) {
                        console.warn('[VSTManagerPage] Sidechain: source not found:', config.sourceChannelId);
                        return;
                    }
                    const targetCh = vstContext.getChannel(config.targetChannelId ?? config.sourceChannelId);
                    const targetVST = targetCh?.getVSTPlugins().find(v => v.id === config.targetVSTId);
                    if (!targetVST) {
                        console.warn('[VSTManagerPage] Sidechain: target VST not found:', config.targetVSTId);
                        return;
                    }
                    vstContext.sidechainRouter.createSidechain(config, sourceCh.output, targetVST);
                }
                catch (e) {
                    console.warn('[VSTManagerPage] Sidechain restore skipped:', config, e);
                }
            });
        }
    };
    return (_jsxs("div", { className: "min-h-screen bg-[#060606] text-[#f0f0f0] font-mono", children: [_jsx(PageNav, {}), _jsxs("div", { className: "container mx-auto p-6", children: [_jsxs("div", { className: "mb-6", children: [_jsx("h1", { className: "text-xl font-bold flex items-center gap-2 tracking-widest uppercase text-[#a3e635]", children: "\uD83D\uDD0C VST Plugin Manager" }), _jsx("p", { className: "text-[#888] mt-2 text-xs tracking-wider", children: "Manage your VST plugins, performance monitoring, and routing" }), saveStatus === 'saving' && (_jsx("p", { className: "mt-2 text-xs text-[#888] tracking-wider", children: "Saving\u2026" })), saveStatus === 'saved' && (_jsx("p", { className: "mt-2 text-xs text-[#a3e635] tracking-wider", children: "\u2713 Project saved & backed up" })), saveStatus === 'error' && (_jsx("p", { className: "mt-2 text-xs text-red-400 tracking-wider", children: "\u2717 Save failed \u2014 check console" })), loadError && (_jsxs("div", { className: "mt-3 flex items-start gap-2 rounded-none border border-yellow-500/40\n                            bg-yellow-500/10 px-3 py-2 text-xs text-yellow-300 tracking-wider", children: [_jsx("span", { children: "\u26A0" }), _jsx("span", { className: "flex-1", children: loadError }), _jsx("button", { onClick: () => setLoadError(null), className: "text-yellow-400 hover:text-yellow-200", "aria-label": "Dismiss warning", children: "\u2715" })] }))] }), _jsx(ErrorBoundary, { children: _jsx(Suspense, { fallback: _jsx(PanelFallback, { message: "Loading VST Master Panel\u2026" }), children: _jsx(VSTMasterPanel, { performanceMonitor: vstContext.performanceMonitor, sidechainRouter: vstContext.sidechainRouter, automationEngine: vstContext.automationEngine, channels: vstContext.channels, onProjectSave: handleProjectSave, onProjectLoad: handleProjectLoad }) }) })] })] }));
}
// ─────────────────────────────────────────────────────────────────────────────
// ROUTE PAGE SHELLS
// ─────────────────────────────────────────────────────────────────────────────
/**
 * MultiTrackPage — full-bleed shell for the DAW.
 *
 * No PageNav or container wrapper here — MultiTrackPanel is a fully
 * self-contained full-screen application that owns its own navigation,
 * header, and layout. Adding a wrapper here caused:
 *   • A duplicate nav bar (MultiTrackPanel renders its own PageNav)
 *   • A white border line from container padding bleeds
 *
 * The panel renders flush to the viewport edges with its own ag-daw-shell.
 */
function MultiTrackPage() {
    return (_jsx(ErrorBoundary, { children: _jsx(Suspense, { fallback: _jsx(LoadingFallback, { message: "Loading MultiTrack DAW\u2026" }), children: _jsx(MultiTrackPanel, {}) }) }));
}
function LoopStationPage() {
    return (_jsxs("div", { className: "min-h-screen bg-[#060606] text-[#f0f0f0] font-mono flex flex-col", children: [_jsx(PageNav, {}), _jsx("div", { className: "flex-1 flex items-start justify-center p-6 overflow-auto", children: _jsx("div", { className: "w-full max-w-5xl", children: _jsx(ErrorBoundary, { children: _jsx(Suspense, { fallback: _jsx(PanelFallback, { message: "Loading Loop Station\u2026" }), children: _jsx(LoopStation505, {}) }) }) }) })] }));
}
function VSTRoute() {
    return (_jsx(ErrorBoundary, { children: _jsx(VSTProvider, { children: _jsx(VSTManagerPage, {}) }) }));
}
// ─────────────────────────────────────────────────────────────────────────────
// ROUTER
// ─────────────────────────────────────────────────────────────────────────────
function Router() {
    return (_jsxs(Switch, { children: [_jsx(Route, { path: "/", children: () => (_jsx(ErrorBoundary, { children: _jsx(Suspense, { fallback: _jsx(LoadingFallback, { message: "Loading Instrument\u2026" }), children: _jsx(InstrumentPage, {}) }) })) }), _jsx(Route, { path: "/multitrack", children: () => _jsx(MultiTrackPage, {}) }), _jsx(Route, { path: "/vst", children: () => _jsx(VSTRoute, {}) }), _jsx(Route, { path: "/loopstation", children: () => _jsx(LoopStationPage, {}) }), _jsx(Route, { children: () => (_jsx(Suspense, { fallback: null, children: _jsx(NotFound, {}) })) })] }));
}
// ─────────────────────────────────────────────────────────────────────────────
// APP SHELL
// ─────────────────────────────────────────────────────────────────────────────
function App() {
    return (_jsx(QueryClientProvider, { client: queryClient, children: _jsx(ThemeProvider, { children: _jsxs(TooltipProvider, { children: [_jsx(Toaster, {}), _jsx(Router, {})] }) }) }));
}
export default App;
