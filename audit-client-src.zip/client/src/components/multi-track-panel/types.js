// types.ts - Centralized type definitions for the multi-track DAW
export {};
