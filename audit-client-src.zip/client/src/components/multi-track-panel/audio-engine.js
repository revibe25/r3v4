// REPLACEMENT for multi-track-panel/audio-engine.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Uses the singleton AudioContext instead of creating its own.
// ─────────────────────────────────────────────────────────────────────────────
import { getAudioContext } from '@/audio/core/audio-context';
export class AudioEngine {
    context = null;
    trackNodes = new Map();
    cleanup() {
        // Disconnect and close any AudioContext / nodes you opened
        try {
            this.audioContext?.close();
        }
        catch (_) { /* already closed */ }
    }
    async initialize() {
        // Use singleton — NOT getAudioContext()
        this.context = await getAudioContext();
        return this.context;
    }
    createAnalyserNode(trackId) {
        if (!this.context)
            return null;
        const analyser = this.context.createAnalyser();
        analyser.fftSize = 2048;
        analyser.smoothingTimeConstant = 0.8;
        return analyser;
    }
    createGainNode(initialValue = 1) {
        if (!this.context)
            return null;
        const gain = this.context.createGain();
        gain.gain.value = initialValue;
        return gain;
    }
    // ── Track management ────────────────────────────────────────────
    setupTrack(trackId) {
        if (!this.context)
            return null;
        if (this.trackNodes.has(trackId))
            return this.trackNodes.get(trackId);
        const gain = this.context.createGain();
        const analyser = this.context.createAnalyser();
        analyser.fftSize = 2048;
        gain.connect(analyser);
        analyser.connect(this.context.destination);
        const nodes = { gain, analyser };
        this.trackNodes.set(trackId, nodes);
        return nodes;
    }
    getTrackNodes(trackId) {
        return this.trackNodes.get(trackId) ?? null;
    }
}
// Export as singleton — one engine instance for the whole app
export const audioEngine = new AudioEngine();
export default AudioEngine;
