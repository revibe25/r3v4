import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// components/MixerView.tsx - Professional mixer interface
import { useCallback } from 'react';
import { Volume2, Circle } from 'lucide-react';
import { AdvancedMeter } from './advanced-meter';
import { FX_ICONS } from '../constants';
export const MixerView = ({ tracks, masterVolume, masterMeter, masterPeak, preferences, onUpdateTrack, onUpdateMaster, onShowVSTPanel, }) => {
    const getChannelWidth = useCallback(() => {
        switch (preferences.mixerView) {
            case 'narrow':
                return 'w-16';
            case 'medium':
                return 'w-20';
            case 'wide':
                return 'w-24';
            case 'extended':
                return 'w-32';
            default:
                return 'w-20';
        }
    }, [preferences.mixerView]);
    const handleVolumeChange = useCallback((trackId, volume) => {
        onUpdateTrack(trackId, { volume });
    }, [onUpdateTrack]);
    const handlePanChange = useCallback((trackId, pan) => {
        onUpdateTrack(trackId, { pan });
    }, [onUpdateTrack]);
    const handleToggle = useCallback((trackId, key) => {
        const track = tracks.find((t) => t.id === trackId);
        if (track) {
            onUpdateTrack(trackId, { [key]: !track[key] });
        }
    }, [tracks, onUpdateTrack]);
    return (_jsx("div", { className: "flex-1 bg-background overflow-x-auto overflow-y-hidden", children: _jsxs("div", { className: "flex h-full gap-1 p-2", children: [tracks.map((track) => (_jsxs("div", { className: `${getChannelWidth()} flex-shrink-0 bg-card rounded-lg border border-border flex flex-col`, children: [_jsxs("div", { className: "p-2 border-b border-border", children: [_jsx("div", { className: `h-1 rounded mb-2 ${track.color}`, "aria-label": `Track color: ${track.color}` }), _jsx("h3", { className: "text-xs font-semibold text-white truncate", title: track.name, children: track.name }), _jsx("span", { className: "text-[10px] text-muted-foreground uppercase", children: track.type })] }), preferences.mixerView !== 'narrow' && track.fxChain.length > 0 && (_jsx("div", { className: "px-2 py-1 border-b border-border", children: _jsxs("div", { className: "flex flex-wrap gap-1", children: [track.fxChain.slice(0, 3).map((fx, idx) => (_jsx("div", { className: "text-xs bg-muted px-1 rounded", title: fx, children: FX_ICONS[fx] }, `${track.id}-fx-${idx}`))), track.fxChain.length > 3 && (_jsxs("div", { className: "text-[10px] text-muted-foreground", children: ["+", track.fxChain.length - 3] }))] }) })), _jsx("div", { className: "flex-1 flex items-center justify-center p-2", children: _jsx(AdvancedMeter, { level: track.meter, peak: track.peak, height: preferences.mixerView === 'narrow' ? 120 : 200 }) }), _jsxs("div", { className: "px-2 py-3 space-y-2", children: [_jsxs("div", { className: "flex flex-col items-center gap-1", children: [_jsx("input", { type: "range", min: "0", max: "1", step: "0.01", value: track.volume, onChange: (e) => handleVolumeChange(track.id, parseFloat(e.target.value)), className: "w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:rounded-full", style: { writingMode: 'bt-lr', WebkitAppearance: 'slider-vertical' }, "aria-label": "Volume" }), _jsxs("span", { className: "text-[10px] text-muted-foreground", children: [Math.round(track.volume * 100), "%"] })] }), preferences.mixerView !== 'narrow' && (_jsxs("div", { className: "flex flex-col items-center gap-1", children: [_jsx("input", { type: "range", min: "-1", max: "1", step: "0.01", value: track.pan, onChange: (e) => handlePanChange(track.id, parseFloat(e.target.value)), className: "w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer", "aria-label": "Pan" }), _jsx("span", { className: "text-[10px] text-muted-foreground", children: track.pan === 0 ? 'C' : track.pan < 0 ? `L${Math.abs(Math.round(track.pan * 100))}` : `R${Math.round(track.pan * 100)}` })] }))] }), _jsxs("div", { className: "p-2 border-t border-border space-y-1", children: [_jsxs("div", { className: "flex gap-1", children: [_jsx("button", { onClick: () => handleToggle(track.id, 'muted'), className: `flex-1 px-2 py-1 text-[10px] rounded transition-colors ${track.muted
                                                ? 'bg-red-600 text-white'
                                                : 'bg-muted text-muted-foreground hover:bg-muted'}`, title: "Mute", children: "M" }), _jsx("button", { onClick: () => handleToggle(track.id, 'solo'), className: `flex-1 px-2 py-1 text-[10px] rounded transition-colors ${track.solo
                                                ? 'bg-yellow-600 text-white'
                                                : 'bg-muted text-muted-foreground hover:bg-muted'}`, title: "Solo", children: "S" }), _jsx("button", { onClick: () => handleToggle(track.id, 'armed'), className: `flex-1 px-2 py-1 text-[10px] rounded transition-colors ${track.armed
                                                ? 'bg-red-600 text-white'
                                                : 'bg-muted text-muted-foreground hover:bg-muted'}`, title: "Arm for recording", children: _jsx(Circle, { size: 10, className: "mx-auto" }) })] }), preferences.mixerView !== 'narrow' && (_jsx("button", { onClick: () => onShowVSTPanel(track.id), className: "w-full px-2 py-1 text-[10px] bg-muted text-muted-foreground hover:bg-muted rounded transition-colors", children: "VST" }))] })] }, track.id))), _jsxs("div", { className: `${getChannelWidth()} flex-shrink-0 bg-card rounded-lg border-2 border-blue-600 flex flex-col`, children: [_jsx("div", { className: "p-2 border-b border-border", children: _jsx("h3", { className: "text-xs font-bold text-blue-400 text-center", children: "MASTER" }) }), _jsx("div", { className: "flex-1 flex items-center justify-center p-2", children: _jsx(AdvancedMeter, { level: masterMeter, peak: masterPeak, height: preferences.mixerView === 'narrow' ? 120 : 200 }) }), _jsx("div", { className: "px-2 py-3 space-y-2", children: _jsxs("div", { className: "flex flex-col items-center gap-1", children: [_jsx("input", { type: "range", min: "0", max: "1", step: "0.01", value: masterVolume, onChange: (e) => onUpdateMaster(parseFloat(e.target.value)), className: "w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:rounded-full", style: { writingMode: 'bt-lr', WebkitAppearance: 'slider-vertical' }, "aria-label": "Master Volume" }), _jsxs("span", { className: "text-[10px] text-blue-400 font-semibold", children: [Math.round(masterVolume * 100), "%"] })] }) }), _jsx("div", { className: "p-2 border-t border-border", children: _jsxs("div", { className: "text-center text-[10px] text-muted-foreground", children: [_jsx(Volume2, { size: 12, className: "mx-auto mb-1" }), "Output"] }) })] })] }) }));
};
