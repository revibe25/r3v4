import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// components/AdvancedMeter.tsx - Professional audio level meter
import { useMemo } from 'react';
import { gainToDb } from '../utils';
export const AdvancedMeter = ({ level, peak, height, }) => {
    const levelDb = useMemo(() => gainToDb(level), [level]);
    const peakDb = useMemo(() => gainToDb(peak), [peak]);
    const getLevelColor = (db) => {
        if (db > -3)
            return 'bg-red-500';
        if (db > -12)
            return 'bg-yellow-500';
        return 'bg-green-500';
    };
    const getLevelPercentage = (db) => {
        // Map -60dB to 0dB range to 0-100%
        const normalized = Math.max(0, Math.min(100, ((db + 60) / 60) * 100));
        return normalized;
    };
    const levelPercentage = getLevelPercentage(levelDb);
    const peakPercentage = getLevelPercentage(peakDb);
    return (_jsxs("div", { className: "relative w-full bg-muted rounded overflow-hidden", style: { height: `${height}px` }, children: [_jsxs("div", { className: "absolute inset-0 opacity-30", children: [_jsx("div", { className: "h-1/3 bg-gradient-to-t from-green-900" }), _jsx("div", { className: "h-1/3 bg-gradient-to-t from-yellow-900" }), _jsx("div", { className: "h-1/3 bg-gradient-to-t from-red-900" })] }), _jsx("div", { className: `absolute bottom-0 w-full transition-all duration-75 ${getLevelColor(levelDb)}`, style: { height: `${levelPercentage}%` } }), peak > 0 && (_jsx("div", { className: "absolute w-full h-0.5 bg-white transition-all duration-100", style: { bottom: `${peakPercentage}%` } })), _jsx("div", { className: "absolute inset-0 flex flex-col justify-between py-1 pointer-events-none", children: [0, -6, -12, -18, -24, -30].map((db) => (_jsx("div", { className: "text-[8px] text-muted-foreground px-1 leading-none", children: db }, db))) })] }));
};
