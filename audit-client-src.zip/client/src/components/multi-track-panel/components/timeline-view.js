import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// components/TimelineView.tsx - Timeline editor with clips and waveforms
import { useCallback, useRef } from 'react';
import { Upload } from 'lucide-react';
import { WaveformDisplay } from './waveform-display';
import { formatTime } from '../utils';
export const TimelineView = ({ tracks, transport, zoom, onClipMove, onAddClip, }) => {
    const timelineRef = useRef(null);
    const pixelsPerSecond = 50 * zoom;
    const totalWidth = 300 * pixelsPerSecond; // 5 minutes worth
    const handleFileDrop = useCallback((trackId, e) => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer.files);
        files.forEach((file) => {
            if (file.type.startsWith('audio/')) {
                onAddClip(trackId, file);
            }
        });
    }, [onAddClip]);
    const handleClipDragStart = useCallback((e, clipId) => {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('clipId', clipId);
    }, []);
    const handleClipDrop = useCallback((e, trackId) => {
        e.preventDefault();
        const clipId = e.dataTransfer.getData('clipId');
        if (!clipId)
            return;
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const time = x / pixelsPerSecond;
        onClipMove(clipId, time);
    }, [pixelsPerSecond, onClipMove]);
    const renderTimeRuler = () => {
        const markers = [];
        const interval = 10; // Every 10 seconds
        for (let i = 0; i <= 300; i += interval) {
            markers.push(_jsx("div", { className: "absolute top-0 bottom-0 border-l border-border", style: { left: `${i * pixelsPerSecond}px` }, children: _jsx("span", { className: "absolute top-1 left-1 text-[10px] text-muted-foreground", children: formatTime(i, 'seconds') }) }, i));
        }
        return markers;
    };
    const renderPlayhead = () => {
        const position = transport.position * pixelsPerSecond;
        return (_jsx("div", { className: "absolute top-0 bottom-0 w-0.5 bg-blue-500 z-30 pointer-events-none", style: { left: `${position}px` }, children: _jsx("div", { className: "absolute -top-1 -left-2 w-4 h-4", children: _jsx("div", { className: "w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-blue-500" }) }) }));
    };
    return (_jsxs("div", { className: "flex-1 flex flex-col bg-background overflow-hidden", children: [_jsx("div", { className: "h-8 bg-card border-b border-border relative overflow-hidden flex-shrink-0", children: _jsx("div", { ref: timelineRef, className: "relative h-full", style: { width: `${totalWidth}px` }, children: renderTimeRuler() }) }), _jsx("div", { className: "flex-1 overflow-auto", children: _jsxs("div", { className: "relative", style: { width: `${totalWidth}px` }, children: [renderPlayhead(), transport.loopEnabled && (_jsx("div", { className: "absolute top-0 bottom-0 bg-green-500/10 border-l-2 border-r-2 border-green-500 z-10 pointer-events-none", style: {
                                left: `${transport.loopStart * pixelsPerSecond}px`,
                                width: `${(transport.loopEnd - transport.loopStart) * pixelsPerSecond}px`,
                            } })), tracks.map((track, index) => (_jsxs("div", { className: `relative h-24 border-b border-border ${index % 2 === 0 ? 'bg-card/50' : 'bg-card/30'}`, onDrop: (e) => handleClipDrop(e, track.id), onDragOver: (e) => e.preventDefault(), children: [_jsxs("div", { className: "absolute left-0 top-0 bottom-0 w-32 bg-card border-r border-border flex items-center px-3 z-20", children: [_jsxs("div", { className: "flex-1", children: [_jsx("h4", { className: "text-xs font-semibold text-white truncate", children: track.name }), _jsx("span", { className: "text-[10px] text-muted-foreground uppercase", children: track.type })] }), _jsx("button", { onClick: () => {
                                                const input = document.createElement('input');
                                                input.type = 'file';
                                                input.accept = 'audio/*';
                                                input.onchange = (e) => {
                                                    const file = e.target.files?.[0];
                                                    if (file) {
                                                        onAddClip(track.id, file);
                                                    }
                                                };
                                                input.click();
                                            }, className: "p-1 hover:bg-muted rounded transition-colors", title: "Add clip", children: _jsx(Upload, { size: 12, className: "text-muted-foreground" }) })] }), _jsx("div", { className: "absolute left-32 right-0 top-0 bottom-0", children: track.clips.map((clip) => (_jsxs("div", { draggable: true, onDragStart: (e) => handleClipDragStart(e, clip.id), className: "absolute top-2 bottom-2 bg-muted border border-border rounded cursor-move hover:border-blue-500 transition-colors overflow-hidden group", style: {
                                            left: `${clip.startTime * pixelsPerSecond}px`,
                                            width: `${clip.duration * pixelsPerSecond}px`,
                                        }, children: [_jsx("div", { className: "absolute top-0 left-0 right-0 px-2 py-1 bg-card/80 border-b border-border z-10", children: _jsx("span", { className: "text-[10px] text-white truncate block", children: clip.fileName }) }), clip.waveformData && (_jsx("div", { className: "absolute inset-0 pt-6", children: _jsx(WaveformDisplay, { waveformData: clip.waveformData, color: clip.color, height: 64 }) })), _jsx("div", { className: `absolute top-0 left-0 bottom-0 w-1 ${clip.color}` }), _jsx("div", { className: "absolute top-0 left-0 bottom-0 w-2 cursor-ew-resize hover:bg-blue-500/50 opacity-0 group-hover:opacity-100 transition-opacity" }), _jsx("div", { className: "absolute top-0 right-0 bottom-0 w-2 cursor-ew-resize hover:bg-blue-500/50 opacity-0 group-hover:opacity-100 transition-opacity" })] }, clip.id))) }), _jsx("div", { className: "absolute left-32 right-0 top-0 bottom-0 pointer-events-none", onDragOver: (e) => {
                                        e.preventDefault();
                                        e.currentTarget.classList.add('bg-blue-500/10');
                                    }, onDragLeave: (e) => {
                                        e.currentTarget.classList.remove('bg-blue-500/10');
                                    } })] }, track.id)))] }) })] }));
};
