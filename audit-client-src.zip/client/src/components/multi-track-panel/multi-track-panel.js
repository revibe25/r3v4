import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// multi-track-panel.tsx
import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, Square, SkipBack, Repeat, Save, FolderOpen, Upload, Settings, Activity, Cpu, ZoomIn, ZoomOut, X, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';
import { useVSTContext } from '@/App';
import { VSTPerformanceUI } from '@/components/vst-performance-monitor-ui';
// Fixed: Changed from './audioengine' to './AudioEngine' (correct case-sensitive filename)
import { AudioEngine } from './audio-engine';
import { MixerView } from './components/mixer-view';
import { TimelineView } from './components/timeline-view';
import { PreferencesModal } from './components/preferences-modal';
import { VSTPanelModal } from './components/vst-panel-modal';
import { THEME_COLORS, TRACK_COLORS } from './constants';
import { formatTime, generateId } from './utils';
// ============================================
// INITIAL STATE
// ============================================
const createInitialTransport = () => ({
    isPlaying: false,
    isRecording: false,
    position: 0,
    loopEnabled: false,
    loopStart: 0,
    loopEnd: 60,
    tempo: 120,
    timeSignature: '4/4',
});
const createInitialTrack = (index) => ({
    id: generateId(),
    name: `Track ${index + 1}`,
    type: 'audio',
    color: TRACK_COLORS[index % TRACK_COLORS.length],
    armed: false,
    muted: false,
    solo: false,
    frozen: false,
    volume: 0.75,
    pan: 0,
    fxChain: [],
    clips: [],
    automation: { volume: [], pan: [] },
    automationMode: 'off',
    meter: 0,
    peak: 0,
    input: 'default',
    output: 'master',
    cpuUsage: 0,
});
const createInitialProject = () => ({
    title: 'Untitled Project',
    tracks: Array.from({ length: 8 }, (_, i) => createInitialTrack(i)),
    transport: createInitialTransport(),
    masterVolume: 0.8,
    masterMeter: 0,
    masterPeak: 0,
    cpuUsage: 0,
});
const createInitialPreferences = () => ({
    theme: 'dark',
    mixerView: 'medium',
    timeFormat: 'bars',
    viewMode: 'split',
    autoSave: false,
    bufferSize: 512,
    sampleRate: 48000,
    showCpuMeter: true,
    showVSTPanel: false,
});
// ============================================
// MAIN COMPONENT
// ============================================
export function MultiTrackPanel() {
    // VST Context
    const vstContext = useVSTContext();
    // State
    const [project, setProject] = useState(createInitialProject);
    const [preferences, setPreferences] = useState(createInitialPreferences);
    const [zoom, setZoom] = useState(1);
    const [showPreferences, setShowPreferences] = useState(false);
    const [showPerformanceMonitor, setShowPerformanceMonitor] = useState(false);
    const [selectedTrackForVST, setSelectedTrackForVST] = useState(null);
    // Refs
    const audioEngineRef = useRef(new AudioEngine());
    const fileInputRef = useRef(null);
    const animationFrameRef = useRef(null);
    const lastUpdateTimeRef = useRef(Date.now());
    // Theme configuration
    const themeConfig = THEME_COLORS[preferences.theme];
    // ============================================
    // AUDIO ENGINE INITIALIZATION
    // ============================================
    useEffect(() => {
        const engine = audioEngineRef.current;
        engine.initialize();
        return () => {
            engine.cleanup();
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, []);
    // ============================================
    // TRANSPORT CONTROLS
    // ============================================
    const handlePlayPause = useCallback(() => {
        setProject((prev) => ({
            ...prev,
            transport: {
                ...prev.transport,
                isPlaying: !prev.transport.isPlaying,
            },
        }));
    }, []);
    const handleStop = useCallback(() => {
        setProject((prev) => ({
            ...prev,
            transport: {
                ...prev.transport,
                isPlaying: false,
                position: 0,
            },
        }));
    }, []);
    const handleRecord = useCallback(() => {
        setProject((prev) => ({
            ...prev,
            transport: {
                ...prev.transport,
                isRecording: !prev.transport.isRecording,
                isPlaying: true,
            },
        }));
    }, []);
    // ============================================
    // PLAYBACK LOOP
    // ============================================
    useEffect(() => {
        if (!project.transport.isPlaying) {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
                animationFrameRef.current = null;
            }
            return;
        }
        const updatePlayback = () => {
            const now = Date.now();
            const deltaTime = (now - lastUpdateTimeRef.current) / 1000;
            lastUpdateTimeRef.current = now;
            setProject((prev) => {
                let newPosition = prev.transport.position + deltaTime;
                // Handle looping
                if (prev.transport.loopEnabled) {
                    if (newPosition >= prev.transport.loopEnd) {
                        newPosition = prev.transport.loopStart;
                    }
                }
                // Update meters — read from real Web Audio analyser nodes
                const engine = audioEngineRef.current;
                const newTracks = prev.tracks.map((track) => {
                    const nodes = engine.getTrackNodes(track.id);
                    let level = 0;
                    if (nodes && !track.muted) {
                        const data = new Uint8Array(nodes.analyser.frequencyBinCount);
                        nodes.analyser.getByteTimeDomainData(data);
                        let sum = 0;
                        for (let i = 0; i < data.length; i++) {
                            const n = (data[i] - 128) / 128;
                            sum += n * n;
                        }
                        level = Math.min(1, Math.sqrt(sum / data.length) * 2);
                    }
                    return {
                        ...track,
                        meter: level,
                        peak: Math.max(track.peak * 0.97, level),
                    };
                });
                const soloActive = newTracks.some(t => t.solo);
                const activeTracks = soloActive ? newTracks.filter(t => t.solo) : newTracks.filter(t => !t.muted);
                const masterLevel = activeTracks.length > 0 ? Math.max(0, ...activeTracks.map(t => t.meter)) : 0;
                return {
                    ...prev,
                    transport: { ...prev.transport, position: newPosition },
                    tracks: newTracks,
                    masterMeter: masterLevel,
                    masterPeak: Math.max(prev.masterPeak * 0.97, masterLevel),
                    cpuUsage: prev.cpuUsage * 0.85 + (performance.now() % 25) * 0.15,
                };
            });
            animationFrameRef.current = requestAnimationFrame(updatePlayback);
        };
        lastUpdateTimeRef.current = Date.now();
        animationFrameRef.current = requestAnimationFrame(updatePlayback);
        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, [project.transport.isPlaying]);
    // ============================================
    // TRACK MANAGEMENT
    // ============================================
    const updateTrack = useCallback((id, updates) => {
        setProject((prev) => ({
            ...prev,
            tracks: prev.tracks.map((track) => track.id === id ? { ...track, ...updates } : track),
        }));
    }, []);
    const addTrack = useCallback(() => {
        setProject((prev) => ({
            ...prev,
            tracks: [...prev.tracks, createInitialTrack(prev.tracks.length)],
        }));
    }, []);
    const removeTrack = useCallback((id) => {
        setProject((prev) => ({
            ...prev,
            tracks: prev.tracks.filter((track) => track.id !== id),
        }));
    }, []);
    // ============================================
    // FILE IMPORT
    // ============================================
    const handleFileImport = useCallback(async (trackId, file) => {
        const engine = audioEngineRef.current;
        const audioBuffer = await engine.loadAudioFile(file);
        if (!audioBuffer) {
            console.error('Failed to load audio file');
            return;
        }
        const waveformData = engine.generateWaveformData(audioBuffer);
        // Ensure gain+analyser nodes exist for this track
        engine.setupTrack(trackId);
        const newClip = {
            id: generateId(),
            trackId,
            startTime: project.transport.position,
            duration: audioBuffer.duration,
            audioBuffer,
            fileName: file.name,
            waveformData,
            color: '#3b82f6',
        };
        setProject((prev) => ({
            ...prev,
            tracks: prev.tracks.map((track) => track.id === trackId
                ? { ...track, clips: [...track.clips, newClip] }
                : track),
        }));
    }, [project.transport.position]);
    // ============================================
    // PROJECT SAVE/LOAD
    // ============================================
    const handleSaveProject = useCallback(() => {
        const projectData = JSON.stringify(project, null, 2);
        const blob = new Blob([projectData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${project.title}.dawproject`;
        a.click();
        URL.revokeObjectURL(url);
    }, [project]);
    const handleLoadProject = useCallback((e) => {
        const file = e.target.files?.[0];
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const data = JSON.parse(event.target?.result);
                setProject(data);
            }
            catch (error) {
                console.error('Failed to load project:', error);
            }
        };
        reader.readAsText(file);
    }, []);
    // ============================================
    // RENDER
    // ============================================
    return (_jsxs("div", { className: `h-screen flex flex-col ${themeConfig.bg} ${themeConfig.text}`, children: [_jsxs("div", { className: `${themeConfig.bgPanel} ${themeConfig.border} border-b px-3 py-2 flex items-center gap-3 flex-shrink-0`, children: [_jsx(Link, { href: "/", className: `p-2 ${themeConfig.bgHover} rounded transition-colors`, children: _jsx(ArrowLeft, { size: 16 }) }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("button", { onClick: handlePlayPause, className: `p-2 rounded transition-colors ${project.transport.isPlaying ? 'bg-green-600' : themeConfig.bgHover}`, title: project.transport.isPlaying ? 'Pause' : 'Play', "aria-label": project.transport.isPlaying ? 'Pause' : 'Play', children: project.transport.isPlaying ? _jsx(Pause, { size: 16 }) : _jsx(Play, { size: 16 }) }), _jsx("button", { onClick: handleStop, className: `p-2 ${themeConfig.bgHover} rounded`, title: "Stop", "aria-label": "Stop", children: _jsx(Square, { size: 16 }) }), _jsx("button", { onClick: handleRecord, className: `p-2 rounded transition-colors ${project.transport.isRecording ? 'bg-red-600' : themeConfig.bgHover}`, title: "Record", "aria-label": "Record", children: _jsx("div", { className: "w-4 h-4 rounded-full border-2 border-current" }) }), _jsx("button", { onClick: () => handleStop(), className: `p-2 ${themeConfig.bgHover} rounded`, title: "Return to Start", "aria-label": "Return to start", children: _jsx(SkipBack, { size: 16 }) }), _jsx("button", { onClick: () => setProject((prev) => ({
                                    ...prev,
                                    transport: { ...prev.transport, loopEnabled: !prev.transport.loopEnabled },
                                })), className: `p-2 rounded transition-colors ${project.transport.loopEnabled ? 'bg-green-600' : themeConfig.bgHover}`, title: "Loop", "aria-label": "Toggle loop", children: _jsx(Repeat, { size: 16 }) })] }), _jsx("div", { className: "flex-1 space-y-1", children: _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "font-mono text-sm text-blue-400", children: formatTime(project.transport.position, preferences.timeFormat) }), _jsx("div", { className: "flex-1 h-2 bg-muted rounded-full overflow-hidden", children: _jsx("div", { className: "h-full bg-blue-600 transition-all", style: { width: `${(project.transport.position / 300) * 100}%` } }) }), _jsxs("span", { className: "text-xs text-muted-foreground", children: [project.transport.tempo, " BPM \u00B7 ", project.transport.timeSignature] })] }) }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("button", { onClick: () => setZoom((prev) => Math.max(0.5, prev - 0.25)), className: `p-2 ${themeConfig.bgHover} rounded`, title: "Zoom Out", "aria-label": "Zoom out", children: _jsx(ZoomOut, { size: 16 }) }), _jsx("button", { onClick: () => setZoom((prev) => Math.min(3, prev + 0.25)), className: `p-2 ${themeConfig.bgHover} rounded`, title: "Zoom In", "aria-label": "Zoom in", children: _jsx(ZoomIn, { size: 16 }) }), _jsx("div", { className: "w-px h-6 bg-muted" }), _jsx("button", { onClick: handleSaveProject, className: `p-2 ${themeConfig.bgHover} rounded`, title: "Save Project", "aria-label": "Save project", children: _jsx(Save, { size: 16 }) }), _jsx("button", { onClick: () => fileInputRef.current?.click(), className: `p-2 ${themeConfig.bgHover} rounded`, title: "Load Project", "aria-label": "Load project", children: _jsx(FolderOpen, { size: 16 }) }), _jsx("input", { ref: fileInputRef, type: "file", accept: ".dawproject", onChange: handleLoadProject, className: "hidden" }), _jsx("button", { onClick: () => document.getElementById('audio-import')?.click(), className: `p-2 ${themeConfig.bgHover} rounded`, title: "Import Audio", "aria-label": "Import audio", children: _jsx(Upload, { size: 16 }) }), _jsx("input", { id: "audio-import", type: "file", accept: "audio/*", multiple: true, onChange: (e) => {
                                    const files = Array.from(e.target.files || []);
                                    files.forEach((file) => handleFileImport(project.tracks[0].id, file));
                                }, className: "hidden" }), _jsx("div", { className: "w-px h-6 bg-muted" }), _jsx("button", { onClick: () => setShowPerformanceMonitor(!showPerformanceMonitor), className: `p-2 rounded transition-colors ${showPerformanceMonitor ? 'bg-blue-600' : themeConfig.bgHover}`, title: "Performance Monitor", "aria-label": "Toggle performance monitor", children: _jsx(Activity, { size: 16 }) }), preferences.showCpuMeter && (_jsxs("div", { className: "flex items-center gap-2 px-3 py-1 bg-muted rounded", children: [_jsx(Cpu, { size: 14, className: "text-blue-400" }), _jsxs("span", { className: "text-xs", children: [project.cpuUsage.toFixed(0), "%"] })] })), _jsx("button", { onClick: () => setShowPreferences(true), className: `p-2 ${themeConfig.bgHover} rounded transition-colors`, title: "Preferences", "aria-label": "Open preferences", children: _jsx(Settings, { size: 16 }) })] })] }), _jsxs("div", { className: `${themeConfig.bgPanel} ${themeConfig.border} border-b px-3 py-2 flex items-center gap-2 text-xs flex-shrink-0`, children: [_jsx("span", { className: "text-muted-foreground", children: "View:" }), _jsx("button", { onClick: () => setPreferences((prev) => ({ ...prev, viewMode: 'mixer' })), className: `px-3 py-1 rounded ${preferences.viewMode === 'mixer' ? 'bg-blue-600' : 'bg-muted'}`, children: "Mixer" }), _jsx("button", { onClick: () => setPreferences((prev) => ({ ...prev, viewMode: 'timeline' })), className: `px-3 py-1 rounded ${preferences.viewMode === 'timeline' ? 'bg-blue-600' : 'bg-muted'}`, children: "Timeline" }), _jsx("button", { onClick: () => setPreferences((prev) => ({ ...prev, viewMode: 'split' })), className: `px-3 py-1 rounded ${preferences.viewMode === 'split' ? 'bg-blue-600' : 'bg-muted'}`, children: "Split" }), _jsx("div", { className: "flex-1" }), _jsx("span", { className: "text-muted-foreground", children: project.title })] }), _jsxs("div", { className: "flex-1 flex overflow-hidden", children: [preferences.viewMode === 'mixer' && (_jsx(MixerView, { tracks: project.tracks, masterVolume: project.masterVolume, masterMeter: project.masterMeter, masterPeak: project.masterPeak, preferences: preferences, onUpdateTrack: updateTrack, onUpdateMaster: (vol) => setProject((prev) => ({ ...prev, masterVolume: vol })), onShowVSTPanel: (trackId) => setSelectedTrackForVST(trackId) })), preferences.viewMode === 'timeline' && (_jsx(TimelineView, { tracks: project.tracks, transport: project.transport, zoom: zoom, onClipMove: (clipId, time) => {
                            // Handle clip move
                        }, onAddClip: handleFileImport })), preferences.viewMode === 'split' && (_jsxs(_Fragment, { children: [_jsx("div", { className: "w-1/2 border-r border-border", children: _jsx(MixerView, { tracks: project.tracks, masterVolume: project.masterVolume, masterMeter: project.masterMeter, masterPeak: project.masterPeak, preferences: preferences, onUpdateTrack: updateTrack, onUpdateMaster: (vol) => setProject((prev) => ({ ...prev, masterVolume: vol })), onShowVSTPanel: (trackId) => setSelectedTrackForVST(trackId) }) }), _jsx("div", { className: "w-1/2", children: _jsx(TimelineView, { tracks: project.tracks, transport: project.transport, zoom: zoom, onClipMove: (clipId, time) => {
                                        // Handle clip move
                                    }, onAddClip: handleFileImport }) })] }))] }), _jsxs("div", { className: `${themeConfig.bgPanel} ${themeConfig.border} border-t px-3 py-1 flex items-center gap-4 text-xs flex-shrink-0`, children: [_jsxs("span", { className: "text-muted-foreground", children: [preferences.sampleRate / 1000, "kHz / ", preferences.bufferSize, " samples"] }), _jsxs("span", { className: "text-muted-foreground", children: [project.tracks.length, " tracks"] }), _jsxs("span", { className: "text-muted-foreground", children: [project.tracks.reduce((sum, t) => sum + t.clips.length, 0), " clips"] }), _jsx("div", { className: "flex-1" }), _jsx("span", { className: "text-green-400", children: "\u25CF Ready" })] }), showPreferences && (_jsx(PreferencesModal, { preferences: preferences, onUpdate: (prefs) => setPreferences((prev) => ({ ...prev, ...prefs })), onClose: () => setShowPreferences(false) })), selectedTrackForVST && (_jsx(VSTPanelModal, { trackId: selectedTrackForVST, onClose: () => setSelectedTrackForVST(null) })), showPerformanceMonitor && (_jsx("div", { className: "fixed bottom-20 right-4 z-40 w-[400px]", children: _jsxs("div", { className: "bg-card border border-border rounded-lg shadow-2xl", children: [_jsxs("div", { className: "flex items-center justify-between p-3 border-b border-border", children: [_jsx("h3", { className: "font-semibold", children: "Performance Monitor" }), _jsx("button", { onClick: () => setShowPerformanceMonitor(false), className: "text-muted-foreground hover:text-white", "aria-label": "Close performance monitor", children: _jsx(X, { size: 16 }) })] }), _jsx("div", { className: "p-3", children: _jsx(VSTPerformanceUI, { monitor: vstContext.performanceMonitor, vstIds: vstContext.channels.map((c) => c.id) }) })] }) }))] }));
}
export default MultiTrackPanel;
