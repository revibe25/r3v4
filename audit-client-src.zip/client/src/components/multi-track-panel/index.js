// Main component
export { MultiTrackPanel as default } from './multi-track-panel';
export { MultiTrackPanel } from './multi-track-panel';
// Constants
export { THEME_COLORS, COLOR_SCHEME, FX_ICONS, TRACK_COLORS, DEFAULT_BUFFER_SIZE, DEFAULT_SAMPLE_RATE, DEFAULT_TEMPO, DEFAULT_TIME_SIGNATURE, MAX_ZOOM, MIN_ZOOM, ZOOM_STEP, } from './constants';
// Utilities
export { formatTime, generateId, clamp, gainToDb, dbToGain, findTrackById, findClipById, calculatePeakWithDecay, serializeProject, downloadFile, } from './utils';
// Audio Engine
export { AudioEngine } from './audio-engine';
// Components
export { TimelineView } from './components/timeline-view';
export { WaveformDisplay } from './components/waveform-display';
export { AdvancedMeter } from './components/advanced-meter';
export { PreferencesModal } from './components/preferences-modal';
export { VSTPanelModal } from './components/vst-panel-modal';
