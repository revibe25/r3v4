import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// FILE: client/src/components/ThreeStage.tsx
import { useRef, memo } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
// Camera base position — the rig always pulls back toward this.
const BASE_POSITION = new THREE.Vector3(0, 5.5, 11);
export const ThreeStage = memo(function ThreeStage({ children, shake }) {
    return (_jsxs(Canvas, { shadows: true, dpr: [1, 2], camera: { position: BASE_POSITION.toArray(), fov: 42 }, gl: { antialias: true, powerPreference: 'high-performance' }, children: [_jsx("color", { attach: "background", args: ['#050505'] }), _jsx("ambientLight", { intensity: 0.25 }), _jsx("hemisphereLight", { intensity: 0.35, groundColor: "#111" }), _jsx("directionalLight", { castShadow: true, position: [6, 12, 6], intensity: 1.4, "shadow-mapSize": [2048, 2048], "shadow-bias": -0.0001 }), _jsx(CameraRig, { shake: shake }), children, _jsxs(EffectComposer, { enableNormalPass: false, children: [_jsx(Bloom, { intensity: 1.6, luminanceThreshold: 0.15, luminanceSmoothing: 0.9, mipmapBlur: true }), _jsx(Vignette, { eskil: false, offset: 0.15, darkness: 0.6 })] })] }));
});
// ─── CameraRig ────────────────────────────────────────────────────────────────
// Fixes:
//  1. React import was missing (required for React.ReactNode in ThreeStageProps).
//  2. `shake` was captured as a stale closure value inside useFrame.
//     Store it in a ref so the frame loop always reads the latest value.
//  3. Camera position drifted permanently from BASE_POSITION because velocity
//     was only damped, never corrected. Added a spring force back to base.
//  4. Skip lookAt call when velocity is effectively zero (cheap early-out).
function CameraRig({ shake }) {
    const { camera } = useThree();
    // Keep a live ref to shake so useFrame never captures a stale value
    const shakeRef = useRef(shake);
    shakeRef.current = shake;
    const velocity = useRef(new THREE.Vector3());
    useFrame(() => {
        const s = shakeRef.current;
        const vel = velocity.current;
        // Apply random impulse when shaking
        if (s > 0) {
            vel.x += (Math.random() - 0.5) * s * 0.08;
            vel.y += (Math.random() - 0.5) * s * 0.06;
        }
        // Spring force: gently pull camera back toward BASE_POSITION.
        // Without this the camera drifts arbitrarily far from its starting point.
        const springStrength = 0.04;
        vel.x += (BASE_POSITION.x - camera.position.x) * springStrength;
        vel.y += (BASE_POSITION.y - camera.position.y) * springStrength;
        vel.z += (BASE_POSITION.z - camera.position.z) * springStrength;
        // Dampen velocity each frame
        vel.multiplyScalar(0.85);
        // Only update transform if velocity is non-negligible (avoids pointless
        // matrix recalculation and lookAt calls every frame when idle)
        if (vel.lengthSq() > 1e-8) {
            camera.position.add(vel);
            camera.lookAt(0, 0, 0);
        }
    });
    return null;
}
