import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useTransportStore } from '@/store/transport-store';
import "@/store/clip-store";
export function TransportBar() {
    const { playing, recording, bpm, play, stop, record, setBpm, } = useTransportStore();
    return (_jsxs("div", { style: { display: "flex", gap: 8 }, children: [_jsx("button", { onClick: play, children: "\u25B6" }), _jsx("button", { onClick: stop, children: "\u25A0" }), _jsx("button", { onClick: record, children: recording ? "● REC" : "REC" }), _jsxs("label", { children: ["BPM", _jsx("input", { type: "number", value: bpm, onChange: e => setBpm(+e.target.value), style: { width: 60 } })] })] }));
}
