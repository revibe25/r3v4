import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// client/src/components/vst-browser.tsx
import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { VSTScanner } from '@/audio/fx/vst-scanner';
import { Search, Star, TrendingUp, Grid, List, RefreshCw } from 'lucide-react';
import { getAudioContext } from '@/audio/core/audio-context';
import { useVSTStore } from '@/store/vst-store';
export function VSTBrowser({ onPluginSelect, channelId, showFXChain }) {
    const addPluginToChannel = useVSTStore(s => s.addPluginToChannel);
    const [plugins, setPlugins] = useState([]);
    const [recentIds, setRecentIds] = useState([]);
    const [loadingId, setLoadingId] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [viewMode, setViewMode] = useState('grid');
    const [isScanning, setIsScanning] = useState(false);
    const [scanProgress, setScanProgress] = useState(0);
    useEffect(() => {
        // Load cached plugins on mount
        VSTScanner.loadFromStorage();
        setPlugins(VSTScanner.getAllCachedPlugins());
    }, []);
    const handleScan = async () => {
        setIsScanning(true);
        setScanProgress(0);
        try {
            const audioCtx = getAudioContext();
            const result = await VSTScanner.scanDirectory('/plugins', audioCtx);
            setPlugins(result.plugins);
            VSTScanner.saveToStorage();
            if (result.errors.length > 0) {
                console.warn('Scan completed with errors:', result.errors);
            }
        }
        catch (error) {
            console.error('Scan failed:', error);
        }
        finally {
            setIsScanning(false);
            setScanProgress(100);
        }
    };
    const handlePluginSelect = (plugin) => {
        setLoadingId(plugin.id);
        setRecentIds(prev => [plugin.id, ...prev.filter(id => id !== plugin.id)].slice(0, 10));
        if (channelId)
            addPluginToChannel(channelId, plugin.id, plugin.name);
        onPluginSelect(plugin);
        setTimeout(() => setLoadingId(null), 600);
    };
    const filteredPlugins = useMemo(() => {
        return plugins.filter(plugin => {
            // Special tabs first
            if (selectedCategory === 'favorites')
                return !!plugin.isFavorite;
            if (selectedCategory === 'recent')
                return recentIds.includes(plugin.id);
            // Category filter
            if (selectedCategory !== 'all' && plugin.category !== selectedCategory) {
                return false;
            }
            // Search filter
            if (searchQuery) {
                const query = searchQuery.toLowerCase();
                return (plugin.name.toLowerCase().includes(query) ||
                    plugin.vendor.toLowerCase().includes(query) ||
                    plugin.tags.some(tag => tag.includes(query)));
            }
            return true;
        });
    }, [plugins, searchQuery, selectedCategory, recentIds]);
    const categories = useMemo(() => {
        const cats = new Set(plugins.map(p => p.category));
        return Array.from(cats);
    }, [plugins]);
    const toggleFavorite = (pluginId) => {
        setPlugins(prev => prev.map(p => p.id === pluginId ? { ...p, isFavorite: !p.isFavorite } : p));
        VSTScanner.saveToStorage();
    };
    return (_jsxs(Card, { className: "w-full h-full", children: [_jsxs(CardHeader, { children: [_jsxs(CardTitle, { className: "flex items-center justify-between", children: [_jsx("span", { children: "VST Plugin Browser" }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => setViewMode(viewMode === 'grid' ? 'list' : 'grid'), children: viewMode === 'grid' ? _jsx(List, { className: "h-4 w-4" }) : _jsx(Grid, { className: "h-4 w-4" }) }), _jsxs(Button, { variant: "outline", size: "sm", onClick: handleScan, disabled: isScanning, children: [_jsx(RefreshCw, { className: `h-4 w-4 ${isScanning ? 'animate-spin' : ''}` }), isScanning ? 'Scanning...' : 'Scan'] })] })] }), _jsx("div", { className: "flex gap-2 mt-4", children: _jsxs("div", { className: "relative flex-1", children: [_jsx(Search, { className: "absolute left-3 top-3 h-4 w-4 text-[#888]" }), _jsx(Input, { placeholder: "Search plugins...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), className: "pl-9" })] }) })] }), _jsx(CardContent, { children: _jsxs(Tabs, { value: selectedCategory, onValueChange: setSelectedCategory, children: [_jsxs(TabsList, { className: "w-full justify-start", children: [_jsx(TabsTrigger, { value: "all", children: "All" }), _jsxs(TabsTrigger, { value: "favorites", children: [_jsx(Star, { className: "h-4 w-4 mr-1" }), "Favorites"] }), _jsxs(TabsTrigger, { value: "recent", children: [_jsx(TrendingUp, { className: "h-4 w-4 mr-1" }), "Recent"] }), categories.map(cat => (_jsx(TabsTrigger, { value: cat, children: cat }, cat)))] }), _jsx(TabsContent, { value: selectedCategory, className: "mt-4", children: _jsxs(ScrollArea, { className: "h-[500px]", children: [viewMode === 'grid' ? (_jsx("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4", children: filteredPlugins.map(plugin => (_jsx(PluginCard, { plugin: plugin, onSelect: () => handlePluginSelect(plugin), loading: loadingId === plugin.id, onToggleFavorite: () => toggleFavorite(plugin.id) }, plugin.id))) })) : (_jsx("div", { className: "space-y-2", children: filteredPlugins.map(plugin => (_jsx(PluginListItem, { plugin: plugin, onSelect: () => handlePluginSelect(plugin), loading: loadingId === plugin.id, onToggleFavorite: () => toggleFavorite(plugin.id) }, plugin.id))) })), filteredPlugins.length === 0 && (_jsx("div", { className: "text-center py-12 text-[#888]", children: searchQuery ? 'No plugins found' : 'No plugins available. Click Scan to load plugins.' }))] }) })] }) })] }));
}
function PluginCard({ plugin, onSelect, onToggleFavorite, loading, }) {
    return (_jsx(Card, { className: `cursor-pointer hover:bg-accent transition-colors${loading ? ' opacity-60 pointer-events-none' : ''}`, onClick: onSelect, children: _jsxs(CardContent, { className: "p-4", children: [_jsxs("div", { className: "flex justify-between items-start mb-2", children: [_jsx(Badge, { variant: "secondary", children: plugin.category }), _jsx("button", { onClick: (e) => {
                                e.stopPropagation();
                                onToggleFavorite();
                            }, className: "text-yellow-500 hover:text-yellow-600", children: _jsx(Star, { className: `h-4 w-4 ${plugin.isFavorite ? 'fill-current' : ''}` }) })] }), _jsx("h3", { className: "font-semibold truncate", children: plugin.name }), _jsx("p", { className: "text-sm text-[#888] truncate", children: plugin.vendor }), _jsx("div", { className: "flex flex-wrap gap-1 mt-2", children: plugin.tags.slice(0, 2).map(tag => (_jsx(Badge, { variant: "outline", className: "text-xs", children: tag }, tag))) })] }) }));
}
function PluginListItem({ plugin, onSelect, onToggleFavorite, loading, }) {
    return (_jsxs("div", { className: `flex items-center justify-between p-3 border rounded-none hover:bg-accent cursor-pointer${loading ? ' opacity-60 pointer-events-none' : ''}`, onClick: onSelect, children: [_jsxs("div", { className: "flex items-center gap-4 flex-1", children: [_jsx(Badge, { variant: "secondary", children: plugin.category }), _jsxs("div", { className: "flex-1", children: [_jsx("h4", { className: "font-medium", children: plugin.name }), _jsxs("p", { className: "text-sm text-[#888]", children: [plugin.vendor, " \u2022 v", plugin.version] })] }), _jsx("div", { className: "flex gap-1", children: plugin.tags.slice(0, 3).map(tag => (_jsx(Badge, { variant: "outline", className: "text-xs", children: tag }, tag))) })] }), _jsx("button", { onClick: (e) => {
                    e.stopPropagation();
                    onToggleFavorite();
                }, className: "text-yellow-500 hover:text-yellow-600", children: _jsx(Star, { className: `h-4 w-4 ${plugin.isFavorite ? 'fill-current' : ''}` }) })] }));
}
