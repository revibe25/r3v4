import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
export default function AgentChat() {
    const [msg, setMsg] = useState("");
    const [reply, setReply] = useState("");
    async function send() {
        const res = await fetch("/ai/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: msg })
        });
        const data = await res.json();
        setReply(data.reply);
    }
    return (_jsxs("div", { children: [_jsx("input", { value: msg, onChange: (e) => setMsg(e.target.value) }), _jsx("button", { onClick: send, children: "Send" }), _jsx("div", { children: reply })] }));
}
