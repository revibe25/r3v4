// ─────────────────────────────────────────────────────────────────────────────
// R3 · UpgradePrompt Component
// Drop into: client/src/components/subscription/UpgradePrompt.tsx
// ─────────────────────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import { useSubscription, GateError } from '../hooks/useSubscription';
import { SubscriptionTier, TIER_DEFINITIONS } from '../../../../shared/subscription.types';

interface UpgradePromptProps {
  gateError?: GateError | null;
  requiredTier?: SubscriptionTier;
  feature?: string;
  compact?: boolean;
  onDismiss?: () => void;
}

const TIER_COLORS: Record<SubscriptionTier, string> = {
  explorer: '#3A7D44',
  creator: '#1A3C5E',
  pro_artist: '#B35A00',
};

export function UpgradePrompt({
  gateError,
  requiredTier: requiredTierProp,
  feature,
  compact = false,
  onDismiss,
}: UpgradePromptProps) {
  const { startCheckout, tier: currentTier } = useSubscription();
  const [billing, setBilling] = useState<'monthly' | 'annual'>('annual');
  const [loading, setLoading] = useState(false);

  const requiredTier =
    gateError?.requiredTier ?? requiredTierProp ?? 'creator';
  const message =
    gateError?.message ??
    `Upgrade to ${TIER_DEFINITIONS[requiredTier].displayName} to unlock this feature.`;

  const tierDef = TIER_DEFINITIONS[requiredTier as Exclude<SubscriptionTier, 'explorer'>];
  const color = TIER_COLORS[requiredTier];
  const monthlyCents = tierDef.monthlyPriceCents;
  const annualCents = tierDef.annualPriceCents;

  async function handleUpgrade() {
    if (requiredTier === 'explorer') return;
    setLoading(true);
    try {
      await startCheckout(requiredTier as Exclude<SubscriptionTier, 'explorer'>, billing);
    } finally {
      setLoading(false);
    }
  }

  if (compact) {
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '10px 14px',
          background: `${color}14`,
          border: `1px solid ${color}40`,
          borderRadius: '8px',
          fontSize: '13px',
        }}
      >
        <span style={{ flex: 1, color: '#333' }}>{message}</span>
        <button
          onClick={handleUpgrade}
          disabled={loading}
          style={{
            padding: '6px 14px',
            background: color,
            color: '#fff',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontWeight: 600,
            fontSize: '12px',
            whiteSpace: 'nowrap',
          }}
        >
          {loading ? 'Opening...' : `Upgrade to ${tierDef.displayName}`}
        </button>
      </div>
    );
  }

  return (
    <div
      style={{
        background: '#fff',
        border: `2px solid ${color}`,
        borderRadius: '16px',
        padding: '32px',
        maxWidth: '420px',
        width: '100%',
        boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
        fontFamily: 'Arial, sans-serif',
        position: 'relative',
      }}
    >
      {onDismiss && (
        <button
          onClick={onDismiss}
          style={{
            position: 'absolute',
            top: '14px',
            right: '14px',
            background: 'none',
            border: 'none',
            fontSize: '18px',
            cursor: 'pointer',
            color: '#999',
            lineHeight: 1,
          }}
          aria-label="Dismiss"
        >
          ×
        </button>
      )}

      <div
        style={{
          display: 'inline-block',
          background: color,
          color: '#fff',
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '12px',
          fontWeight: 700,
          letterSpacing: '0.05em',
          marginBottom: '16px',
          textTransform: 'uppercase',
        }}
      >
        {tierDef.displayName}
      </div>

      <h3 style={{ margin: '0 0 8px', fontSize: '20px', color: '#1a1a1a' }}>
        Unlock this feature
      </h3>
      <p style={{ margin: '0 0 24px', fontSize: '14px', color: '#555', lineHeight: 1.6 }}>
        {message}
      </p>

      {/* Billing toggle */}
      {requiredTier !== 'explorer' && (
        <>
          <div
            style={{
              display: 'flex',
              background: '#f3f4f6',
              borderRadius: '8px',
              padding: '3px',
              marginBottom: '20px',
              gap: '2px',
            }}
          >
            {(['monthly', 'annual'] as const).map((cycle) => (
              <button
                key={cycle}
                onClick={() => setBilling(cycle)}
                style={{
                  flex: 1,
                  padding: '7px',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: billing === cycle ? 700 : 400,
                  fontSize: '13px',
                  background: billing === cycle ? '#fff' : 'transparent',
                  color: billing === cycle ? '#1a1a1a' : '#666',
                  boxShadow: billing === cycle ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
                  transition: 'all 0.15s',
                }}
              >
                {cycle === 'monthly' ? 'Monthly' : 'Annual (save 20%)'}
              </button>
            ))}
          </div>

          <div style={{ marginBottom: '20px' }}>
            <span style={{ fontSize: '32px', fontWeight: 700, color: '#1a1a1a' }}>
              ${billing === 'monthly' ? (monthlyCents / 100).toFixed(0) : (annualCents / 100).toFixed(0)}
            </span>
            <span style={{ fontSize: '14px', color: '#888' }}> / month</span>
            {billing === 'annual' && (
              <span
                style={{
                  marginLeft: '8px',
                  fontSize: '12px',
                  background: '#e8f5e9',
                  color: '#2e7d32',
                  padding: '2px 8px',
                  borderRadius: '10px',
                  fontWeight: 600,
                }}
              >
                billed ${((annualCents / 100) * 12).toFixed(0)}/yr
              </span>
            )}
          </div>

          <button
            onClick={handleUpgrade}
            disabled={loading}
            style={{
              width: '100%',
              padding: '14px',
              background: loading ? '#ccc' : color,
              color: '#fff',
              border: 'none',
              borderRadius: '10px',
              cursor: loading ? 'not-allowed' : 'pointer',
              fontWeight: 700,
              fontSize: '15px',
              transition: 'opacity 0.2s',
            }}
          >
            {loading
              ? 'Redirecting to checkout...'
              : `Start 7-day free trial — then $${billing === 'monthly' ? (monthlyCents / 100).toFixed(0) : (annualCents / 100).toFixed(0)}/mo`}
          </button>

          <p style={{ marginTop: '12px', fontSize: '11px', color: '#aaa', textAlign: 'center' }}>
            Cancel any time · No commitment · Secure checkout via Stripe
          </p>
        </>
      )}
    </div>
  );
}

// ── Gate wrapper — wraps any component, shows upgrade prompt if not allowed ───

interface FeatureGateProps {
  feature: Parameters<ReturnType<typeof useSubscription>['can']>[0];
  requiredTier?: SubscriptionTier;
  compact?: boolean;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function FeatureGate({
  feature,
  requiredTier,
  compact,
  children,
  fallback,
}: FeatureGateProps) {
  const { can } = useSubscription();
  const allowed = can(feature);

  if (allowed) return <>{children}</>;

  if (fallback) return <>{fallback}</>;

  return (
    <UpgradePrompt
      requiredTier={requiredTier}
      feature={String(feature)}
      compact={compact}
    />
  );
}
