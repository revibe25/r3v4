import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { FileAudio, Music } from 'lucide-react';
export const ClipBlock = ({ clip, isSelected, pixelsPerSecond = 100, onStartDrag, onStartResize, onClick }) => {
    const width = clip.duration * pixelsPerSecond;
    const left = clip.startTime * pixelsPerSecond;
    const defaultColor = clip.type === 'midi' ? '#6366f1' : '#8b5cf6';
    const selectedColor = clip.type === 'midi' ? '#3b82f6' : '#a78bfa';
    const handleMouseDown = (e) => {
        e.stopPropagation();
        if (onClick)
            onClick(clip.id);
        onStartDrag(clip.id, e.clientX);
    };
    const handleResizeMouseDown = (e) => {
        e.stopPropagation();
        if (onStartResize) {
            onStartResize(clip.id, e.clientX);
        }
    };
    return (_jsxs("div", { className: "absolute h-14 rounded cursor-move transition-all select-none overflow-hidden group", style: {
            left: `${left}px`,
            width: `${width}px`,
            backgroundColor: clip.color || (isSelected ? selectedColor : defaultColor),
            border: isSelected ? '2px solid #60a5fa' : '2px solid rgba(255,255,255,0.2)',
            boxShadow: isSelected ? '0 0 0 1px rgba(96, 165, 250, 0.5)' : 'none'
        }, onMouseDown: handleMouseDown, children: [_jsxs("div", { className: "p-2 flex items-center gap-2 h-full", children: [clip.type === 'midi' ? (_jsx(Music, { className: "w-3 h-3 text-white/70 flex-shrink-0" })) : (_jsx(FileAudio, { className: "w-3 h-3 text-white/70 flex-shrink-0" })), _jsx("div", { className: "text-xs text-white font-medium truncate flex-1", children: clip.name || clip.id })] }), _jsxs("div", { className: "absolute bottom-1 right-2 text-xs text-white/60 pointer-events-none", children: [clip.duration.toFixed(2), "s"] }), onStartResize && (_jsx("div", { className: "absolute top-0 right-0 bottom-0 w-2 cursor-ew-resize opacity-0 group-hover:opacity-100 transition-opacity bg-white/20", onMouseDown: handleResizeMouseDown })), _jsx("div", { className: "absolute bottom-0 left-0 right-0 h-6 opacity-30", children: _jsx("svg", { width: "100%", height: "100%", className: "opacity-50", children: _jsx("rect", { x: "0", y: "40%", width: "100%", height: "20%", fill: "currentColor", className: "text-white" }) }) })] }));
};
export default ClipBlock;
