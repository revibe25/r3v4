import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useMemo, useCallback } from "react";
import { useClipStore } from "@/store/clip-store";
import { timeToPixels } from "@/utils/time";
import { useTransportState } from "@/hooks/use-transport-state";
import { useClipDrag, useClipResize } from "@/components/tracks/clip-drag-handler";
import { ClipBlock } from "./clip-block";
import { ClipContextMenu } from "./clip-context-menu";
import { TransportBar } from "./transport-bar";
import { Timeline } from "./timeline";
export const UnifiedDaw = () => {
    const clips = useClipStore(s => s.clips);
    const selectedClipIds = useClipStore(s => s.selectedClipIds);
    const selectClip = useClipStore(s => s.selectClip);
    const removeClip = useClipStore(s => s.removeClip);
    const getClipsForTrack = useClipStore(s => s.getClipsForTrack);
    const snapEnabled = useClipStore(s => s.snapEnabled ?? false);
    const updatePosition = useClipStore(s => s.updateClipPosition);
    const updateDuration = useClipStore(s => s.updateClipDuration);
    const duplicateClip = useClipStore(s => s.duplicateClip);
    const splitClipAt = useClipStore(s => s.splitClipAt);
    const { playing, position, bpm, play, stop, setBpm } = useTransportState();
    const [contextMenu, setContextMenu] = useState(null);
    const [dragState, setDragState] = useState(null);
    const [resizeState, setResizeState] = useState(null);
    const tracks = useMemo(() => Array.from(new Set(Array.from(clips.values()).map(c => c.trackId)))
        .map(id => ({ id, name: `Track ${id}`, volume: 1, pan: 0, muted: false, solo: false })), [clips]);
    const maxTime = useMemo(() => Math.max(10, ...Array.from(clips.values()).map(c => c.startTime + c.duration)), [clips]);
    const handleDragEnd = useCallback(() => setDragState(null), []);
    const handleResizeEnd = useCallback(() => setResizeState(null), []);
    useClipDrag(dragState?.clipId ?? null, dragState?.startX ?? 0, dragState?.initialTime ?? 0, snapEnabled, updatePosition, handleDragEnd);
    useClipResize(resizeState?.clipId ?? null, resizeState?.startX ?? 0, resizeState?.initialDuration ?? 0, snapEnabled, updateDuration, handleResizeEnd);
    const handleDrag = useCallback((clipId, startX) => {
        const clip = Array.from(clips.values()).find(c => c.id === clipId);
        if (!clip)
            return;
        setDragState({ clipId, startX, initialTime: clip.startTime });
    }, [clips]);
    const handleResize = useCallback((clipId, startX) => {
        const clip = Array.from(clips.values()).find(c => c.id === clipId);
        if (!clip)
            return;
        setResizeState({ clipId, startX, initialDuration: clip.duration });
    }, [clips]);
    return (_jsxs("div", { className: "flex flex-col h-screen bg-card text-white", children: [_jsx(TransportBar, { playing: playing, position: position, bpm: bpm, onPlay: play, onStop: stop, onBpmChange: setBpm }), _jsx(Timeline, { maxTime: maxTime }), _jsx("div", { className: "flex-1 overflow-auto relative", children: _jsx("div", { style: { minWidth: timeToPixels(maxTime) + 200 }, children: tracks.map(t => (_jsx("div", { className: "relative h-16 border-b border-border", children: getClipsForTrack(t.id).map(clip => (_jsx(ClipBlock, { clip: clip, isSelected: selectedClipIds?.[0] === clip.id, onDrag: handleDrag, onResize: handleResize, onSelect: selectClip, onContext: (id, x, y) => setContextMenu({ clipId: id, x, y }) }, clip.id))) }, t.id))) }) }), contextMenu && (_jsx(ClipContextMenu, { x: contextMenu.x, y: contextMenu.y, onClose: () => setContextMenu(null), onDelete: () => { removeClip(contextMenu.clipId); setContextMenu(null); }, onDuplicate: () => { duplicateClip?.(contextMenu.clipId); setContextMenu(null); }, onSplit: () => { splitClipAt?.(contextMenu.clipId, position); setContextMenu(null); } }))] }));
};
export default UnifiedDaw;
