import { jsx as _jsx } from "react/jsx-runtime";
// visual/oscilloscope.tsx
import { Line } from '@react-three/drei';
export function Oscilloscope({ data }) {
    const points = data.map((v, i) => [
        i / data.length - 0.5,
        v / 100,
        0,
    ]);
    return _jsx(Line, { points: points, color: "cyan" });
}
