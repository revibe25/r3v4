// Scene Worker stub
export {};
