// ─── useLoopStation505 ────────────────────────────────────────────────────────
// src/features/loopstation/hooks/useLoopStation505.ts
//
// No direct `import * as Tone` — all engine access via getLoopEngine().
// Features: scenes, undo stack, keyboard shortcuts, solo logic,
//           tap tempo, metronome, per-track send FX, overdub counter.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useEffect, useRef, useState } from 'react';
import { getLoopEngine } from '../engine/loopEngine';
// ── Helpers ───────────────────────────────────────────────────────────────────
function idxFromId(trackId) {
    return parseInt(trackId.split('-')[1], 10);
}
// Track colors — hardware-inspired
const TRACK_COLORS = ['#39ff14', '#00d4ff', '#ff6b35', '#c77dff', '#ffd60a'];
// ── Initial state ─────────────────────────────────────────────────────────────
const makeInitialState = () => ({
    tracks: Array.from({ length: 5 }, (_, i) => ({
        id: `track-${i}`,
        index: i,
        state: 'idle',
        volume: 0.8,
        pan: 0,
        muted: false,
        soloed: false,
        cued: false,
        hasContent: false,
        loopLength: null,
        harmonyMode: 'off',
        eq: { low: 0, mid: 0, high: 0 },
        reverbSend: 0,
        delaySend: 0,
        overdubLayers: 0,
        color: TRACK_COLORS[i],
    })),
    bpm: 120,
    masterVolume: 0.9,
    isPlaying: false,
    midiSync: false,
    quantize: '1m',
    soloActive: false,
    beat: { bar: 0, beat: 0 },
});
const makeInitialFX = () => ({
    filterFreq: 8000,
    filterResonance: 1,
    delayTime: '8n',
    delayFeedback: 0.3,
    reverbDecay: 2.5,
    reverbWet: 0,
    xyX: 0.5,
    xyY: 0.5,
    compThreshold: -18,
    compRatio: 4,
    metronomeOn: false,
    metronomeVol: 0.4,
});
// ── Initial scenes ────────────────────────────────────────────────────────────
const SCENE_LABELS = 'ABCDEFGHIJKLMNOP'.split('');
// ── Hook ──────────────────────────────────────────────────────────────────────
export function useLoopStation505() {
    const [state, setState] = useState(makeInitialState);
    const [fx, setFX] = useState(makeInitialFX);
    const [isReady, setIsReady] = useState(false);
    const [isError, setIsError] = useState(false);
    const [errorMessage, setErrorMessage] = useState(null);
    const [midiSync, setMidiSync] = useState(false);
    const [scenes, setScenes] = useState(Array(16).fill(null));
    const [activeScene, setActiveScene] = useState(null);
    const undoStack = useRef([]);
    const recordingTracks = useRef(new Set());
    const [canUndo, setCanUndo] = useState(false);
    // ── Engine listeners ──────────────────────────────────────────────────────
    useEffect(() => {
        const engine = getLoopEngine();
        const offs = [
            engine.on('error', err => { setIsError(true); setErrorMessage(err.message); }),
            engine.on('bpmChange', bpm => {
                setState(prev => Math.abs(prev.bpm - bpm) > 0.5 ? { ...prev, bpm } : prev);
            }),
            engine.on('beat', (bar, beat) => {
                setState(prev => ({ ...prev, beat: { bar, beat } }));
            }),
            engine.on('soloChanged', soloActive => {
                setState(prev => ({ ...prev, soloActive }));
            }),
        ];
        return () => offs.forEach(off => off());
    }, []);
    // ── Init ─────────────────────────────────────────────────────────────────
    // FIX: init() is called AFTER Tone.start() in pressTrack/togglePlayback
    // so the AudioContext is already running when we get here.
    const init = useCallback(async () => {
        try {
            const engine = getLoopEngine();
            await engine.init();
            // FIX: wait for all Tone buffers (reverb IR etc.) to finish decoding
            // before starting the transport, otherwise players with no buffer crash.
            const { loaded } = await import('tone');
            await loaded();
            engine.startTransport();
            setIsReady(true);
            setIsError(false);
            setErrorMessage(null);
            setState(prev => ({ ...prev, isPlaying: true }));
        }
        catch (err) {
            setIsError(true);
            setErrorMessage(err instanceof Error ? err.message : String(err));
        }
    }, []);
    // ── BPM sync ──────────────────────────────────────────────────────────────
    useEffect(() => {
        if (!isReady)
            return;
        const id = setInterval(() => {
            const liveBpm = getLoopEngine().getBpm();
            setState(prev => Math.abs(prev.bpm - liveBpm) > 0.5 ? { ...prev, bpm: liveBpm } : prev);
        }, 500);
        return () => clearInterval(id);
    }, [isReady]);
    // ── MIDI Clock ────────────────────────────────────────────────────────────
    useEffect(() => {
        if (!navigator.requestMIDIAccess)
            return;
        let cleanup = null;
        let clockTimeout;
        navigator.requestMIDIAccess()
            .then(access => {
            const offs = [];
            access.inputs.forEach(input => {
                const h = (msg) => {
                    if (msg.data[0] === 248) {
                        setMidiSync(true);
                        clearTimeout(clockTimeout);
                        clockTimeout = setTimeout(() => setMidiSync(false), 1000);
                    }
                };
                input.addEventListener('midimessage', h);
                offs.push(() => input.removeEventListener('midimessage', h));
            });
            cleanup = () => { offs.forEach(f => f()); clearTimeout(clockTimeout); };
        })
            .catch(() => { });
        return () => { cleanup?.(); };
    }, []);
    // ── Keyboard shortcuts ────────────────────────────────────────────────────
    useEffect(() => {
        if (!isReady)
            return;
        const handler = (e) => {
            if (e.target?.tagName === 'INPUT')
                return;
            switch (e.key) {
                case ' ':
                    e.preventDefault();
                    togglePlayback();
                    break;
                case 't':
                    tapTempo();
                    break;
                case 'm':
                    toggleMetronome();
                    break;
                case 'z':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        undo();
                    }
                    break;
                case '1':
                    pressTrack('track-0');
                    break;
                case '2':
                    pressTrack('track-1');
                    break;
                case '3':
                    pressTrack('track-2');
                    break;
                case '4':
                    pressTrack('track-3');
                    break;
                case '5':
                    pressTrack('track-4');
                    break;
                case 'a':
                    recallScene(0);
                    break;
                case 'b':
                    recallScene(1);
                    break;
                case 'c':
                    recallScene(2);
                    break;
                case 'd':
                    recallScene(3);
                    break;
            }
        };
        window.addEventListener('keydown', handler);
        return () => window.removeEventListener('keydown', handler);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isReady]);
    // ── Helpers ───────────────────────────────────────────────────────────────
    const pushUndo = useCallback(() => {
        setState(prev => {
            undoStack.current = [...undoStack.current.slice(-9), prev];
            setCanUndo(true);
            return prev;
        });
    }, []);
    const undo = useCallback(() => {
        const prev = undoStack.current.pop();
        if (prev) {
            setState(prev);
            setCanUndo(undoStack.current.length > 0);
        }
    }, []);
    // ── Track state machine ───────────────────────────────────────────────────
    const pressTrack = useCallback(async (trackId) => {
        // FIX: Tone.start() MUST be called synchronously inside the user-gesture
        // handler BEFORE any await. The browser only grants AudioContext.resume()
        // during the synchronous portion of a click/keydown event.
        const { start: toneStart } = await import('tone');
        await toneStart();
        if (!isReady)
            await init();
        const engine = getLoopEngine();
        const idx = idxFromId(trackId);
        const track = engine.tracks[idx];
        setState(prev => {
            const tracks = prev.tracks.map(t => {
                if (t.id !== trackId)
                    return t;
                switch (t.state) {
                    case 'idle':
                    case 'stopped': {
                        if (!t.hasContent) {
                            track?.recorder.open().catch(console.error);
                            recordingTracks.current.add(trackId);
                            return { ...t, state: 'recording' };
                        }
                        // FIX: player already has content — make sure it's synced before playing
                        engine.startPlayerOnTransport(idx);
                        return { ...t, state: 'playing' };
                    }
                    case 'recording': {
                        track?.recorder.close();
                        recordingTracks.current.delete(trackId);
                        // FIX: sync player to transport now that it has a buffer
                        engine.startPlayerOnTransport(idx);
                        return {
                            ...t, state: 'playing',
                            hasContent: true,
                            loopLength: engine.getTransportPosition(),
                        };
                    }
                    case 'playing':
                        engine.incrementOverdub(idx);
                        return { ...t, state: 'overdubbing', overdubLayers: t.overdubLayers + 1 };
                    case 'overdubbing':
                        return { ...t, state: 'playing' };
                    default: return t;
                }
            });
            return { ...prev, tracks };
        });
    }, [isReady, init]);
    const stopTrack = useCallback((trackId) => {
        const idx = idxFromId(trackId);
        getLoopEngine().tracks[idx]?.recorder.close();
        recordingTracks.current.delete(trackId);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, state: 'stopped' } : t),
        }));
    }, []);
    const clearTrack = useCallback((trackId) => {
        pushUndo();
        const idx = idxFromId(trackId);
        // resetOverdub now also stops + unsyncs the player via the engine patch
        getLoopEngine().resetOverdub(idx);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId
                ? { ...t, state: 'idle', hasContent: false, loopLength: null, overdubLayers: 0 }
                : t),
        }));
    }, [pushUndo]);
    const clearAll = useCallback(() => {
        pushUndo();
        state.tracks.forEach(t => {
            const idx = idxFromId(t.id);
            getLoopEngine().resetOverdub(idx);
        });
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => ({
                ...t, state: 'idle', hasContent: false,
                loopLength: null, overdubLayers: 0,
            })),
        }));
    }, [pushUndo, state.tracks]);
    // ── Track params ──────────────────────────────────────────────────────────
    const setTrackVolume = useCallback((trackId, vol) => {
        getLoopEngine().setTrackVolume(idxFromId(trackId), vol);
        setState(prev => ({ ...prev, tracks: prev.tracks.map(t => t.id === trackId ? { ...t, volume: vol } : t) }));
    }, []);
    const setTrackPan = useCallback((trackId, pan) => {
        getLoopEngine().setTrackPan(idxFromId(trackId), pan);
        setState(prev => ({ ...prev, tracks: prev.tracks.map(t => t.id === trackId ? { ...t, pan } : t) }));
    }, []);
    const setTrackEQ = useCallback((trackId, band, val) => {
        getLoopEngine().setTrackEQ(idxFromId(trackId), band, val);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, eq: { ...t.eq, [band]: val } } : t),
        }));
    }, []);
    const toggleMute = useCallback((trackId) => {
        setState(prev => {
            const tracks = prev.tracks.map(t => {
                if (t.id !== trackId)
                    return t;
                const muted = !t.muted;
                getLoopEngine().muteTrack(idxFromId(trackId), muted);
                return { ...t, muted };
            });
            return { ...prev, tracks };
        });
    }, []);
    const toggleSolo = useCallback((trackId) => {
        setState(prev => {
            const tracks = prev.tracks.map(t => {
                const soloed = t.id === trackId ? !t.soloed : t.soloed;
                getLoopEngine().soloTrack(idxFromId(t.id), soloed);
                return { ...t, soloed };
            });
            return { ...prev, tracks };
        });
    }, []);
    const toggleCue = useCallback((trackId) => {
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, cued: !t.cued } : t),
        }));
    }, []);
    const setHarmonyMode = useCallback((trackId, mode) => {
        getLoopEngine().setHarmonyMode(idxFromId(trackId), mode);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, harmonyMode: mode } : t),
        }));
    }, []);
    const setReverbSend = useCallback((trackId, amount) => {
        getLoopEngine().setReverbSend(idxFromId(trackId), amount);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, reverbSend: amount } : t),
        }));
    }, []);
    const setDelaySend = useCallback((trackId, amount) => {
        getLoopEngine().setDelaySend(idxFromId(trackId), amount);
        setState(prev => ({
            ...prev,
            tracks: prev.tracks.map(t => t.id === trackId ? { ...t, delaySend: amount } : t),
        }));
    }, []);
    // ── BPM & tempo ───────────────────────────────────────────────────────────
    const setBpm = useCallback((bpm) => {
        getLoopEngine().setBpm(bpm);
        setState(prev => ({ ...prev, bpm }));
    }, []);
    const setSwing = useCallback((amount) => {
        getLoopEngine().setSwing(amount);
    }, []);
    const setTimeSignature = useCallback((sig) => {
        getLoopEngine().setTimeSignature(sig);
    }, []);
    const setQuantMode = useCallback((mode) => {
        getLoopEngine().setQuantMode(mode);
        setState(prev => ({ ...prev, quantize: mode }));
    }, []);
    const setPlaybackMode = useCallback((trackId, mode) => {
        getLoopEngine().setPlaybackMode(idxFromId(trackId), mode);
    }, []);
    const tapTempo = useCallback(() => {
        const newBpm = getLoopEngine().tapTempo();
        setState(prev => ({ ...prev, bpm: newBpm }));
        return newBpm;
    }, []);
    const setMasterVolume = useCallback((vol) => {
        getLoopEngine().setMasterVolume(vol);
        setState(prev => ({ ...prev, masterVolume: vol }));
    }, []);
    // ── Metronome ─────────────────────────────────────────────────────────────
    const toggleMetronome = useCallback(() => {
        setFX(prev => {
            const on = !prev.metronomeOn;
            getLoopEngine().setMetronome(on, prev.metronomeVol);
            return { ...prev, metronomeOn: on };
        });
    }, []);
    const setMetronomeVol = useCallback((vol) => {
        setFX(prev => {
            getLoopEngine().setMetronome(prev.metronomeOn, vol);
            return { ...prev, metronomeVol: vol };
        });
    }, []);
    // ── FX ────────────────────────────────────────────────────────────────────
    const setFilter = useCallback((freq, resonance) => {
        getLoopEngine().setGlobalFilter(freq);
        if (resonance !== undefined)
            getLoopEngine().setFilterResonance(resonance);
        setFX(prev => ({ ...prev, filterFreq: freq, ...(resonance !== undefined ? { filterResonance: resonance } : {}) }));
    }, []);
    const setDelay = useCallback((time, feedback) => {
        getLoopEngine().setGlobalDelay(time, feedback);
        setFX(prev => ({ ...prev, delayTime: time, delayFeedback: feedback }));
    }, []);
    const setReverb = useCallback((decay, wet) => {
        getLoopEngine().setGlobalReverb(decay, wet);
        setFX(prev => ({ ...prev, reverbDecay: decay, reverbWet: wet }));
    }, []);
    const setCompressor = useCallback((threshold, ratio) => {
        getLoopEngine().setMasterCompressor(threshold, ratio);
        setFX(prev => ({ ...prev, compThreshold: threshold, compRatio: ratio }));
    }, []);
    const setXY = useCallback(({ x, y }) => {
        setFilter(x * 18000 + 200, x * 8 + 0.5);
        setReverb(y * 8 + 0.5, y * 0.8);
        setFX(prev => ({ ...prev, xyX: x, xyY: y }));
    }, [setFilter, setReverb]);
    // ── Transport ─────────────────────────────────────────────────────────────
    const togglePlayback = useCallback(async () => {
        if (!isReady)
            return;
        // FIX: keep AudioContext alive on every transport gesture
        const { start: toneStart } = await import('tone');
        await toneStart();
        getLoopEngine().toggleTransport();
        setState(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
    }, [isReady]);
    // ── Scenes ────────────────────────────────────────────────────────────────
    const saveScene = useCallback((slot) => {
        const label = SCENE_LABELS[slot] ?? String(slot + 1);
        const snapshot = getLoopEngine().captureScene(`scene-${slot}`, label);
        setScenes(prev => { const next = [...prev]; next[slot] = snapshot; return next; });
        setActiveScene(slot);
    }, []);
    const recallScene = useCallback((slot) => {
        const scene = scenes[slot];
        if (!scene || !isReady)
            return;
        pushUndo();
        getLoopEngine().recallScene(scene);
        setActiveScene(slot);
        setState(prev => ({ ...prev, bpm: scene.bpm }));
        setFX(prev => ({
            ...prev,
            filterFreq: scene.fx.filterFreq,
            reverbWet: scene.fx.reverbWet,
            delayFeedback: scene.fx.delayFeedback,
        }));
    }, [scenes, isReady, pushUndo]);
    // ── Return API ────────────────────────────────────────────────────────────
    return {
        state,
        fx,
        isReady,
        isError,
        errorMessage,
        midiSync,
        scenes,
        activeScene,
        canUndo,
        // Lifecycle
        init,
        togglePlayback,
        // Track actions
        pressTrack,
        stopTrack,
        clearTrack,
        clearAll,
        undo,
        // Track params
        setTrackVolume,
        setTrackPan,
        setTrackEQ,
        toggleMute,
        toggleSolo,
        toggleCue,
        setHarmonyMode,
        setReverbSend,
        setDelaySend,
        setMasterVolume,
        // Tempo
        setBpm,
        tapTempo,
        // Metronome
        toggleMetronome,
        setMetronomeVol,
        // FX
        setFilter,
        setDelay,
        setReverb,
        setCompressor,
        setXY,
        // Scenes
        saveScene,
        recallScene,
        // Extended controls (wired to engine)
        setSwing,
        setTimeSignature,
        setQuantMode,
        setPlaybackMode,
    };
}
