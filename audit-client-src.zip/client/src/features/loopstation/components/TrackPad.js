import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// ─── TrackPad v2 — Professional Channel Strip ─────────────────────────────────
import { motion, useAnimation } from 'framer-motion';
import { useCallback, useEffect, useRef, useState } from 'react';
import { getLoopEngine } from '../engine/loopEngine';
import { RGBRing } from './RGBRing';
import { VUMeter } from './VUMeter';
import { WaveformCanvas } from './WaveformCanvas';
import { FXKnob } from './FXKnob';
// ── Constants ──────────────────────────────────────────────────────────────────
const HARMONY = ['off', 'subtle', 'choir', 'ambient', 'counter', 'octave', 'fifth', 'unison'];
const PLAYBACK = [
    { key: 'normal', label: '▶', color: '#39ff14' },
    { key: 'reverse', label: '◀', color: '#f472b6' },
    { key: 'half', label: '½', color: '#c084fc' },
    { key: 'double', label: '2x', color: '#c084fc' },
    { key: 'stutter', label: 'STU', color: '#fb923c' },
    { key: 'pingpong', label: '⇄', color: '#22d3ee' },
];
const SCOL = {
    idle: '#1a1a1a',
    recording: '#ff1a1a',
    overdubbing: '#ff6b00',
    playing: '#39ff14',
    stopped: '#252525',
    waiting_record: '#ff1a1a',
    waiting_play: '#39ff14',
};
const SLBL = {
    idle: '○',
    recording: 'REC',
    overdubbing: 'OD',
    playing: '▶',
    stopped: '■',
    waiting_record: '⟳REC',
    waiting_play: '⟳PLY',
};
const TRACK_NAMES = ['TRACK 1', 'TRACK 2', 'TRACK 3', 'TRACK 4', 'TRACK 5'];
// ── Utilities ──────────────────────────────────────────────────────────────────
function useQPulse(ready) {
    const [p, setP] = useState(false);
    const id = useRef(-1);
    useEffect(() => {
        if (!ready)
            return;
        const e = getLoopEngine();
        id.current = e.scheduleRepeat(() => { setP(true); setTimeout(() => setP(false), 80); }, '1m');
        return () => { e.clearSchedule(id.current); id.current = -1; };
    }, [ready]);
    return p;
}
// ── Micro LED Button ───────────────────────────────────────────────────────────
const LB = ({ label, active, ac = '#39ff14', disabled, onClick, onMD, onMU, onML, title, w = 24, h = 18, fontSize = 7 }) => (_jsxs("button", { onClick: onClick, onMouseDown: onMD, onMouseUp: onMU, onMouseLeave: onML, disabled: disabled, title: title, style: {
        width: w, height: h, fontSize, fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.08em',
        background: active ? `${ac}16` : '#090909',
        border: `1px solid ${active ? ac : '#181818'}`,
        borderBottom: `2px solid ${active ? ac + '66' : '#0a0a0a'}`,
        color: active ? ac : disabled ? '#111' : '#2e2e2e',
        cursor: disabled ? 'default' : 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all .07s', userSelect: 'none',
        boxShadow: active ? `0 0 8px ${ac}44, inset 0 0 4px ${ac}11` : 'none',
        position: 'relative', overflow: 'hidden',
    }, children: [active && (_jsx("div", { style: {
                position: 'absolute', top: 0, left: 0, right: 0, height: 1,
                background: `linear-gradient(90deg, transparent, ${ac}88, transparent)`,
            } })), label] }));
// ── Vertical Fader ─────────────────────────────────────────────────────────────
const Fader = ({ value, onChange, color, h = 80, label }) => {
    const dragging = useRef(false);
    const sy = useRef(0);
    const sv = useRef(value);
    const tref = useRef(null);
    const md = (e) => {
        e.preventDefault();
        dragging.current = true;
        sy.current = e.clientY;
        sv.current = value;
        const mv = (ev) => {
            if (!dragging.current || !tref.current)
                return;
            const ht = tref.current.getBoundingClientRect().height;
            onChange(Math.min(1, Math.max(0, sv.current - (ev.clientY - sy.current) / ht)));
        };
        const up = () => {
            dragging.current = false;
            window.removeEventListener('mousemove', mv);
            window.removeEventListener('mouseup', up);
        };
        window.addEventListener('mousemove', mv);
        window.addEventListener('mouseup', up);
    };
    // Double-click to reset to unity (0.8)
    const dblClick = () => onChange(0.8);
    const capY = `${(1 - value) * (h - 8)}px`;
    const unityY = `${(1 - 0.8) * (h - 8)}px`;
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }, children: [_jsxs("div", { ref: tref, style: {
                    width: 10, height: h,
                    background: 'linear-gradient(180deg, #0d0d0d 0%, #080808 100%)',
                    border: '1px solid #141414',
                    borderRadius: 1,
                    position: 'relative', cursor: 'ns-resize',
                }, onMouseDown: md, onDoubleClick: dblClick, children: [_jsx("div", { style: {
                            position: 'absolute', bottom: 0, left: 1, right: 1,
                            height: `${value * 100}%`,
                            background: `linear-gradient(180deg, ${color}55, ${color}1a)`,
                            borderTop: `1px solid ${color}66`,
                            transition: 'none',
                        } }), _jsx("div", { style: {
                            position: 'absolute', left: -3, right: -3,
                            top: unityY, height: 1,
                            background: '#333',
                        } }), _jsx("div", { style: {
                            position: 'absolute', top: capY, left: -3, right: -3, height: 10,
                            background: 'linear-gradient(180deg, #383838 0%, #1e1e1e 50%, #2a2a2a 100%)',
                            border: `1px solid ${value > 0.01 ? color + '88' : '#282828'}`,
                            borderRadius: 1,
                            boxShadow: value > 0.01 ? `0 0 6px ${color}44` : '0 1px 3px rgba(0,0,0,0.8)',
                            cursor: 'ns-resize',
                        } })] }), _jsx("span", { style: { fontSize: 5, color: '#252525', fontFamily: 'IBM Plex Mono,monospace' }, children: Math.round(value * 100) }), label && _jsx("span", { style: { fontSize: 5, color: '#1e1e1e', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.15em' }, children: label })] }));
};
// ── EQ Mini Display ────────────────────────────────────────────────────────────
const EQMini = ({ low, mid, high, color }) => {
    const vals = [low, mid, high];
    const labels = ['L', 'M', 'H'];
    return (_jsx("div", { style: { display: 'flex', gap: 2, alignItems: 'flex-end', height: 18 }, children: vals.map((v, i) => {
            const norm = (v + 20) / 40; // -20 to +20 → 0 to 1
            const barH = Math.max(2, Math.round(norm * 16));
            const midH = 8;
            const isBoost = norm > 0.5;
            return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }, children: [_jsxs("div", { style: {
                            width: 6, height: 16, background: '#090909',
                            border: '1px solid #141414', position: 'relative', overflow: 'hidden',
                        }, children: [_jsx("div", { style: { position: 'absolute', left: 0, right: 0, top: '50%', height: 1, background: '#1e1e1e' } }), _jsx("div", { style: {
                                    position: 'absolute',
                                    [isBoost ? 'bottom' : 'top']: '50%',
                                    left: 0, right: 0,
                                    height: Math.abs(norm - 0.5) * 32,
                                    background: Math.abs(norm - 0.5) > 0.1 ? `${color}88` : '#1e1e1e',
                                } })] }), _jsx("span", { style: { fontSize: 4, color: '#1e1e1e', fontFamily: 'IBM Plex Mono,monospace' }, children: labels[i] })] }, labels[i]));
        }) }));
};
// ── Loop Progress Ring ─────────────────────────────────────────────────────────
const LoopRing = ({ progress, color, isActive, size = 24 }) => {
    const r = (size - 3) / 2;
    const circ = 2 * Math.PI * r;
    const dash = progress * circ;
    return (_jsxs("svg", { width: size, height: size, style: { transform: 'rotate(-90deg)', flexShrink: 0 }, children: [_jsx("circle", { cx: size / 2, cy: size / 2, r: r, fill: "none", stroke: "#141414", strokeWidth: 2 }), _jsx("circle", { cx: size / 2, cy: size / 2, r: r, fill: "none", stroke: isActive ? color : '#222', strokeWidth: isActive ? 2.5 : 1.5, strokeDasharray: `${dash} ${circ - dash}`, strokeLinecap: "round", style: { filter: isActive ? `drop-shadow(0 0 3px ${color}88)` : 'none', transition: 'stroke-dasharray 0.1s' } })] }));
};
// ── Send Strip ─────────────────────────────────────────────────────────────────
const SendStrip = ({ label, value, color, onChange }) => {
    const w = 48;
    const dragging = useRef(false);
    const sx = useRef(0), sv2 = useRef(value);
    const md = (e) => {
        e.preventDefault();
        dragging.current = true;
        sx.current = e.clientX;
        sv2.current = value;
        const mv = (ev) => {
            if (!dragging.current)
                return;
            onChange(Math.min(1, Math.max(0, sv2.current + (ev.clientX - sx.current) / 120)));
        };
        const up = () => { dragging.current = false; window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
        window.addEventListener('mousemove', mv);
        window.addEventListener('mouseup', up);
    };
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 2 }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' }, children: [_jsx("span", { style: { fontSize: 6, color: '#252525', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.1em' }, children: label }), _jsx("span", { style: { fontSize: 6, color: value > 0.05 ? color : '#222', fontFamily: 'IBM Plex Mono,monospace' }, children: Math.round(value * 100) })] }), _jsxs("div", { style: {
                    width: '100%', height: 8, background: '#090909',
                    border: '1px solid #141414', position: 'relative', cursor: 'ew-resize',
                }, onMouseDown: md, children: [_jsx("div", { style: {
                            position: 'absolute', left: 0, top: 0, bottom: 0, width: `${value * 100}%`,
                            background: `linear-gradient(90deg, ${color}44, ${color}88)`,
                            borderRight: value > 0.02 ? `1px solid ${color}` : 'none',
                        } }), _jsx("div", { style: {
                            position: 'absolute', right: 3, top: 0, bottom: 0,
                            display: 'flex', alignItems: 'center',
                        } })] })] }));
};
// ═══════════════════════════════════════════════════════════════════════════════
// TRACKPAD MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════
export const TrackPad = ({ track, bpm, isReady, beat, onPress, onStop, onClear, onVolumeChange, onPanChange, onEQChange, onMuteToggle, onSoloToggle, onCueToggle, onHarmonyChange, onReverbSend, onDelaySend, }) => {
    const ctrl = useAnimation();
    const pulse = useQPulse(isReady);
    const [expanded, setExpanded] = useState(false);
    const [tab, setTab] = useState('eq');
    const [playMode, setPlayMode] = useState('normal');
    const [ch, setCH] = useState(false);
    const [loopProgress, setLoopProgress] = useState(0);
    const [overdubBlend, setOD] = useState(0.7);
    const ct = useRef(null);
    const lpRef = useRef(0);
    const lastBar = useRef(0);
    const isActive = track.state === 'playing' || track.state === 'overdubbing';
    const isRec = track.state === 'recording';
    const isWaiting = track.state === 'waiting_record' || track.state === 'waiting_play';
    const col = SCOL[track.state] ?? '#1a1a1a';
    const wc = track.state === 'overdubbing' ? '#ff6b00' : track.color;
    // Animate loop progress
    useEffect(() => {
        if (!isActive || !track.loopLength) {
            setLoopProgress(0);
            return;
        }
        const tick = () => {
            const pos = beat.bar % (Number(track.loopLength) || 4);
            const beatInLoop = pos * 4 + beat.beat;
            const totalBeats = (Number(track.loopLength) || 4) * 4;
            setLoopProgress(beatInLoop / totalBeats);
            lpRef.current = requestAnimationFrame(tick);
        };
        lpRef.current = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(lpRef.current);
    }, [isActive, beat, track.loopLength]);
    // Trigger pad animation
    useEffect(() => {
        if (isActive) {
            void ctrl.start({
                scale: [1, beat.beat === 0 && pulse ? 1.015 : 1.006, 1],
                transition: { duration: (60 / bpm) * 0.25, ease: [0.22, 1, 0.36, 1] },
            });
        }
        else if (isRec && pulse) {
            void ctrl.start({ scale: [1, 1.01, 1], transition: { duration: 0.08 } });
        }
        else if (isWaiting) {
            void ctrl.start({
                scale: [1, 1.008, 1],
                transition: { duration: 0.25, repeat: Infinity, ease: 'easeInOut' },
            });
        }
        else {
            ctrl.stop();
            ctrl.set({ scale: 1 });
        }
    }, [isActive, isRec, isWaiting, beat.beat, pulse, bpm, ctrl]);
    const hCH = useCallback(() => { ct.current = setTimeout(() => setCH(true), 600); }, []);
    const hCU = useCallback(() => {
        if (ct.current)
            clearTimeout(ct.current);
        if (ch) {
            onClear(track.id);
            setCH(false);
        }
        else
            setCH(false);
    }, [ch, onClear, track.id]);
    const trackBgGrad = isActive
        ? `radial-gradient(ellipse at 50% 80%, ${col}0d 0%, #060606 100%)`
        : '#070707';
    return (_jsxs("div", { style: {
            display: 'flex', flexDirection: 'column',
            background: trackBgGrad,
            borderRight: '1px solid #0f0f0f',
            boxShadow: isActive
                ? `inset 0 0 40px ${col}08, inset -1px 0 0 ${col}1a`
                : 'none',
            transition: 'box-shadow 0.3s, background 0.3s',
            minWidth: 0,
        }, children: [_jsxs("div", { style: {
                    padding: '4px 6px 3px',
                    background: 'linear-gradient(180deg, #0c0c0c 0%, #080808 100%)',
                    borderBottom: `2px solid ${col}`,
                    display: 'flex', alignItems: 'center', gap: 4,
                    position: 'relative', overflow: 'hidden',
                }, children: [_jsx("div", { style: {
                            position: 'absolute', top: 0, left: 0, right: 0, height: 1,
                            background: `linear-gradient(90deg, transparent 0%, ${col}66 40%, ${col}33 70%, transparent 100%)`,
                        } }), _jsx("div", { style: {
                            width: 20, height: 20, flexShrink: 0,
                            background: isActive ? col : 'transparent',
                            border: `1px solid ${col}`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            boxShadow: isActive ? `0 0 12px ${col}77, 0 0 24px ${col}33` : 'none',
                            transition: 'all 0.15s',
                        }, children: _jsx("span", { style: {
                                fontSize: 10, fontWeight: 900, fontFamily: 'Syne, sans-serif',
                                color: isActive ? '#050505' : col, lineHeight: 1,
                            }, children: track.index + 1 }) }), _jsx(LoopRing, { progress: loopProgress, color: col, isActive: isActive, size: 22 }), _jsxs("div", { style: { flex: 1, display: 'flex', flexDirection: 'column', gap: 1, minWidth: 0 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 3 }, children: [track.overdubLayers > 0 && (_jsxs("span", { style: {
                                            fontSize: 6, color: '#ff6b00', background: 'rgba(255,107,0,0.12)',
                                            border: '1px solid rgba(255,107,0,0.25)', padding: '0 3px',
                                            fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.05em', flexShrink: 0,
                                        }, children: ["\u00D7", track.overdubLayers + 1] })), track.muted && _jsx("div", { style: { width: 4, height: 4, background: '#ff6b00', boxShadow: '0 0 4px #ff6b00', flexShrink: 0 } }), track.soloed && _jsx("div", { style: { width: 4, height: 4, background: '#39ff14', boxShadow: '0 0 4px #39ff14', flexShrink: 0 } }), track.cued && _jsx("div", { style: { width: 4, height: 4, background: '#22d3ee', boxShadow: '0 0 4px #22d3ee', flexShrink: 0 } })] }), _jsxs("span", { style: {
                                    fontSize: 6, color: col, fontFamily: 'IBM Plex Mono,monospace',
                                    letterSpacing: '.08em', lineHeight: 1,
                                }, children: [SLBL[track.state], track.loopLength ? ` · ${track.loopLength}` : ''] })] }), _jsx(EQMini, { low: track.eq.low, mid: track.eq.mid, high: track.eq.high, color: track.color })] }), _jsxs(motion.button, { animate: ctrl, whileTap: { scale: 0.975, transition: { duration: 0.04 } }, onClick: () => onPress(track.id), style: {
                    position: 'relative', height: 88,
                    background: 'transparent',
                    border: 'none',
                    borderBottom: `1px solid ${col}1a`,
                    cursor: 'pointer', overflow: 'hidden',
                    display: 'block', width: '100%',
                }, "aria-label": `Track ${track.index + 1}: ${track.state}`, children: [_jsx(RGBRing, { state: track.state, bpm: bpm, color: track.color }), isActive ? (_jsx(WaveformCanvas, { trackIndex: track.index, isActive: isActive, color: wc, mode: "mirror", persistence: 0.22, width: 200, height: 84, className: "" })) : (_jsxs("div", { style: {
                            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                            height: '100%', gap: 5, position: 'relative', zIndex: 1,
                        }, children: [_jsx("div", { style: {
                                    fontSize: isRec ? 12 : 22, color: col,
                                    fontFamily: isRec ? 'IBM Plex Mono,monospace' : 'Syne,sans-serif',
                                    fontWeight: 900, lineHeight: 1,
                                    textShadow: isRec ? `0 0 12px ${col}` : 'none',
                                }, children: SLBL[track.state] }), _jsx("span", { style: { fontSize: 7, color: '#1e1e1e', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.2em' }, children: track.hasContent ? 'PLAY / OVERDUB' : 'TAP TO RECORD' })] })), isRec && pulse && (_jsx("div", { style: {
                            position: 'absolute', inset: 0,
                            border: '2px solid #ff1a1a',
                            opacity: 0.7, pointerEvents: 'none',
                        } })), isWaiting && (_jsx("div", { style: {
                            position: 'absolute', bottom: 3, left: '50%', transform: 'translateX(-50%)',
                            fontSize: 6, color: col, fontFamily: 'IBM Plex Mono,monospace',
                            letterSpacing: '.2em', background: 'rgba(0,0,0,0.8)', padding: '1px 4px',
                        }, children: "WAITING\u2026" }))] }), _jsxs("div", { style: { padding: '3px 5px', borderBottom: '1px solid #0f0f0f', display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 2 }, children: [_jsx(LB, { label: "\u25A0", active: false, disabled: track.state === 'idle' || track.state === 'stopped', onClick: () => onStop(track.id), title: "Stop" }), _jsx(LB, { label: "M", active: track.muted, ac: "#ff6b00", onClick: () => onMuteToggle(track.id), title: "Mute" }), _jsx(LB, { label: "S", active: track.soloed, ac: "#39ff14", onClick: () => onSoloToggle(track.id), title: "Solo" }), _jsx(LB, { label: "Q", active: track.cued, ac: "#22d3ee", onClick: () => onCueToggle(track.id), title: "Cue / Headphones" }), _jsx(LB, { label: ch ? '!CLR' : 'CLR', active: ch, ac: "#ff1a1a", onMD: hCH, onMU: hCU, onML: () => { if (ct.current)
                            clearTimeout(ct.current); setCH(false); }, title: "Hold to clear" })] }), _jsxs("div", { style: { padding: '6px 5px 4px', borderBottom: '1px solid #0f0f0f', display: 'flex', gap: 4, alignItems: 'flex-end', justifyContent: 'center', background: '#070707' }, children: [_jsx(Fader, { value: track.volume, onChange: v => onVolumeChange(track.id, v), color: track.color, h: 84 }), _jsx(VUMeter, { trackIndex: track.index, isActive: isActive, showScale: true, height: 84, showGr: isActive })] }), _jsxs("div", { style: { padding: '5px 6px', borderBottom: '1px solid #0f0f0f', display: 'flex', flexDirection: 'column', gap: 4 }, children: [_jsx(SendStrip, { label: "REV", value: track.reverbSend, color: "#ff6b00", onChange: v => onReverbSend(track.id, v) }), _jsx(SendStrip, { label: "DLY", value: track.delaySend, color: "#22d3ee", onChange: v => onDelaySend(track.id, v) }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6 }, children: [_jsx("span", { style: { fontSize: 6, color: '#252525', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.1em', flexShrink: 0 }, children: "PAN" }), _jsxs("div", { style: { flex: 1, position: 'relative', height: 8, background: '#090909', border: '1px solid #141414', cursor: 'ew-resize' }, onMouseDown: e => {
                                    e.preventDefault();
                                    const rect = e.currentTarget.getBoundingClientRect();
                                    const sv = track.pan;
                                    const sx = e.clientX;
                                    const mv = (ev) => {
                                        const newPan = Math.min(1, Math.max(-1, sv + (ev.clientX - sx) / (rect.width / 2)));
                                        onPanChange(track.id, newPan);
                                    };
                                    const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
                                    window.addEventListener('mousemove', mv);
                                    window.addEventListener('mouseup', up);
                                }, onDoubleClick: () => onPanChange(track.id, 0), children: [_jsx("div", { style: { position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, background: '#1e1e1e' } }), _jsx("div", { style: {
                                            position: 'absolute',
                                            left: track.pan >= 0 ? '50%' : `${(track.pan + 1) * 50}%`,
                                            width: `${Math.abs(track.pan) * 50}%`,
                                            top: 0, bottom: 0,
                                            background: `${track.color}77`,
                                        } }), _jsx("div", { style: {
                                            position: 'absolute', top: 0, bottom: 0,
                                            left: `${(track.pan + 1) * 50}%`,
                                            width: 2, background: track.color,
                                            transform: 'translateX(-50%)',
                                            boxShadow: `0 0 4px ${track.color}`,
                                        } })] }), _jsx("span", { style: { fontSize: 6, color: Math.abs(track.pan) > 0.05 ? track.color : '#222', fontFamily: 'IBM Plex Mono,monospace', flexShrink: 0, width: 18, textAlign: 'right' }, children: track.pan === 0 ? 'C' : `${track.pan > 0 ? 'R' : 'L'}${Math.round(Math.abs(track.pan) * 100)}` })] })] }), _jsx("button", { onClick: () => setExpanded(v => !v), style: {
                    padding: '3px 6px', width: '100%', height: 16, fontSize: 6,
                    letterSpacing: '.2em', fontFamily: 'IBM Plex Mono,monospace',
                    background: expanded ? 'rgba(57,255,20,0.03)' : 'transparent',
                    border: 'none', borderBottom: '1px solid #0f0f0f',
                    color: expanded ? '#39ff14' : '#1e1e1e', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
                }, children: expanded ? '▲ LESS' : '▼ MORE' }), expanded && (_jsxs("div", { style: { borderBottom: '1px solid #0f0f0f' }, children: [_jsx("div", { style: { display: 'flex', borderBottom: '1px solid #0f0f0f' }, children: ['eq', 'fx', 'mod', 'dyn'].map(t => (_jsx("button", { onClick: () => setTab(t), style: {
                                flex: 1, height: 16, fontSize: 6, fontFamily: 'IBM Plex Mono,monospace',
                                letterSpacing: '.12em', textTransform: 'uppercase',
                                background: tab === t ? 'rgba(57,255,20,0.05)' : 'transparent',
                                border: 'none', borderBottom: `1px solid ${tab === t ? '#39ff14' : 'transparent'}`,
                                color: tab === t ? '#39ff14' : '#222', cursor: 'pointer',
                            }, children: t }, t))) }), tab === 'eq' && (_jsx("div", { style: { padding: '8px 6px' }, children: _jsxs("div", { style: { display: 'flex', justifyContent: 'space-around' }, children: [_jsx(FXKnob, { label: "HF", value: (track.eq.high + 20) / 40, color: "#22d3ee", size: "xs", bipolar: true, onChange: v => onEQChange(track.id, 'high', v * 40 - 20) }), _jsx(FXKnob, { label: "MF", value: (track.eq.mid + 20) / 40, color: "#22d3ee", size: "xs", bipolar: true, onChange: v => onEQChange(track.id, 'mid', v * 40 - 20) }), _jsx(FXKnob, { label: "LF", value: (track.eq.low + 20) / 40, color: "#22d3ee", size: "xs", bipolar: true, onChange: v => onEQChange(track.id, 'low', v * 40 - 20) })] }) })), tab === 'fx' && (_jsxs("div", { style: { padding: '8px 6px', display: 'flex', flexDirection: 'column', gap: 6 }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-around' }, children: [_jsx(FXKnob, { label: "PTCH", value: 0.5, color: "#c084fc", size: "xs", bipolar: true, onChange: () => { } }), _jsx(FXKnob, { label: "FINE", value: 0.5, color: "#818cf8", size: "xs", bipolar: true, onChange: () => { } }), _jsx(FXKnob, { label: "CHO", value: 0, color: "#f472b6", size: "xs", onChange: () => { } })] }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 6, color: '#1c1c1c', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.2em', marginBottom: 3, textAlign: 'center' }, children: "HARMONY" }), _jsx("select", { value: track.harmonyMode, onChange: e => onHarmonyChange(track.id, e.target.value), style: {
                                            width: '100%', fontSize: 7, background: '#060606',
                                            color: track.harmonyMode === 'off' ? '#1e1e1e' : '#39ff14',
                                            border: `1px solid ${track.harmonyMode === 'off' ? '#141414' : '#39ff1422'}`,
                                            padding: '2px 4px', cursor: 'pointer', outline: 'none',
                                            fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.1em',
                                        }, children: HARMONY.map(m => (_jsx("option", { value: m, style: { background: '#060606' }, children: m === 'off' ? '— HARMONY OFF' : `♪ ${m.toUpperCase()}` }, m))) })] })] })), tab === 'mod' && (_jsxs("div", { style: { padding: '6px' }, children: [_jsx("div", { style: { fontSize: 6, color: '#1c1c1c', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.2em', marginBottom: 4, textAlign: 'center' }, children: "PLAYBACK MODE" }), _jsx("div", { style: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 2 }, children: PLAYBACK.map(pm => (_jsx(LB, { label: pm.label, active: playMode === pm.key, ac: pm.color, onClick: () => setPlayMode(pm.key), w: 999, h: 20, fontSize: 8, title: pm.key }, pm.key))) }), _jsxs("div", { style: { marginTop: 6 }, children: [_jsx("div", { style: { fontSize: 6, color: '#1c1c1c', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.2em', marginBottom: 3, textAlign: 'center' }, children: "OVERDUB BLEND" }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsx("input", { type: "range", min: 0, max: 100, value: Math.round(overdubBlend * 100), onChange: e => setOD(Number(e.target.value) / 100), style: { flex: 1, accentColor: track.color, cursor: 'pointer', height: 2 } }), _jsx("span", { style: { fontSize: 6, color: '#333', fontFamily: 'IBM Plex Mono,monospace', width: 20, textAlign: 'right' }, children: Math.round(overdubBlend * 100) })] })] })] })), tab === 'dyn' && (_jsxs("div", { style: { padding: '8px 6px' }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-around' }, children: [_jsx(FXKnob, { label: "GATE", value: 0, color: "#eab308", size: "xs", onChange: () => { } }), _jsx(FXKnob, { label: "COMP", value: 0.35, color: "#eab308", size: "xs", onChange: () => { } }), _jsx(FXKnob, { label: "SAT", value: 0, color: "#f97316", size: "xs", onChange: () => { } })] }), _jsxs("div", { style: { marginTop: 6, display: 'flex', justifyContent: 'space-around' }, children: [_jsx(FXKnob, { label: "TRIM", value: 0.5, color: "#94a3b8", size: "xs", onChange: () => { } }), _jsx(FXKnob, { label: "XFAD", value: 0.5, color: "#94a3b8", size: "xs", bipolar: true, onChange: () => { } })] })] }))] })), _jsxs("div", { style: {
                    padding: '3px 6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    background: '#060606',
                }, children: [_jsx("span", { style: { fontSize: 6, color: '#191919', fontFamily: 'IBM Plex Mono,monospace', letterSpacing: '.1em' }, children: track.loopLength ?? '—' }), _jsx("div", { style: { display: 'flex', gap: 2, alignItems: 'center' }, children: Array.from({ length: 4 }, (_, i) => (_jsx("div", { style: {
                                width: 4, height: 4,
                                background: isActive && i === beat.beat ? col : '#141414',
                                boxShadow: isActive && i === beat.beat ? `0 0 4px ${col}` : 'none',
                                transition: 'all 0.04s',
                            } }, i))) })] })] }));
};
