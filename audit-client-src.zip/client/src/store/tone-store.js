import { create } from 'zustand';
import * as Tone from 'tone';
import { Crossfader } from '../audio/dj-controls/crossfader';
import { TempoControl } from '../audio/dj-controls/tempo-control';
import { CueManager } from '../audio/dj-controls/cue-management';
import { BeatSync } from '../audio/dj-controls/beat-sync';
export const useAudioStore = create((set, get) => ({
    effectChain: new Map(),
    crossfader: null,
    tempoControl: null,
    cueManager: null,
    beatSync: null,
    crossfaderState: null,
    tempoState: null,
    initAudio: async () => {
        await Tone.start();
        const destination = Tone.Destination;
        const crossfader = new Crossfader(destination);
        const tempoControl = new TempoControl(120);
        const cueManager = new CueManager('default');
        const beatSync = new BeatSync(120);
        set({
            crossfader,
            tempoControl,
            cueManager,
            beatSync,
            crossfaderState: crossfader.getState(),
            tempoState: tempoControl.getState(),
        });
        // Subscribe to changes
        tempoControl.subscribe((state) => {
            set({ tempoState: state });
        });
    },
    addEffect: (type) => {
        // Implementation depends on selected type
        // Create effect instance and add to chain
    },
    updateEffect: (id, params) => {
        const { effectChain } = get();
        const effect = effectChain.get(id);
        if (effect) {
            effect.setParams(params);
        }
    },
    removeEffect: (id) => {
        const { effectChain } = get();
        const effect = effectChain.get(id);
        if (effect) {
            effect.dispose();
            effectChain.delete(id);
        }
    },
    setCrossfaderPosition: (position) => {
        const { crossfader } = get();
        crossfader?.setPosition(position);
    },
    setTempo: (bpm) => {
        const { tempoControl } = get();
        tempoControl?.setBpm(bpm);
    },
    jumpToCue: (index) => {
        const { cueManager } = get();
        if (cueManager) {
            try {
                cueManager.jumpToCue(index);
            }
            catch (err) {
                console.error('Cue error:', err);
            }
        }
    },
    setCue: (index, position) => {
        const { cueManager } = get();
        cueManager?.setCue(index, position);
    },
}));
