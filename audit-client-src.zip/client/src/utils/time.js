export const PIXELS_PER_SECOND = 100;
export function timeToPixels(timeInSeconds, zoom = 1) {
    return timeInSeconds * PIXELS_PER_SECOND * zoom;
}
export function pixelsToTime(pixels, zoom = 1) {
    return pixels / (PIXELS_PER_SECOND * zoom);
}
export function snapToGrid(time, gridSize) {
    return Math.round(time / gridSize) * gridSize;
}
export function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}
