import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'

export type EffectType = 'reverb' | 'delay' | 'flanger' | 'filter' | 'echo'

export interface Effect {
  id: string
  type: EffectType
  enabled: boolean
  params: Record<string, number>
}

export interface EffectsState {
  effects: Effect[]
  addEffect: (effect: Omit<Effect, 'id'>) => void
  removeEffect: (id: string) => void
  toggleEffect: (id: string) => void
  updateEffectParam: (id: string, key: string, value: number) => void
}

let _nextId = 0

export const useEffectsStore = create<EffectsState>()(
  subscribeWithSelector((set) => ({
    effects: [],

    addEffect: (effect) =>
      set((s) => ({
        effects: [...s.effects, { ...effect, id: `fx-${++_nextId}` }],
      })),

    removeEffect: (id) =>
      set((s) => ({ effects: s.effects.filter((e) => e.id !== id) })),

    toggleEffect: (id) =>
      set((s) => ({
        effects: s.effects.map((e) =>
          e.id === id ? { ...e, enabled: !e.enabled } : e
        ),
      })),

    updateEffectParam: (id, key, value) =>
      set((s) => ({
        effects: s.effects.map((e) =>
          e.id === id ? { ...e, params: { ...e.params, [key]: value } } : e
        ),
      })),
  }))
)
