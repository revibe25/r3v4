/**
 * stores/index.ts
 *
 * Central barrel for all Zustand stores.
 *
 * ── Redux → Zustand migration cheatsheet ───────────────────────────────────
 *
 *   BEFORE (Redux)                       AFTER (Zustand)
 *   ──────────────────────────────────   ──────────────────────────────────
 *   useSelector(s => s.mixer.bpm)        useMixerStore(s => s.bpm)
 *   useDispatch() + setBpm(130)          useMixerStore(s => s.setBpm)(130)
 *   configureStore + combineReducers      Each store is independent
 *   createSlice                           create<State>() + subscribeWithSelector
 *   redux-thunk async action             Regular async function, call set()
 *
 * ── Audio engine subscriptions (outside React) ─────────────────────────────
 *
 *   useMixerStore.subscribe(
 *     state => state.bpm,
 *     bpm => audioEngine.setBpm(bpm)
 *   )
 */

export { useMixerStore } from './mixerStore'
export type { MixerState, DeckState } from './mixerStore'

export { useEffectsStore } from './effectsStore'
export type { EffectsState, Effect, EffectType } from './effectsStore'
