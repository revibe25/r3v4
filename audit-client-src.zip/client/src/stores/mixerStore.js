import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
// ── Default deck ───────────────────────────────────────────────────────────
const defaultDeck = () => ({
    trackId: null,
    volume: 1.0,
    gain: 0.0,
    pitch: 0.0,
    isPlaying: false,
    position: 0.0,
    cuePoint: null,
});
// ── Store ──────────────────────────────────────────────────────────────────
/**
 * useMixerStore
 *
 * Uses subscribeWithSelector so audio engine callbacks outside React
 * can subscribe to individual fields without triggering full renders:
 *
 *   useMixerStore.subscribe(
 *     state => state.bpm,
 *     bpm => audioEngine.setBpm(bpm)
 *   )
 */
export const useMixerStore = create()(subscribeWithSelector((set) => ({
    bpm: 128,
    masterVolume: 1.0,
    crossfader: 0.5,
    deckA: defaultDeck(),
    deckB: defaultDeck(),
    setBpm: (bpm) => set({ bpm }),
    setMasterVolume: (vol) => set({ masterVolume: Math.max(0, Math.min(1, vol)) }),
    setCrossfader: (pos) => set({ crossfader: Math.max(0, Math.min(1, pos)) }),
    setDeckVolume: (deck, vol) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            volume: Math.max(0, Math.min(1, vol)),
        },
    })),
    setDeckGain: (deck, gain) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            gain,
        },
    })),
    setDeckPitch: (deck, pitch) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            pitch,
        },
    })),
    loadTrack: (deck, trackId) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            trackId,
            position: 0.0,
            isPlaying: false,
        },
    })),
    setPlaying: (deck, playing) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            isPlaying: playing,
        },
    })),
    setPosition: (deck, position) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            position: Math.max(0, Math.min(1, position)),
        },
    })),
    setCuePoint: (deck, cue) => set((s) => ({
        [deck === 'A' ? 'deckA' : 'deckB']: {
            ...(deck === 'A' ? s.deckA : s.deckB),
            cuePoint: cue,
        },
    })),
})));
