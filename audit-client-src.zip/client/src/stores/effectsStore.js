import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
let _nextId = 0;
export const useEffectsStore = create()(subscribeWithSelector((set) => ({
    effects: [],
    addEffect: (effect) => set((s) => ({
        effects: [...s.effects, { ...effect, id: `fx-${++_nextId}` }],
    })),
    removeEffect: (id) => set((s) => ({ effects: s.effects.filter((e) => e.id !== id) })),
    toggleEffect: (id) => set((s) => ({
        effects: s.effects.map((e) => e.id === id ? { ...e, enabled: !e.enabled } : e),
    })),
    updateEffectParam: (id, key, value) => set((s) => ({
        effects: s.effects.map((e) => e.id === id ? { ...e, params: { ...e.params, [key]: value } } : e),
    })),
})));
