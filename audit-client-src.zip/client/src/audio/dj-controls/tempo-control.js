// Stub for tempo-control
export class TempoControl {
    bpm = 120;
    setBpm(bpm) { this.bpm = bpm; }
    getBpm() { return this.bpm; }
    dispose() { }
}
export default TempoControl;
