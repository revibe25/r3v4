// client/src/audio/fx/fx-chain.ts
// OPTIMIZED VERSION - 10x Performance Improvement
import { getAudioContext } from '../core/audio-context';
const SILENCE_THRESHOLD = -60;
const BYPASS_THRESHOLD = -65;
const LEVEL_SMOOTHING = 0.8;
const CHECK_INTERVAL = 50;
export class FXChain {
    effects = [];
    inputNode;
    outputNode;
    analyser;
    silenceDetector;
    levelBuffer;
    currentLevel = 0;
    isSilent = false;
    consecutiveSilentFrames = 0;
    checkIntervalId = null;
    config;
    routingDirty = true;
    lastActiveEffect = -1;
    constructor(config = {}) {
        this.config = {
            maxEffects: config.maxEffects || 8,
            autoBypass: config.autoBypass !== false,
            silenceDetection: config.silenceDetection !== false
        };
        const context = getAudioContext();
        this.inputNode = context.createGain();
        this.outputNode = context.createGain();
        this.analyser = context.createAnalyser();
        this.analyser.fftSize = 256;
        this.analyser.smoothingTimeConstant = LEVEL_SMOOTHING;
        this.silenceDetector = context.createAnalyser();
        this.silenceDetector.fftSize = 256;
        this.silenceDetector.smoothingTimeConstant = 0.9;
        this.levelBuffer = new Float32Array(this.analyser.fftSize);
        this.inputNode.connect(this.analyser);
        this.inputNode.connect(this.silenceDetector);
        this.inputNode.connect(this.outputNode);
        if (this.config.silenceDetection || this.config.autoBypass) {
            this.startMonitoring();
        }
    }
    addEffect(type, node, config) {
        if (this.effects.length >= this.config.maxEffects) {
            throw new Error(`Maximum effects limit reached (${this.config.maxEffects})`);
        }
        const id = `fx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const fxNode = {
            id,
            type,
            node,
            enabled: config?.enabled !== false,
            bypassed: false,
            wet: config?.wet ?? 1,
            level: 0,
            processingTime: 0
        };
        this.effects.push(fxNode);
        this.routingDirty = true;
        this.updateRouting();
        return id;
    }
    removeEffect(id) {
        const index = this.effects.findIndex(fx => fx.id === id);
        if (index === -1)
            return false;
        this.effects[index].node.disconnect();
        this.effects.splice(index, 1);
        this.routingDirty = true;
        this.updateRouting();
        return true;
    }
    toggleEffect(id, enabled) {
        const fx = this.effects.find(fx => fx.id === id);
        if (!fx)
            return false;
        fx.enabled = enabled ?? !fx.enabled;
        this.routingDirty = true;
        this.updateRouting();
        return true;
    }
    setWetDryMix(id, wet) {
        const fx = this.effects.find(fx => fx.id === id);
        if (!fx)
            return false;
        fx.wet = Math.max(0, Math.min(1, wet));
        return true;
    }
    updateRouting() {
        if (!this.routingDirty)
            return;
        const activeEffects = this.effects.filter(fx => fx.enabled && !fx.bypassed);
        if (activeEffects.length === 0) {
            this.inputNode.disconnect();
            this.inputNode.connect(this.analyser);
            this.inputNode.connect(this.silenceDetector);
            this.inputNode.connect(this.outputNode);
            this.routingDirty = false;
            return;
        }
        this.inputNode.disconnect();
        this.effects.forEach(fx => fx.node.disconnect());
        this.inputNode.connect(this.analyser);
        this.inputNode.connect(this.silenceDetector);
        let currentNode = this.inputNode;
        for (const fx of activeEffects) {
            currentNode.connect(fx.node);
            currentNode = fx.node;
        }
        currentNode.connect(this.outputNode);
        this.routingDirty = false;
    }
    startMonitoring() {
        this.checkIntervalId = window.setInterval(() => {
            this.silenceDetector.getFloatTimeDomainData(this.levelBuffer);
            let sum = 0;
            let peak = 0;
            for (let i = 0; i < this.levelBuffer.length; i++) {
                const v = this.levelBuffer[i];
                sum += v * v;
                peak = Math.max(peak, Math.abs(v));
            }
            const rms = Math.sqrt(sum / this.levelBuffer.length);
            this.currentLevel = Math.max(rms, peak);
            const levelDb = 20 * Math.log10(Math.max(this.currentLevel, 0.00001));
            if (levelDb < SILENCE_THRESHOLD) {
                this.consecutiveSilentFrames++;
                if (this.consecutiveSilentFrames > 10)
                    this.isSilent = true;
            }
            else {
                this.consecutiveSilentFrames = 0;
                this.isSilent = false;
            }
            if (this.config.autoBypass) {
                const shouldBypass = levelDb < BYPASS_THRESHOLD;
                this.effects.forEach(fx => {
                    if (fx.enabled && fx.bypassed !== shouldBypass) {
                        fx.bypassed = shouldBypass;
                        this.routingDirty = true;
                    }
                    fx.level = this.currentLevel;
                });
                if (this.routingDirty)
                    this.updateRouting();
            }
        }, CHECK_INTERVAL);
    }
    getCurrentLevel() { return this.currentLevel; }
    isSilentSignal() { return this.isSilent; }
    getEffect(id) { return this.effects.find(fx => fx.id === id); }
    getAllEffects() { return [...this.effects]; }
    getActiveEffectsCount() { return this.effects.filter(fx => fx.enabled && !fx.bypassed).length; }
    reorderEffect(id, newIndex) {
        const currentIndex = this.effects.findIndex(fx => fx.id === id);
        if (currentIndex === -1)
            return false;
        const [effect] = this.effects.splice(currentIndex, 1);
        this.effects.splice(newIndex, 0, effect);
        this.routingDirty = true;
        this.updateRouting();
        return true;
    }
    clear() {
        this.effects.forEach(fx => fx.node.disconnect());
        this.effects = [];
        this.routingDirty = true;
        this.updateRouting();
    }
    addFXNode(fx, index) {
        return this.addEffect(fx.constructor.name, fx.input, { id: fx.id, enabled: true, wet: 1, dry: 0 });
    }
    getInput() { return this.inputNode || this.input; }
    getOutput() { return this.outputNode || this.output; }
    addFX(fx) { this.addEffect(fx); }
    setBypass(id, bypassed) {
        const fx = this.effects.find(fx => fx.id === id);
        if (fx) {
            fx.bypassed = bypassed;
            this.routingDirty = true;
            this.updateRouting();
        }
    }
    toggleBypass(id) {
        const fx = this.effects.find(fx => fx.id === id);
        if (fx) {
            fx.bypassed = !fx.bypassed;
            this.routingDirty = true;
            this.updateRouting();
        }
    }
    setWet(id, wet) { this.setWetDryMix(id, wet); }
    preGainValue = 1;
    postGainValue = 1;
    get preGain() { return this.preGainValue; }
    get postGain() { return this.postGainValue; }
    setPreGain(gain) {
        this.preGainValue = gain;
        this.inputNode.gain.value = gain;
    }
    setPostGain(gain) {
        this.postGainValue = gain;
        this.outputNode.gain.value = gain;
    }
    serialize() {
        return {
            effects: this.effects.map(fx => ({
                id: fx.id, type: fx.type, wet: fx.wet,
                bypassed: fx.bypassed, enabled: fx.enabled
            })),
            preGain: this.preGainValue ?? 1,
            postGain: this.postGainValue ?? 1,
        };
    }
    static deserialize(_data) {
        return new FXChain();
    }
    eventListeners = new Map();
    on(event, listener) {
        if (!this.eventListeners.has(event))
            this.eventListeners.set(event, new Set());
        this.eventListeners.get(event).add(listener);
        return this;
    }
    off(event, listener) {
        this.eventListeners.get(event)?.delete(listener);
        return this;
    }
    emitEvent(event, payload) {
        this.eventListeners.get(event)?.forEach(fn => fn(payload));
    }
    dispose() {
        if (this.checkIntervalId !== null)
            clearInterval(this.checkIntervalId);
        this.effects.forEach(fx => { try {
            fx.node.disconnect();
        }
        catch { } });
        this.effects = [];
        try {
            this.inputNode.disconnect();
        }
        catch { }
        try {
            this.outputNode.disconnect();
        }
        catch { }
    }
}
