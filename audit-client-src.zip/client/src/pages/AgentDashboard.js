import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
function StatCard({ title, value }) {
    return (_jsxs("div", { className: "bg-card p-4 rounded-lg", children: [_jsx("div", { className: "text-muted-foreground text-sm", children: title }), _jsx("div", { className: "text-xl font-bold", children: value })] }));
}
export default function AgentDashboard() {
    const { data, isLoading } = useQuery({
        queryKey: ["agentState"],
        queryFn: async () => {
            const res = await fetch("/agent/state?tenantId=tenant_1");
            return res.json();
        },
        refetchInterval: 2000
    });
    if (isLoading)
        return _jsx("div", { children: "Loading agent state..." });
    const state = data;
    return (_jsxs("div", { className: "p-6 text-white bg-background min-h-screen", children: [_jsx("h1", { className: "text-2xl font-bold mb-6", children: "Agent Dashboard" }), _jsxs("div", { className: "grid grid-cols-3 gap-4", children: [_jsx(StatCard, { title: "CPU Load", value: state.audioEngine.cpuLoad }), _jsx(StatCard, { title: "Underruns", value: state.audioEngine.bufferUnderruns }), _jsx(StatCard, { title: "Server Status", value: state.health.serverStatus })] }), _jsxs("div", { className: "mt-6", children: [_jsx("h2", { className: "text-lg font-semibold mb-2", children: "Alerts" }), state.alerts.map((a, i) => (_jsx("div", { className: "bg-red-900 p-2 mb-2 rounded", children: a.message }, i)))] })] }));
}
