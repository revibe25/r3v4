import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
export default function AdminAgentPage() {
    const { data } = useQuery({
        queryKey: ["tenantState"],
        queryFn: async () => {
            const res = await fetch("/api/tenant/state");
            return res.json();
        }
    });
    return (_jsxs("div", { className: "p-6 text-white", children: [_jsx("h1", { className: "text-2xl font-bold mb-4", children: "AI Agent Dashboard" }), _jsx("pre", { className: "bg-card p-4 rounded", children: JSON.stringify(data, null, 2) })] }));
}
